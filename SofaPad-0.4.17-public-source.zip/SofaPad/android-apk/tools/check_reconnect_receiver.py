#!/usr/bin/env python3
"""Actual receiver over isolated HTTP; virtual sender timing and mocked Mac output."""
import argparse,ast,base64,hashlib,json,math,os,socket,ssl,struct,sys,tempfile,threading,time
from pathlib import Path
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from trackpad_security import SecureReceiver,MAX_BODY,COOKIE
parser=argparse.ArgumentParser();parser.add_argument('--source',type=Path,default=ROOT/'trackpad.py');args=parser.parse_args()
class Pad:
 def __init__(self):
  self.lock=threading.RLock();self.drag_down=self.dragging=self.drag_latched=False;self.last_tap_t=77;self.frames=[];self.releases=0
  self.scroll_motion=type('Scroll',(),{'stop':lambda s:None})()
 def on_frame(self,*args):
  self.frames.append(args)
  if args[0] and args[-1]:self.drag_down=True
 def reset(self):self.drag_down=self.dragging=self.drag_latched=False;self.releases+=1
class Clock:
 now=100
 def monotonic(self):return self.now
clock=Clock();pad=Pad();ups=[]
tree=ast.parse(args.source.read_text());names={'recv_exact','ws_handshake','ws_recv','ws_send_text','serve_client','InputFrameClock','reset_remote_input'}
nodes=[n for n in tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef)) and n.name in names];assert len(nodes)==len(names)
with tempfile.TemporaryDirectory(prefix='trackpad-reconnect-test-') as folder:
 listener=socket.socket();listener.bind(('127.0.0.1',0));listener.listen(8);listener.settimeout(.1);port=listener.getsockname()[1]
 sec=SecureReceiver(Path(folder)/'state',names=['127.0.0.1','127.0.0.1'],port=port,bootstrap_port=0)
 env={'time':clock,'SECURITY':sec,'MAX_BODY':MAX_BODY,'PAD':pad,'socket':socket,'base64':base64,'hashlib':hashlib,'struct':struct,'json':json,'math':math,'os':os,'SELF_PATH':str(args.source),'PAGE':'isolated','MOD_MASK':0x1e0000,'WS_GUID':'258EAFA5-E914-47DA-95CA-C5AB0DC85B11','mouse_up':lambda *a:ups.append(a),'type_text':lambda *a:None,'key_combo':lambda *a:None,'media_volume':lambda *a:None,'print':lambda *a,**k:None}
 exec(compile(ast.Module(body=nodes,type_ignores=[]),'receiver-reconnect-test','exec'),env)
 C=env['InputFrameClock'];c=C();assert c.accept(1000,100)
 assert c.accept(1016,100.016) and c.accept(1032,100.040),'healthy timing is immediate'
 assert not c.accept(1048,101),'old movement must be rejected after a processing/network stall'
 assert not c.accept(1000,101),'out of order old timestamps cannot rebase the clock'
 assert c.accept(2050,101.050),'fresh timing recovers'
 assert c.accept(None,102),'legacy clients stay compatible'
 assert not c.accept(float('nan'),102) and not c.accept(True,102)
 assert C().accept(1,500),'a new connection has a fresh sender clock'
 running=True;threads=[]
 def serve():
  while running:
   try:conn,addr=listener.accept()
   except socket.timeout:continue
   except OSError:break
   t=threading.Thread(target=env['serve_client'],args=(conn,addr),daemon=True);threads.append(t);t.start()
 accept=threading.Thread(target=serve,daemon=True);accept.start()
 capsule=sec.capsule();code=json.loads(base64.urlsafe_b64decode(capsule+'='*(-len(capsule)%4)))['code']
 ident,token=sec.issue(code,'isolated-reconnect','test')
 ctx=None
 def exact(s,n):
  out=b''
  while len(out)<n:
   chunk=s.recv(n-len(out));assert chunk;out+=chunk
  return out
 def read(s):
  b=exact(s,2);n=b[1]&127
  if n==126:n=struct.unpack('>H',exact(s,2))[0]
  assert n<32768
  return json.loads(exact(s,n))
 def send(s,msg,opcode=1):
  data=json.dumps(msg).encode() if opcode==1 else b'';mask=b'abcd';n=len(data)
  head=bytes([0x80|opcode,0x80|n]) if n<126 else bytes([0x80|opcode,0xfe])+struct.pack('>H',n)
  s.sendall(head+mask+bytes(v^mask[i%4] for i,v in enumerate(data)))
 def connect():
  s=socket.create_connection(('127.0.0.1',port));s.settimeout(3)
  key=base64.b64encode(b'0123456789abcdef').decode()
  s.sendall(('GET /ws HTTP/1.1\r\nHost: 127.0.0.1:%d\r\nOrigin: http://127.0.0.1:%d\r\nCookie: %s=%s\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Key: %s\r\nSec-WebSocket-Version: 13\r\n\r\n'%(port,port,COOKIE,token,key)).encode())
  head=b''
  while not head.endswith(b'\r\n\r\n'):head+=exact(s,1)
  assert head.startswith(b'HTTP/1.1 101');assert 'status' in read(s)
  return s
 def barrier(s):
  send(s,{'heartbeat':True})
  assert read(s).get('alive') is True
 # Actual HTTP HTML response refreshes iOS12 cookie flags before subresources load.
 legacy_ua='Mozilla/5.0 (iPad; CPU OS 12_0 like Mac OS X) AppleWebKit/605.1.15 Version/12.1.2 Mobile Safari/604.1'
 with socket.create_connection(('127.0.0.1',port)) as page:
  page.settimeout(3)
  page.sendall(('GET / HTTP/1.1\r\nHost: 127.0.0.1:%d\r\nCookie: %s=%s\r\nUser-Agent: %s\r\nConnection: close\r\n\r\n'%(port,COOKIE,token,legacy_ua)).encode())
  response=b''
  while True:
   chunk=page.recv(4096)
   if not chunk:break
   response+=chunk
  assert response.startswith(b'HTTP/1.1 200') and response.endswith(b'isolated')
  assert b'Set-Cookie:' in response and b'HttpOnly' in response and b'SameSite' not in response,'legacy page refresh must migrate the existing cookie before assets/WS'
 csp=sec.page_headers({'host':'127.0.0.1:%d'%port})['Content-Security-Policy']
 assert ("connect-src 'self' ws://127.0.0.1:%d;"%port) in csp
 assert csp.encode() in response,'actual HTTP HTML must include the precise WS authority'
 assert 'ws://evil.example' not in csp and 'wss:;' not in csp and '*' not in csp
 for bad_host in ['evil.example:%d'%port,'127.0.0.1:%d; ws://evil.example'%port,'127.0.0.1:%d\r\nInjected: yes'%port]:
  assert 'Content-Security-Policy' not in sec.page_headers({'host':bad_host}),'unvalidated authority must not enter CSP'
 print('HTTP CSP checks passed: explicit same-Mac WS authority, no wildcard or arbitrary WS, invalid hosts excluded.')
 first=connect();assert pad.last_tap_t==0,'connection entry clears prior double-tap state'
 send(first,{'sentAt':1000,'meta':{}});clock.now=100.016
 send(first,{'sentAt':1016,'p':[[1,.3,.5]],'directDrag':True});barrier(first)
 assert len(pad.frames)==1 and pad.drag_down
 clock.now=101
 send(first,{'sentAt':1032,'p':[[1,.9,.5]]})
 assert 'inputReset' in read(first)
 assert len(pad.frames)==1 and not pad.drag_down and ups,'stale burst releases drag without replay'
 # Liveness must not be rejected by input timestamp ordering/latency filtering.
 send(first,{'heartbeat':True,'sentAt':1000})
 assert read(first).get('alive') is True,'delayed/out-of-order heartbeat must still receive a liveness response'
 assert len(pad.frames)==1 and not pad.drag_down,'heartbeat must not replay input or restore held controls'
 clock.now=101.02;send(first,{'sentAt':2020,'p':[[1,.91,.5]]});barrier(first)
 assert len(pad.frames)==1,'same held finger stays blocked after a stale burst'
 clock.now=101.03;send(first,{'sentAt':2030,'p':[]});barrier(first)
 clock.now=101.04;send(first,{'sentAt':2040,'p':[[2,.4,.5]]});barrier(first)
 assert pad.frames[-1][0]==[[2,.4,.5]],'fresh contact resumes after lift'
 pad.drag_down=True;pad.last_tap_t=999;send(first,{},opcode=8);first.close()
 limit=time.monotonic()+3
 while sec.active is not None and time.monotonic()<limit:time.sleep(.01)
 assert sec.active is None and not pad.drag_down and pad.last_tap_t==0,'disconnect clears held input and lease'
 clock.now=500;second=connect();before=len(pad.frames)
 send(second,{'sentAt':1,'p':[[3,.5,.5]]});barrier(second)
 assert len(pad.frames)==before+1,'reconnect starts a fresh timing generation'
 send(second,{},opcode=8);second.close();running=False;listener.close();accept.join(2)
 for thread in threads:thread.join(2)
print('Receiver reconnect integration passed: actual local HTTP, sender clock reset, stale burst rejection, drag release, held-contact quarantine, fresh contact recovery and controller cleanup. All Mac input mocked.')
