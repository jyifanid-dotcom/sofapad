#!/usr/bin/env python3
"""Exercise actual receiver recognizer without importing macOS APIs or emitting input."""
import ast, math, threading, argparse
from pathlib import Path
parser=argparse.ArgumentParser();parser.add_argument('--source',type=Path,default=Path(__file__).resolve().parents[2]/'trackpad.py');src=parser.parse_args().source
tree=ast.parse(src.read_text());compile(tree,str(src),'exec')
class Clock:
    now=100.0
    def time(self):return self.now
    def monotonic(self):return self.now
clock=Clock();events=[]
ns={'math':math,'threading':threading,'time':clock,'screen_size':lambda:(1000,700),
    'native_magnify':lambda amount,phase:events.append(('magnify',amount,phase)) or True,
    'cursor_pos':lambda:(300,300),'hid_flags':lambda:0,'print':lambda *a,**k:None,
    'mouse_down':lambda button='left',count=1:events.append(('down',count)),
    'mouse_up':lambda button='left',count=1:events.append(('up',count)),
    'mouse_click':lambda button='left',count=1:events.append(('click',button,count)),
    'mouse_move':lambda x,y,dragged=False:events.append(('move',x,y,dragged))}
for n in tree.body:
    if isinstance(n,ast.Assign):
        try:
            value=ast.literal_eval(n.value)
            for target in n.targets:
                if isinstance(target,ast.Name) and target.id!='PAGE':ns[target.id]=value
        except (ValueError,TypeError):pass
ns['display_rects']=lambda:[(0,0,999,699)]
constraint=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='constrain_pointer')
exec(compile(ast.Module(body=[constraint],type_ignores=[]),'display-constraint','exec'),ns)
motion=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='ScrollMotion')
exec(compile(ast.Module(body=[motion],type_ignores=[]),'scroll-motion','exec'),ns)
node=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='Trackpad')
exec(compile(ast.Module(body=[node],type_ignores=[]),'receiver-class','exec'),ns)
T=ns['Trackpad'];pad=T()
def frame(points,dt=.05,gain=720):
    clock.now+=dt;pad.on_frame(points,gain)
frame([[1,.5,.5]]);frame([], .08)
frame([[1,.5,.5]],.12)
assert ('down',2) in events,'second touch must press before motion with double click state'
frame([[1,.505,.5]])
assert any(e[0]=='move' and e[3] for e in events),'first small movement must be a dragged event'
frame([])
assert ('up',2) in events,'second release preserves double click state'
events.clear();clock.now+=2
frame([[1,.5,.5]]);frame([[1,.5,.5]],.7);frame([])
assert not any(e[0]=='click' and e[1]=='right' for e in events)
def distance(gain):
    events.clear();clock.now+=2;p=T();p.on_frame([[1,.5,.5]],gain);clock.now+=.05;p.on_frame([[1,.55,.5]],gain)
    return next(e[1]-300 for e in events if e[0]=='move')
slow=distance(360);fast=distance(1080)
assert abs(fast/slow-3)<.0001,'live gain must change next movement without reconnect'
print('Receiver checks passed: second-touch press/click-state, held drag events, no long-right, immediate gain; no real Mac events emitted.')

M=ns['ScrollMotion']
def stroke(dt):
    motion=M();motion.begin(200);now=200;total=0
    for i in range(6):
        now+=dt;motion.add(0,.02,now);total+=motion.step(now)[1]
    motion.release(now)
    for i in range(60):
        now+=.016;total+=motion.step(now)[1]
    return total
slow=stroke(.08);fast=stroke(.016)
assert fast>slow*2,('fast flick must scroll further',slow,fast)
m=M();m.begin(300);m.add(.08,0,300.016);m.step(300.016);m.release(300.02)
assert m.step(300.036)[0]>0,'horizontal flick retains direction'
m.begin(300.04);assert m.step(300.056)==(0,0),'new touch immediately stops momentum'
m.add(0,.08,300.072);m.release(300.08);m.stop();assert m.step(300.096)==(0,0),'disconnect/cancel immediately stops momentum'
m.begin(400);m.add(0,.08,400.016)
for i in range(30):m.step(400.016+i*.016)
m.release(400.6);assert not m.momentum,'pause before lift must not start a flick'
print('Receiver scroll checks passed: fast vs slow travel, horizontal direction, new-touch/cancel stop, pause-before-lift gate.')

events.clear();clock.now=500;pad=T();ns['scroll']=lambda dy,dx:events.append(('scroll',dy,dx))
pad.on_frame([[1,.25,.5],[2,.45,.5]]);clock.now+=.016
pad.on_frame([[1,.31,.5],[2,.51,.5]]);pad.tick_scroll(clock.now)
clock.now+=.008;pad.on_frame([[1,.31,.5]])
clock.now+=.006;pad.on_frame([]);before=len(events);clock.now+=.016;pad.tick_scroll(clock.now)
assert len(events)>before and events[-1][0]=='scroll','receiver staggered lift must retain scrolling momentum'
clock.now+=.004;pad.on_frame([[1,.5,.5]]);before=len(events);clock.now+=.016;pad.tick_scroll(clock.now)
assert len(events)==before,'new contact interrupts receiver momentum'
m=M();m.begin(600);m.add(0,.08,600.016);m.add(0,-.08,600.032);assert m.step(600.032)[1]<0,'reversal discards prior positive queue'
print('Gesture scroll integration passed: staggered lift fling, new contact interruption, direction reversal.')

events.clear();clock.now=700;p=T();p.on_frame([[1,.25,.5],[2,.45,.5]]);clock.now+=.016;p.on_frame([[1,.253,.58],[2,.453,.58]]);p.tick_scroll(clock.now)
assert p.scroll_axis==1 and any(e[0]=='scroll' and e[1]!=0 for e in events) and all(e[2]==0 for e in events if e[0]=='scroll'),'vertical scroll must not drift into horizontal carousels'
ns['key_combo']=lambda *args:events.append(('key',args));clock.now+=.016;p.on_frame([[1,.253,.58],[2,.853,.58]]);assert p.scroll_intent=='scroll' and not any(e[0]=='key' for e in events),'scroll intent cannot switch into pinch from spread noise'
events.clear();clock.now=800;p=T();p.on_frame([[1,.5,.5,45,45]]);clock.now+=.02;p.on_frame([[1,.5,.5,150,150]]);clock.now+=.02;p.on_frame([])
assert not any(e[0]=='click' for e in events),'palm replacement cancels without click'
clock.now=900;p=T()
def dragframe(points,delta=.05):
    clock.now+=delta;p.on_frame(points,drag_lock=True)
dragframe([[1,.5,.5]]);dragframe([], .08);dragframe([[1,.5,.5]],.12);dragframe([[1,.6,.5]]);dragframe([])
assert p.drag_latched,'optional drag lock keeps actual button down after drag lift'
dragframe([[1,.2,.5]],.15);dragframe([], .08);assert not p.drag_latched and events[-1][0]=='up','tap ends latch'
dragframe([[1,.5,.5]],1);dragframe([], .08);dragframe([[1,.5,.5]],.12);dragframe([[1,.6,.5]]);dragframe([]);clock.now+=5.1;p.tick_scroll(clock.now);assert not p.drag_latched and events[-1][0]=='up','idle latch must timeout safely'
m=M();m.inertia=0;m.begin(1000);m.add(0,.08,1000.016);m.release(1000.02);assert not m.momentum,'inertia zero disables momentum'
print('Advanced receiver checks passed: vertical axis lock, scroll/pinch intent, palm cancellation, optional drag lock/tap release/timeout, inertia off.')

# Fractional pointer motion and desktop topology; no actual display/input access.
constraint=ns['constrain_pointer']
layouts=[[(0,0,999,699),(1000,0,1999,699)],[(0,0,999,699),(-1000,0,-1,699)],[(0,0,999,699),(0,-700,999,-1)]]
assert constraint(1004,200,layouts[0])==(1004,200),'right extension reachable'
assert constraint(-4,200,layouts[1])==(-4,200),'negative-x extension reachable'
assert constraint(200,-4,layouts[2])==(200,-4),'negative-y extension reachable'
assert constraint(4000,200,layouts[0])==(1999,200),'outer desktop constrained'
ns['display_rects']=lambda:layouts[0]
clock.now+=2;p=T();events.clear();p.on_frame([[1,.5,.5]],360)
for i in range(1,21):
    clock.now+=.016;p.on_frame([[1,.5+i*.0004,.5]],360)
moves=[e for e in events if e[0]=='move']
assert len(moves)==20,'every slow sample moves, no dead-zone bursts'
assert abs(moves[-1][1]-300-20*.0004*720*.6)<1e-8,'fractional distance conserved'
assert max(moves[i][1]-moves[i-1][1] for i in range(1,len(moves)))<.18,'fine movement remains subpixel'
def pointer_travel(size):
    ns['screen_size']=lambda:size;clock.now+=2;p=T();events.clear();p.on_frame([[1,.5,.5]],720);clock.now+=.016;p.on_frame([[1,.51,.51]],720)
    e=next(e for e in events if e[0]=='move');return e[1:3]
assert pointer_travel((1000,700))==pointer_travel((3000,2000)),'Retina resolution does not amplify pointer movement'
ns['cursor_pos']=lambda:(997,200);clock.now+=2;p=T();events.clear();p.on_frame([[1,.5,.5]],720);clock.now+=.016;p.on_frame([[1,.51,.5]],720)
assert next(e[1] for e in events if e[0]=='move')>1000,'recognizer crosses to extension'
ns['display_rects']=lambda:layouts[1];ns['cursor_pos']=lambda:(2,200);clock.now+=2;p=T();events.clear();p.on_frame([[1,.5,.5]],720);clock.now+=.016;p.on_frame([[1,.49,.5]],720)
assert next(e[1] for e in events if e[0]=='move')<0,'recognizer crosses left of main screen'
print('Pointer checks passed: 20 continuous subpixel samples, conserved slow travel, Retina-independent gain, right/left/above extensions and outer bounds. Mock displays/input only.')
ns['display_rects']=lambda:layouts[0];ns['cursor_pos']=lambda:(997,200);clock.now+=2;p=T();p.last_tap_t=clock.now-.1;events.clear();p.on_frame([[1,.5,.5]],720);clock.now+=.016;p.on_frame([[1,.52,.5]],720)
assert any(e[0]=='move' and e[1]>1000 and e[3] for e in events),'held double-tap drag crosses monitor boundary'
print('Cross-display held drag check passed; no real input.')

# A non-square touch surface must preserve equal physical distance on both axes.
ns['screen_size']=lambda:(1000,700);ns['display_rects']=lambda:[(-5000,-5000,5000,5000)];ns['cursor_pos']=lambda:(300,300)
clock.now+=2;p=T();events.clear();p.on_frame([[1,.5,.5]],720,surface=[300,600]);clock.now+=.016;p.on_frame([[1,.51,.505]],720,surface=[300,600])
e=next(e for e in events if e[0]=='move');assert abs((e[1]-300)-(e[2]-300))<1e-8,'same CSS-pixel movement has equal x/y gain'
print('Rectangular surface pointer scale check passed; scroll untouched.')

# Native pinch lifecycle and ratios; never inject events into the desktop.
ns['native_magnify']=lambda amount,phase:events.append(('magnify',amount,phase)) or True
clock.now+=2;p=T();events.clear();p.on_frame([[1,.35,.5],[2,.65,.5]]);clock.now+=.02;p.on_frame([[1,.30,.5],[2,.70,.5]])
for _ in range(20):clock.now+=.016;p.tick_scroll(clock.now)
magnifies=[e for e in events if e[0]=='magnify'];assert magnifies[0][2]==1 and any(e[2]==2 for e in magnifies),'begin + continuous changed pinch events'
factor=math.prod(1+e[1] for e in magnifies if e[2]==2);assert abs(factor-4/3)<1e-8,'zoom ratio preserved including intent threshold'
clock.now+=.02;p.on_frame([[1,.32,.5],[2,.68,.5]]);changes=[e for e in events if e[0]=='magnify' and e[2]==2];assert changes[-1][1]<0,'closing fingers shrinks continuously'
clock.now+=.02;p.on_frame([]);assert [e for e in events if e[0]=='magnify'][-1][2]==4,'release ends magnify'
clock.now+=2;p=T();events.clear();p.on_frame([[1,.35,.5],[2,.65,.5]]);clock.now+=.02;p.on_frame([[1,.30,.5],[2,.70,.5]]);p.reset()
assert [e for e in events if e[0]=='magnify'][-1][2]==8,'cancel/reset closes magnify lifecycle'
print('Native pinch checks passed: begin/change/end/cancel, continuous ratios and reversal; no global input.')

# A large target change is spread across ticks, and lift/cancel never replays a zoom.
clock.now+=2;p=T();events.clear();p.on_frame([[1,.35,.5],[2,.65,.5]]);clock.now+=.016;p.on_frame([[1,.25,.5],[2,.75,.5]])
changes=[e for e in events if e[0]=='magnify' and e[2]==2];assert changes and max(abs(math.log1p(e[1])) for e in changes)<=.100000001,'large pinch has bounded per-tick output'
clock.now+=.016;p.on_frame([[1,.25,.5]]);assert [e for e in events if e[0]=='magnify'][-1][2]==4,'first finger lift ends magnify without waiting for second lift'
finished=len([e for e in events if e[0]=='magnify'])
for _ in range(10):clock.now+=.016;p.tick_scroll(clock.now)
assert len([e for e in events if e[0]=='magnify'])==finished,'no zoom continues after finger lift'
print('Smooth pinch checks passed: bounded continuous output, preserved settled ratio, immediate reversal and no after-lift replay.')

clock.now+=2;p=T();events.clear();p.on_frame([[1,.35,.5],[2,.65,.5]]);clock.now+=.016;p.on_frame([[1,.25,.5],[2,.75,.5]])
clock.now+=.016;p.on_frame([[1,.26,.5],[2,.74,.5]])
assert [e for e in events if e[0]=='magnify' and e[2]==2][-1][1]<0,'reversal discards unsent expanding target immediately'
print('Unsettled fast pinch reversal check passed.')

clock.now+=2;p=T();p.last_tap_t=clock.now-.1;events.clear();p.on_frame([[1,.5,.5]],drag_lock=True,direct_drag=True)
assert events==[('down',1)],'direct drag starts with a single press and no leading click'
clock.now+=.016;p.on_frame([[1,.6,.5]],drag_lock=True,direct_drag=True)
assert any(e[0]=='move' and e[3] for e in events),'direct drag preserves held button while moving'
clock.now+=.016;p.on_frame([],drag_lock=True,direct_drag=True)
assert events[-1]==('up',1) and not p.drag_latched,'direct drag releases even if optional drag-lock enabled'
assert not any(e[0]=='click' for e in events),'screenshot selection cannot be dismissed by a synthetic first click'
print('Direct drag checks passed: single press/move/release without prior click, no drag latch.')

clock.now+=2;p=T();events.clear();p.on_frame([[1,.5,.5]],direct_drag=True);clock.now+=16;p.tick_scroll(clock.now)
assert events[-1]==('up',1) and not p.drag_down,'receiver watchdog releases direct drag even without browser timer'
print('Receiver direct-drag watchdog check passed.')

# Static two-finger taps have down/up events, not a stream of move samples.
ns['display_rects']=lambda:[(-5000,-5000,5000,5000)];ns['cursor_pos']=lambda:(300,300)
clock.now+=2;p=T();events.clear();p.on_frame([[1,.3,.5]])
clock.now+=.02;p.on_frame([[1,.3,.5],[2,.5,.5]])
clock.now+=.10;p.on_frame([[2,.5,.5]])
clock.now+=.02;p.on_frame([])
assert [e for e in events if e[0]=='click']==[('click','right',1)],'stationary staggered two-finger tap emits exactly one right click without move frames'
# Count actual simultaneous contact, not a long single-finger tail after a ghost.
clock.now+=2;p=T();events.clear();p.on_frame([[1,.3,.5],[2,.5,.5]])
clock.now+=.01;p.on_frame([[1,.3,.5]])
clock.now+=.10;p.on_frame([])
assert not any(e[0]=='click' for e in events),'10ms ghost overlap cannot qualify via a long one-finger tail'
clock.now+=2;p=T();events.clear();p.on_frame([[1,.3,.5]])
clock.now+=.10;p.on_frame([[1,.3,.5],[2,.5,.5]])
clock.now+=.10;p.on_frame([])
assert not any(e[0]=='click' and e[1]=='right' for e in events),'late second finger is not a clean right tap'
clock.now+=2;p=T();events.clear();p.on_frame([[1,.3,.5],[2,.5,.5]])
clock.now+=.05;p.on_frame([[1,.3,.55],[2,.5,.55]])
clock.now+=.05;p.on_frame([[1,.3,.5],[2,.5,.5]])
clock.now+=.05;p.on_frame([])
assert not any(e[0]=='click' for e in events),'scroll returning to its origin never becomes a right click'
print('Stationary right-tap regression passed: no move frames required, actual overlap gate, late/ghost/scroll rejection.')

# Defensive continuity when an old page or a malformed stream loses a lift frame.
clock.now+=2;p=T();events.clear();p.on_frame([[11,.2,.5]])
clock.now+=.04;p.on_frame([[12,.7,.5]])
assert not any(e[0] in ('move','click') for e in events),'changed contact ID rebases without teleport or click'
clock.now+=.016;p.on_frame([[12,.71,.5]])
move=next(e for e in events if e[0]=='move')
assert abs(move[1]-308.64)<1e-8,'motion resumes from the new contact baseline'
clock.now+=2;p=T();events.clear();p.on_frame([[11,.2,.5]],direct_drag=True,drag_lock=True)
clock.now+=.04;p.on_frame([[12,.7,.5]],drag_lock=True)
assert events==[('down',1),('up',1)] and not p.drag_latched,'lost dragged contact releases before rebasing without latching'
print('Contact continuity regression passed: no cross-contact delta, no phantom click, held button released.')

# Lifting stationary fingers one by one changes the centroid, not the gesture.
for count in (3,4):
 clock.now+=2;p=T();events.clear()
 points=[[i,.2+i*.15,.5] for i in range(count)]
 p.on_frame(points)
 for left in range(count-1,0,-1):
  clock.now+=.04;p.on_frame(points[:left])
 clock.now+=.04;p.on_frame([])
 assert not any(e[0] in ('key','click','move','magnify') for e in events),('stationary multi-finger lift must be silent',count,events)
# An actual full-contact swipe still works after staggered release.
for count in (3,4):
 clock.now+=2;p=T();events.clear();points=[[i,.2+i*.12,.5] for i in range(count)]
 p.on_frame(points);clock.now+=.08;p.on_frame([[i,x+.10,y] for i,x,y in points])
 for left in range(count-1,0,-1):clock.now+=.02;p.on_frame([[i,x+.10,y] for i,x,y in points[:left]])
 clock.now+=.02;p.on_frame([])
 assert len([e for e in events if e[0]=='key'])==1,('full-contact swipe must remain enabled',count,events)
print('Three/four-finger tap regression passed: staggered lift makes no action; real full-contact swipes remain enabled.')
# Chorded finger-down also changes the centroid, but must not synthesize a swipe.
for count in (3,4):
 clock.now+=2;p=T();events.clear();points=[[i,.2+i*.12,.5] for i in range(count)]
 for down in range(1,count+1):clock.now+=.02;p.on_frame(points[:down])
 for left in range(count-1,0,-1):clock.now+=.02;p.on_frame(points[:left])
 clock.now+=.02;p.on_frame([])
 assert not any(e[0] in ('key','click') for e in events),('staggered down/up chord remains a tap',count,events)
ns['open_launcher']=lambda:events.append(('launcher',))
clock.now+=2;p=T();events.clear();points=[[i,.2+i*.15,.5] for i in range(4)];p.on_frame(points)
shrunk=[[i,.425+(x-.425)*.6,y] for i,x,y in points];clock.now+=.1;p.on_frame(shrunk)
for left in (3,2,1):clock.now+=.02;p.on_frame(shrunk[:left])
clock.now+=.02;p.on_frame([])
assert events==[('launcher',)],'real four-finger pinch survives staggered release'
print('Chord and four-finger pinch checks passed: quiet taps with sequential down/up; real pinch preserved.')
