#!/usr/bin/env python3
"""Record only the current successful cloud build, never inherit old local evidence."""
import hashlib,json,os,re,sys
from pathlib import Path
root=Path(__file__).resolve().parents[1]
apk=Path(sys.argv[1]).resolve()
if os.environ.get('GITHUB_ACTIONS')!='true':raise SystemExit('An actual GitHub Actions run is required')
sig=(apk.parent/'signature-check.txt').read_text()
if 'Verifies' not in sig:raise SystemExit('Signature verification missing')
cert=re.search(r'certificate SHA-256 digest: ([0-9a-f]{64})',sig)
if not cert:raise SystemExit('Signing certificate digest missing')
info=(apk.parent/'apk-info.txt').read_text()
version=re.search(r"versionName='([^']+)'",info);code=re.search(r"versionCode='(\d+)'",info)
if not version or not code:raise SystemExit('APK version missing')
status={
 'version':version[1]+'-cloud-debug','version_code':int(code[1]),
 'build_method':'GitHub Actions','apk_sha256':hashlib.sha256(apk.read_bytes()).hexdigest(),
 'signing_certificate_sha256':cert[1],'signing':'ephemeral runner debug signing; not the local distribution key',
 'checks':{'static_package':'passed','shared_page_and_reconnect_mock':'passed','native_mock_frameworks':'passed','assembleDebug':'passed','lintDebug':'passed','APK_signature':'passed'},
 'cloud_commit':os.environ['GITHUB_SHA'],
 'cloud_run_url':f"{os.environ['GITHUB_SERVER_URL']}/{os.environ['GITHUB_REPOSITORY']}/actions/runs/{os.environ['GITHUB_RUN_ID']}",
 'hardware_acceptance':'not performed by this workflow','transport_stability_acceptance':'not performed by this workflow'
}
(apk.parent/'TEST_STATUS.json').write_text(json.dumps(status,ensure_ascii=False,indent=2)+'\n')
