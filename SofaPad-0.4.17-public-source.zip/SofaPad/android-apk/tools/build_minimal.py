#!/usr/bin/env python3
"""Build with an explicitly supplied temporary JDK + official SDK files, no global install.

Normal/cloud builds use Gradle. This fallback performs javac, D8, AAPT2, zipalign,
signing and signature verification; it does not claim Android lint or device testing.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import xml.etree.ElementTree as ET
import zipfile

ROOT = Path(__file__).resolve().parents[1]
VERSION = '0.4.17'


def run(*args, **kwargs):
    print('Running:', Path(str(args[0])).name, flush=True)
    return subprocess.run([str(x) for x in args], check=True, **kwargs)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--jdk', required=True, type=Path)
    parser.add_argument('--platform', required=True, type=Path)
    parser.add_argument('--build-tools', required=True, type=Path)
    args = parser.parse_args()
    jdk, platform, tools = args.jdk.resolve(), args.platform.resolve(), args.build_tools.resolve()
    for f in [jdk/'bin/javac',platform/'android.jar',tools/'aapt2',tools/'zipalign',tools/'lib/d8.jar',tools/'lib/apksigner.jar']:
        if not f.is_file(): raise FileNotFoundError(f)
    qr = ROOT/'app/libs/zxing-core-3.5.3.jar'
    qr_provenance=json.loads((qr.parent/'ZXING_PROVENANCE.json').read_text())
    if hashlib.sha256(qr.read_bytes()).hexdigest()!=qr_provenance['sha256']:raise ValueError('ZXing hash mismatch')
    out = ROOT/'dist'; out.mkdir(exist_ok=True)
    signing = ROOT/'.local-signing'; signing.mkdir(mode=0o700, exist_ok=True)
    keystore = signing/'test.keystore'
    # A project-only test signing key. Excluded from source/upload bundles; preserved for updates.
    if not keystore.exists():
        run(jdk/'bin/keytool','-genkeypair','-keystore',keystore,'-storepass','android',
            '-keypass','android','-alias','androiddebugkey','-keyalg','RSA','-keysize','2048',
            '-validity','10000','-dname','CN=Trackpad Test,O=Trackpad,C=CN','-noprompt')
        keystore.chmod(0o600)
    with tempfile.TemporaryDirectory(prefix='trackpad-compile-') as temp:
        tmp = Path(temp)
        classes=tmp/'classes'; classes.mkdir()
        dex=tmp/'dex'; dex.mkdir()
        tests=tmp/'tests'; tests.mkdir()
        sources=sorted((ROOT/'app/src/main/java').rglob('*.java'))
        run(jdk/'bin/javac','--release','17','-encoding','UTF-8','-classpath',str(platform/'android.jar')+os.pathsep+str(qr),
            '-d',classes,*sources)
        run(jdk/'bin/javac','--release','17','-encoding','UTF-8','-d',tests,
            ROOT/'app/src/main/java/cc/trackpad/tablet/HidReports.java',
            ROOT/'app/src/main/java/cc/trackpad/tablet/GestureEngine.java',
            ROOT/'app/src/main/java/cc/trackpad/tablet/RelativeMotion.java',
            ROOT/'app/src/main/java/cc/trackpad/tablet/RemoteComposer.java',
            ROOT/'app/src/main/java/cc/trackpad/tablet/RemoteTextMirror.java',
            ROOT/'app/src/main/java/cc/trackpad/tablet/EdgeSwipe.java',
            ROOT/'app/src/main/java/cc/trackpad/tablet/ServerAddress.java',ROOT/'tools/EngineCheck.java')
        run(jdk/'bin/java','-cp',tests,'cc.trackpad.tablet.EngineCheck')
        run(sys.executable,ROOT/'tools/check_bluetooth_lifecycle.py','--jdk',jdk)
        run(sys.executable,ROOT/'tools/check_remote_input.py','--jdk',jdk)
        run(jdk/'bin/java','-cp',tools/'lib/d8.jar','com.android.tools.r8.D8','--lib',platform/'android.jar',
            '--min-api','28','--output',dex,*sorted(classes.rglob('*.class')),qr)
        run(tools/'aapt2','compile','--dir',ROOT/'app/src/main/res','-o',tmp/'resources.zip')
        manifest=ET.parse(ROOT/'app/src/main/AndroidManifest.xml')
        manifest.getroot().set('package','cc.trackpad.tablet')
        ET.register_namespace('android','http://schemas.android.com/apk/res/android')
        manifest.write(tmp/'AndroidManifest.xml',encoding='utf-8',xml_declaration=True)
        run(tools/'aapt2','link','-o',tmp/'unsigned.apk','-I',platform/'android.jar',
            '--manifest',tmp/'AndroidManifest.xml','-A',ROOT/'app/src/main/assets',
            '--min-sdk-version','28','--target-sdk-version','35','--version-code','25',
            '--version-name',VERSION,tmp/'resources.zip')
        with zipfile.ZipFile(tmp/'unsigned.apk','a',compression=zipfile.ZIP_DEFLATED) as archive:
            for f in sorted(dex.glob('*.dex')): archive.write(f,f.name)
        run(tools/'zipalign','-f','4',tmp/'unsigned.apk',tmp/'aligned.apk')
        apk=out/f'Trackpad-{VERSION}-test.apk'
        run(jdk/'bin/java','-jar',tools/'lib/apksigner.jar','sign','--ks',keystore,
            '--ks-key-alias','androiddebugkey','--ks-pass','pass:android','--key-pass','pass:android',
            '--out',apk,tmp/'aligned.apk')
        with (out/'signature-check.txt').open('w') as f:
            run(jdk/'bin/java','-jar',tools/'lib/apksigner.jar','verify','--verbose','--print-certs',apk,stdout=f)
        run(tools/'zipalign','-c','4',apk)
        with (out/'apk-info.txt').open('w') as f: run(tools/'aapt','dump','badging',apk,stdout=f)
        digest=hashlib.sha256(apk.read_bytes()).hexdigest()
        (out/'SHA256SUMS.txt').write_text(f'{digest}  {apk.name}\n')
        print('APK signed and verified:', apk)


if __name__ == '__main__': main()
