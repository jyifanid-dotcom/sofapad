#!/usr/bin/env python3
"""Exercise actual saved endpoint restore code using the SDK interface and fake preferences.
Does not claim an AndroidKeyStore encryption/device test.
"""
import argparse,os,subprocess,tempfile
from pathlib import Path
root=Path(__file__).resolve().parents[1]
p=argparse.ArgumentParser();p.add_argument('--jdk',required=True,type=Path);p.add_argument('--platform',required=True,type=Path);args=p.parse_args()
java=r'''import cc.trackpad.tablet.*;import android.content.SharedPreferences;import java.util.*;import java.lang.reflect.*;
public class StoreCheck{
 static SharedPreferences prefs(String url,String saved){return (SharedPreferences)Proxy.newProxyInstance(StoreCheck.class.getClassLoader(),new Class[]{SharedPreferences.class},(proxy,method,a)->{if(method.getName().equals("getString"))return a[0].equals("url")?url:a[0].equals("lanOrigins")?saved:a[1];throw new AssertionError("unexpected preference access");});}
 public static void main(String[] a)throws Exception{
 List<String> restored=PairingStore.origins(prefs("http://192.168.50.10:8765","http://192.168.50.10:8765\nhttp://192.168.50.10:8765\nhttp://10.50.0.10:8765"));
 if(restored.size()!=2||!restored.get(0).contains("192.168.50.10")||!restored.get(1).contains("10.50.0.10"))throw new AssertionError("saved endpoints not restored/deduplicated");
 if(PairingStore.origins(prefs("http://192.168.50.10:8765","")).size()!=1)throw new AssertionError("old saved pairing incompatible");
 for(String bad:new String[]{"http://evil.example:8765","https://192.168.50.10:8765","http://user@192.168.50.10:8765"}){boolean refused=false;try{PairingStore.origins(prefs("http://192.168.50.10:8765",bad));}catch(Exception e){refused=true;}if(!refused)throw new AssertionError("unvalidated restored endpoint accepted");}
 System.out.println("Saved pairing endpoint restoration passed: reachable-first, fallback retention, deduplication, old-record compatibility and invalid endpoint refusal. AndroidKeyStore not exercised.");
 }}'''
with tempfile.TemporaryDirectory(prefix='trackpad-store-check-') as folder:
 t=Path(folder);(t/'StoreCheck.java').write_text(java);src=root/'app/src/main/java/cc/trackpad/tablet';sdk=args.platform/'android.jar'
 subprocess.run([str(args.jdk/'bin/javac'),'--release','17','-encoding','UTF-8','-cp',str(sdk),'-d',str(t/'classes'),str(src/'PairingStore.java'),str(src/'LanConnection.java'),str(t/'StoreCheck.java')],check=True)
 subprocess.run([str(args.jdk/'bin/java'),'-cp',str(t/'classes')+os.pathsep+str(sdk),'StoreCheck'],check=True)
