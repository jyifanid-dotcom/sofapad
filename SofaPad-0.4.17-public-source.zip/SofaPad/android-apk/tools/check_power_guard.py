#!/usr/bin/env python3
"""Briefly verify this process's real macOS idle-sleep assertion, always releasing it."""
import os,subprocess,sys
from pathlib import Path
sys.dont_write_bytecode=True
sys.path.insert(0,str(Path(__file__).resolve().parents[2]))
from trackpad_power import IdleSleepGuard
label='TabletTrackpad active LAN controller'
def own_assertions():
 text=subprocess.check_output(['/usr/bin/pmset','-g','assertions'],text=True,timeout=5)
 return [line for line in text.splitlines() if 'pid '+str(os.getpid())+'(' in line and label in line]
guard=IdleSleepGuard();assert not guard.active
try:
 assert guard.acquire() and guard.active,'IOPM assertion acquisition failed'
 identifier=guard._assertion
 assert guard.acquire() and guard._assertion==identifier,'repeated acquire must not leak assertions'
 assert own_assertions(),'own process assertion missing from pmset'
finally:guard.release()
assert not guard.active and not own_assertions(),'own idle assertion not released'
guard.release()
print('Power guard passed: actual macOS IOPM assertion visible for this test PID, idempotent acquire/release and absent afterward. No display assertion or persistent setting change; no input injected.')
