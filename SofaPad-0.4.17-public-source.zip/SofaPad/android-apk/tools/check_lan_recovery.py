#!/usr/bin/env python3
"""Actual Java client cancellation and delayed writer race; temporary sockets/fake output."""
import argparse,subprocess,tempfile
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--jdk',type=Path,required=True);p.add_argument('--source',type=Path);p.add_argument('--expect-old',action='store_true');args=p.parse_args()
root=Path(__file__).resolve().parents[2]
java=r'''import cc.trackpad.tablet.LanConnection;import java.io.*;import java.net.*;import java.lang.reflect.*;import java.util.concurrent.*;import java.util.concurrent.atomic.*;
public class RecoveryCheck{
 static void set(Object o,String n,Object v)throws Exception{Field f=LanConnection.class.getDeclaredField(n);f.setAccessible(true);f.set(o,v);}
 static Object get(Object o,String n)throws Exception{Field f=LanConnection.class.getDeclaredField(n);f.setAccessible(true);return f.get(o);}
 static LanConnection client(String url,AtomicInteger auth)throws Exception{return new LanConnection(url,"a".repeat(32),"trackpad-device="+"x".repeat(40),new LanConnection.Listener(){public void changed(String m,boolean c){}public void pairingRequired(){auth.incrementAndGet();}});}
 static class Sink extends Socket{volatile boolean closed;public void close(){closed=true;}public OutputStream getOutputStream(){return new ByteArrayOutputStream();}}
 static class Blocked extends Sink{CountDownLatch entered=new CountDownLatch(1),fail=new CountDownLatch(1);public OutputStream getOutputStream(){return new OutputStream(){public void write(int b)throws IOException{entered.countDown();try{if(!fail.await(3,TimeUnit.SECONDS))throw new IOException("test timeout");}catch(InterruptedException e){throw new IOException(e);}throw new IOException("old socket failed");}};}}
 public static void main(String[] args)throws Exception{
 boolean old=Boolean.parseBoolean(args[0]);AtomicInteger auth=new AtomicInteger();
 try(ServerSocket server=new ServerSocket(0,1,InetAddress.getByName("127.0.0.1"))){server.setSoTimeout(3000);LanConnection c=client("http://127.0.0.1:"+server.getLocalPort(),auth);c.start();try(Socket probe=server.accept()){
 c.stop();boolean stopped=((ExecutorService)get(c,"workers")).awaitTermination(800,TimeUnit.MILLISECONDS);if(old){if(stopped)throw new AssertionError("expected old uncancellable probe");}else{if(!stopped)throw new AssertionError("stopped identity probe still blocks retry worker");probe.setSoTimeout(800);int r;try{while((r=probe.getInputStream().read())>=0){}}catch(SocketException e){}if(auth.get()!=0)throw new AssertionError("stop emitted obsolete pairing-required callback");}
 }finally{c.stop();}}
 LanConnection c=client("http://127.0.0.1:8765",auth);Blocked a=new Blocked();Sink b=new Sink();
 try{set(c,"active",true);set(c,"ready",true);set(c,"connectionGeneration",1L);set(c,"socket",a);c.send("{\"heartbeat\":true}");if(!a.entered.await(2,TimeUnit.SECONDS))throw new AssertionError("writer did not enter old socket");set(c,"socket",b);set(c,"connectionGeneration",2L);a.fail.countDown();((ExecutorService)get(c,"outgoing")).submit(()->{}).get(2,TimeUnit.SECONDS);
 if(old){if(!b.closed)throw new AssertionError("expected old writer to close new socket");}else{if(b.closed||!a.closed)throw new AssertionError("late old writer damaged replacement socket");}
 }finally{a.fail.countDown();c.stop();}
 if(old)System.out.println("REPRODUCED 0.4.14: stop leaves identity probe blocked; delayed old writer failure closes the replacement socket. Controlled Java sockets/output, no Mac input.");
 else{if(!LanConnection.failureMessage(new SocketTimeoutException()).contains("超时")||!LanConnection.failureMessage(new ConnectException()).contains("端口")||!LanConnection.failureMessage(new NoRouteToHostException()).contains("网络"))throw new AssertionError("failure causes hidden");System.out.println("Native recovery passed: stop cancels blocked identity socket promptly, no stale auth callback, delayed failed writer closes only its captured old socket, distinct timeout/port/route diagnostics. No Mac input.");}
 }}'''
with tempfile.TemporaryDirectory(prefix='trackpad-java-recovery-') as folder:
 t=Path(folder);source=args.source or root/'android-apk/app/src/main/java/cc/trackpad/tablet/LanConnection.java'
 (t/'LanConnection.java').write_bytes(source.read_bytes());(t/'RecoveryCheck.java').write_text(java)
 subprocess.run([str(args.jdk/'bin/javac'),'--release','17','-encoding','UTF-8','-d',str(t/'classes'),str(t/'LanConnection.java'),str(t/'RecoveryCheck.java')],check=True)
 subprocess.run([str(args.jdk/'bin/java'),'-cp',str(t/'classes'),'RecoveryCheck',str(args.expect_old).lower()],check=True,timeout=20)
