/* Real enrollment script with virtual polling and controlled cookie persistence. */
const cp=require('node:child_process'),vm=require('node:vm'),assert=require('node:assert/strict'),path=require('node:path');
const source=process.argv[2]||path.join(__dirname,'../../trackpad_security.py');
const html=cp.execFileSync('python3',['-c',"import importlib.util,sys; s=importlib.util.spec_from_file_location('home_test',sys.argv[1]);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);print(m.home_pair_page())",source],{encoding:'utf8'});
const script=[...html.matchAll(/<script>([\s\S]*?)<\/script>/g)][0][1];
const ticket='T'.repeat(43);
function fixture(state,storage=new Map()){
 let now=1700000000000,id=0;const timers=new Map(),ids={},redirects=[],calls=[];
 const c={console,Promise,JSON,URL,Math,Date:{now:()=>now},navigator:{userAgent:state.legacy?'Mozilla/5.0 (iPad; CPU OS 12_0 like Mac OS X) AppleWebKit/605.1.15 Version/12.1.2 Mobile Safari/604.1':'Macintosh',maxTouchPoints:5},location:{origin:'http://192.168.50.10',replace:v=>redirects.push(v)},
 document:{getElementById:n=>ids[n]||={textContent:'',style:{},disabled:false,value:''}},sessionStorage:{getItem:k=>storage.get(k)||null,setItem:(k,v)=>storage.set(k,v)},
 setTimeout:(fn,delay)=>{timers.set(++id,{fn,at:now+delay,delay});return id;},clearTimeout:n=>timers.delete(n),
 fetch:async(p,o)=>{calls.push({path:p,body:o.body?JSON.parse(o.body):null});let body,code=200;
 if(p==='/api/session'){const accepted=state.cookie&&!(state.legacy&&state.strictCookie);code=accepted?200:401;body=accepted?{ok:true,busy:!!state.busy,controllerName:'iPhone'}:{ok:false};}
 else if(p==='/api/home/request'){
  const v=JSON.parse(o.body);if(!v.ticket){state.created++;state.pending=true;}else assert.equal(v.ticket,ticket,'resume preserves ticket');
  body={ticket,number:'123456',expiresIn:300};state.label=v.name;
 }else if(p==='/api/home/claim'){
  if(state.approved){body={ok:true};if(!state.blockCookies)state.cookie=true;state.pending=false;}else body={pending:true};
 }else throw Error(p);
 return{status:code,ok:code===200,json:async()=>body,text:async()=>JSON.stringify(body)};}};
 Object.defineProperty(c,'status',{get:()=>'',set:()=>{},configurable:true}); // Actual Window.status is a string property.
 vm.createContext(c);vm.runInContext(script,c);
 async function flush(){for(let i=0;i<30;i++)await Promise.resolve();}
 async function poll(){now+=2000;const tasks=[...timers].filter(([n,t])=>t.delay===2000&&t.at<=now);assert(tasks.length,'poll expected');for(const [n,t]of tasks){timers.delete(n);t.fn();}await flush();}
 return{c,ids,storage,redirects,calls,flush,poll};
}
(async()=>{
 const s={created:0,cookie:false,busy:true,approved:false};const f=fixture(s);await f.flush();f.ids.request.onclick();await f.flush();
 assert.equal(s.created,1);assert.equal(s.label,'iPad 主屏幕');assert(f.ids.status.textContent.includes('123456'));
 s.approved=true;await f.poll();assert.equal(s.created,1);assert(f.ids.status.textContent.includes('已配对并记住'));assert(f.ids.status.textContent.includes('iPhone'));assert.equal(f.redirects.length,0,'busy phone must not be confused with missing pairing');
 s.busy=false;await f.poll();assert.deepEqual(f.redirects,['/']);
 const blocked={created:0,cookie:false,busy:false,approved:true,blockCookies:true};const b=fixture(blocked);await b.flush();b.ids.request.onclick();await b.flush();await b.poll();
 assert.equal(b.redirects.length,0,'missing cookie must never redirect back into enrollment');assert(b.ids.status.textContent.includes('没有保存连接记录'));assert.equal(blocked.created,1);
 b.ids.request.onclick();await b.flush();assert.equal(blocked.created,1,'recheck cannot create another authorization');
 const reloadBlocked=fixture(blocked,b.storage);await reloadBlocked.flush();assert.equal(blocked.created,1,'reload preserves cookie failure and never silently requests approval');
 const pending={created:0,cookie:false,busy:false,approved:false};const first=fixture(pending);await first.flush();first.ids.request.onclick();await first.flush();
 const restored=fixture(pending,first.storage);await restored.flush();assert.equal(pending.created,1,'refresh resumes the same pending request');assert(restored.ids.status.textContent.includes('123456'));
 pending.approved=true;await restored.poll();assert.deepEqual(restored.redirects,['/']);assert.equal(pending.created,1);
 const remembered={created:0,cookie:true,busy:false};const rememberedPage=fixture(remembered);await rememberedPage.flush();assert.deepEqual(rememberedPage.redirects,['/']);assert.equal(remembered.created,0,'remembered device does not create a pending authorization');
 const legacy={created:0,cookie:true,busy:false,legacy:true,strictCookie:true};
 const legacyStorage=new Map([['trackpad-home-request',JSON.stringify({pending:null,cookieFailure:true})]]);
 const oldSafari=fixture(legacy,legacyStorage);await oldSafari.flush();assert.deepEqual(oldSafari.redirects,['/session/continue'],'iOS 12 uses a top-level cookie recovery before reauthorization');assert.equal(legacy.created,0,'old Strict cookie recovery does not create another authorization');
 assert.equal(oldSafari.c.status,'','page state must not overwrite Window.status');
 console.log('iOS12 top-level recovery and Window.status isolation passed; no new authorization requested.');
 console.log('Home page checks passed: iPad desktop UA, active phone standby, verified cookie before redirect, cookie-failure loop prevention, same-ticket resume and remembered-device reuse. Controlled fetch/storage only.');
})().catch(e=>{console.error(e);process.exitCode=1;});
// The QR path must also verify the HttpOnly cookie before redirecting.
const pairHtml=cp.execFileSync('python3',['-c',"import importlib.util,sys;s=importlib.util.spec_from_file_location('qr_test',sys.argv[1]);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);print(m.pair_page())",source],{encoding:'utf8'});
const pairScript=[...pairHtml.matchAll(/<script>([\s\S]*?)<\/script>/g)][0][1];
async function qrFixture(blocked){
 const capsule={origin:'http://192.168.50.10',receiver:'1'.repeat(32),code:'x'.repeat(32)};let cookie=false;const status={},redirects=[];
 const c={console,Promise,JSON,URL,navigator:{userAgent:'iPad'},atob:v=>Buffer.from(v,'base64').toString('binary'),location:{origin:capsule.origin,pathname:'/pair',hash:'#'+Buffer.from(JSON.stringify(capsule)).toString('base64url'),replace:v=>redirects.push(v)},history:{replaceState(){}},document:{getElementById:()=>status},
 fetch:async(p)=>{if(p==='/api/pair'){cookie=!blocked;return{ok:true};}return{ok:cookie};}};
 vm.createContext(c);vm.runInContext(pairScript,c);for(let i=0;i<20;i++)await Promise.resolve();return{redirects,status};
}
(async()=>{const good=await qrFixture(false);assert.deepEqual(good.redirects,['/'],good.status.textContent);const bad=await qrFixture(true);assert.equal(bad.redirects.length,0);assert(bad.status.textContent.includes('没有保存连接记录'));console.log('QR cookie verification passed: saved session opens the pad; missing cookie stops with a diagnostic instead of redirecting into enrollment.');})().catch(e=>{console.error(e);process.exitCode=1;});
