/* Real page/bridge lifecycle, controlled sockets and virtual time; no network/input. */
const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict'),path=require('node:path');
const cp=require('node:child_process');
const source=process.argv[2]||path.join(__dirname,'../../trackpad.py');
const html=JSON.parse(cp.execFileSync('python3',['-c',"import ast,json,sys; t=ast.parse(open(sys.argv[1]).read()); print(json.dumps(next(ast.literal_eval(n.value) for n in t.body if isinstance(n,ast.Assign) and any(isinstance(v,ast.Name) and v.id=='PAGE' for v in n.targets))))",source],{encoding:'utf8'}));
const browserScript=[...html.matchAll(/<script>([\s\S]*?)<\/script>/g)][0][1];
const uiScript=fs.readFileSync(path.join(__dirname,'../app/src/main/assets/app-ui.js'),'utf8');
class Element{
 constructor(){this.events={};this.style={setProperty(k,v){this[k]=v;}};this.children=[];this.value='';this.offsetHeight=196;const s=new Set();this.classList={add:x=>s.add(x),remove:x=>s.delete(x),contains:x=>s.has(x),toggle:(x,on)=>{on=on===undefined?!s.has(x):!!on;on?s.add(x):s.delete(x);return on;}};}
 addEventListener(n,fn,options){(this.events[n]||=[]).push({fn,capture:options===true});}
 emit(n,e={}){e.preventDefault||=()=>{};e.stopImmediatePropagation=()=>{};for(const h of [...(this.events[n]||[])].sort((a,b)=>b.capture-a.capture))h.fn(e);}
 getBoundingClientRect(){return{left:0,top:0,width:1000,height:this.id==='padCommandStrip'?80:700,right:1000,bottom:this.id==='padCommandStrip'?80:700};}
 appendChild(e){this.children.push(e);e.parentNode=this;}removeChild(e){this.children=this.children.filter(v=>v!==e);e.parentNode=null;}
 setAttribute(){}getAttribute(){return null;}setPointerCapture(){}focus(){}blur(){}
}
function fixture(options={}){
 let now=0,id=0;const timeouts=new Map(),intervals=new Map(),rafs=new Map(),sockets=[],ids={},we={},de={};
 class WS{constructor(url){this.url=url;if(options.throwWS){options.throwWS=false;throw Error('CSP construction blocked');}this.readyState=0;this.bufferedAmount=0;this.sent=[];this.closeCalls=0;sockets.push(this);}send(s){assert.equal(this.readyState,1);this.sent.push(JSON.parse(s));}close(){this.closeCalls++;this.readyState=2;}open(){this.readyState=1;this.onopen?.();}finish(){this.readyState=3;this.onclose?.();}}
 const document={hidden:false,body:new Element(),head:new Element(),documentElement:new Element(),getElementById:n=>ids[n]||=new Element(),createElement:()=>new Element(),querySelectorAll:()=>[],addEventListener:(n,f)=>(de[n]||=[]).push(f)};
 const c={document,console,Map,JSON,Math,Promise,performance:{now:()=>now},innerWidth:1200,innerHeight:800,navigator:{userAgent:options.ua||'iPhone',standalone:options.standalone!==false,maxTouchPoints:options.maxTouchPoints||0},screen:options.screen,location:{protocol:'https:',host:'test.local'},WebSocket:WS,PointerEvent:function(){},
 setTimeout:(fn,delay)=>{const n=++id;timeouts.set(n,{fn,at:now+delay});return n;},clearTimeout:n=>timeouts.delete(n),setInterval:(fn,delay)=>{const n=++id;intervals.set(n,{fn,delay});return n;},clearInterval:n=>intervals.delete(n),requestAnimationFrame:fn=>{rafs.set(++id,fn);return id;},cancelAnimationFrame:n=>rafs.delete(n),addEventListener:(n,f)=>(we[n]||=[]).push(f)};
 if(options.nativeTablet!==undefined)c.TrackpadNative={isTablet:()=>options.nativeTablet,send(){}};if(options.legacyTouch)delete c.PointerEvent;c.window=c;vm.createContext(c);vm.runInContext(browserScript,c);vm.runInContext(uiScript,c);
 function pointer(n,pid,x=500){ids.pad.emit(n,{pointerType:'touch',pointerId:pid,isPrimary:true,clientX:x,clientY:350,width:30,height:30});}
 function frame(){now+=16;const list=[...rafs.values()];rafs.clear();list.forEach(f=>f(now));}
 function advance(ms){now+=ms;for(const [n,t]of [...timeouts])if(t.at<=now){timeouts.delete(n);t.fn();}}
 function hidden(v){document.hidden=v;for(const f of de.visibilitychange||[])f();}
 return{c,sockets,pointer,frame,advance,hidden,intervals,rafs};
}
const f=fixture();assert.equal(f.sockets.length,1);const first=f.sockets[0];first.open();
f.pointer('pointerdown',1,200);f.frame();first.finish();
f.pointer('pointerdown',2,800);f.pointer('pointermove',2,850);f.frame();
assert.equal(f.c.touches.size,0,'offline fingers must never be retained for reconnect');
f.advance(800);assert.equal(f.sockets.length,2);const second=f.sockets[1];second.open();f.frame();
assert.equal(f.c.touches.size,0,'reconnect starts with no contacts');
assert.equal(f.intervals.size,1,'one heartbeat after reconnect');
f.pointer('pointermove',2,900);f.frame();assert(!second.sent.some(m=>m.p?.length),'finger held across disconnect must not resume until a new down');
f.pointer('pointerup',2,900);f.pointer('pointerdown',3,600);f.frame();assert(second.sent.some(m=>m.p?.length===1&&m.p[0][0]===3),'fresh contact works after reconnect');
for(let i=0;i<5;i++){
 const old=f.sockets.at(-1);old.finish();f.advance(800);f.sockets.at(-1).open();
 assert.equal(f.intervals.size,1,'repeated reconnect cannot accumulate heartbeats');
}
const old=f.sockets.at(-1);f.hidden(true);assert.equal(old.closeCalls,1,'background closes the actual transport');assert.equal(f.intervals.size,0,'background removes heartbeat immediately');
f.hidden(false);assert.equal(f.sockets.length,8,'foreground creates exactly one fresh connection');
const fresh=f.sockets.at(-1);old.onclose();old.onmessage({data:JSON.stringify({status:{inputReady:false}})});old.onerror();fresh.open();
assert.equal(f.intervals.size,1,'late old callbacks do not alter the new connection timer');
const before=f.sockets.length;f.hidden(false);assert.equal(f.sockets.length,before,'duplicate visible notification cannot orphan an open socket');
const pending=fixture(),connecting=pending.sockets[0];pending.hidden(true);
assert.equal(connecting.closeCalls,1,'background also closes a connecting socket');pending.hidden(false);assert.equal(pending.sockets.length,2);
connecting.open();assert.equal(pending.intervals.size,0,'late open cannot start an orphan heartbeat');
pending.sockets[1].open();assert.equal(pending.intervals.size,1);
// Legacy Safari paths: no PointerEvent, regular browser, failed/hung handshake.
const ipad=fixture({ua:'Mozilla/5.0 (iPad; CPU OS 12_0 like Mac OS X) AppleWebKit/605.1.15 Version/12.1 Mobile Safari/604.1',standalone:false,legacyTouch:true,screen:{width:768,height:1024}});
assert.equal(ipad.sockets.length,0);assert(ipad.c.document.body.classList.contains('tablet-bar'));assert.equal(ipad.c.document.documentElement.style['--touchbar-top'],'108px');
ipad.c.trackpadStart(true);assert.equal(ipad.sockets.length,1);ipad.sockets[0].open();
const touch={identifier:21,clientX:500,clientY:350,radiusX:15,radiusY:15};
ipad.c.padEl.emit('touchstart',{changedTouches:[touch],touches:[touch]});ipad.c.padEl.emit('touchend',{changedTouches:[touch],touches:[]});
assert.deepEqual(ipad.sockets[0].sent.filter(m=>m.p).slice(-2).map(m=>m.p.length),[1,0],'iOS12 touch fallback preserves tap boundaries');
const phone=fixture({screen:{width:390,height:844}});assert.equal(phone.c.document.documentElement.style['--touchbar-top'],'80px');assert(!phone.c.document.body.classList.contains('tablet-bar'),'phone Bar dimensions stay unchanged');
const androidPhone=fixture({ua:'Android Mobile',screen:{width:412,height:915}});assert(!androidPhone.c.document.body.classList.contains('tablet-bar'));
const androidTablet=fixture({ua:'Android Tablet',screen:{width:1280,height:800}});assert(androidTablet.c.document.body.classList.contains('tablet-bar'));
const desktopIpad=fixture({ua:'Macintosh',maxTouchPoints:5,screen:{width:1024,height:768}});assert(desktopIpad.c.document.body.classList.contains('tablet-bar'));
const nativeTablet=fixture({nativeTablet:true,screen:{width:400,height:640}});assert(nativeTablet.c.document.body.classList.contains('tablet-bar'),'native Android tablet flag beats narrow WebView/IME viewport');const nativePhone=fixture({nativeTablet:false,screen:{width:1200,height:800}});assert(!nativePhone.c.document.body.classList.contains('tablet-bar'),'native Android phone flag beats wide default viewport');
const hung=fixture();hung.advance(8000);assert.equal(hung.sockets[0].closeCalls,1,'hung handshake must close even without a browser close event');hung.advance(800);assert.equal(hung.sockets.length,2,'hung handshake retries');hung.sockets[0].finish();hung.sockets[1].open();assert.equal(hung.intervals.size,1,'late close cannot interrupt current session');
const blocked=fixture({throwWS:true});assert.equal(blocked.sockets.length,0);blocked.advance(800);assert.equal(blocked.sockets.length,1,'constructor exceptions do not leave on=true permanently disconnected');
const manual=fixture({standalone:false});manual.c.on=true;manual.c.trackpadStart(true);assert.equal(manual.sockets.length,1,'start retries an idle session even when on was already set');manual.c.trackpadStart(true);assert.equal(manual.sockets.length,1);
assert(uiScript.includes('body.tablet-bar #touchbar:not(.collapsed){height:68px}'));
assert(uiScript.includes('body.iphone #touchbar button{height:32px'));
assert(uiScript.includes('background-color:rgba(253,252,249,.995)!important;'));assert(!uiScript.includes('ellipse at 16% 0'));
console.log('iOS12 touch fallback, tablet-only Bar, failed construction, bounded handshake and manual retry checks passed.');
console.log('Reconnect regressions passed: offline contact rejection, fresh-contact resume, repeated reconnect, one heartbeat, background/foreground, connecting abort and stale callbacks.');
(async()=>{
 const probe=fixture();probe.sockets[0].open();probe.c.fetch=()=>new Promise(()=>{});probe.sockets[0].finish();probe.advance(800);
 assert.equal(probe.sockets.length,2,'unanswered session probe cannot block reconnect');
 const revoked=fixture();revoked.sockets[0].open();revoked.c.fetch=()=>Promise.resolve({status:401});revoked.sockets[0].finish();await Promise.resolve();await Promise.resolve();revoked.advance(16000);
 assert.equal(revoked.sockets.length,1,'revoked pairing stops automatic reconnect');
 const reset=fixture(),sock=reset.sockets[0];sock.open();reset.pointer('pointerdown',1,200);reset.frame();
 sock.onmessage({data:JSON.stringify({inputReset:'timing reset'})});assert.equal(reset.c.touches.size,0,'server reset clears current contacts');
 reset.pointer('pointermove',1,900);reset.frame();assert(!reset.c.touches.size,'same held finger cannot revive an interrupted stroke');
 reset.pointer('pointerup',1,900);reset.pointer('pointerdown',2,300);reset.frame();assert.equal(reset.c.touches.size,1,'fresh down works after timing reset');
 const watchdog=fixture();watchdog.sockets[0].open();watchdog.pointer('pointerdown',1);watchdog.advance(13000);
 for(const timer of [...watchdog.intervals.values()])timer.fn();
 assert.equal(watchdog.sockets[0].closeCalls,1,'unresponsive peer closes without replay');assert.equal(watchdog.c.touches.size,0);
 const live=fixture();live.sockets[0].open();
 for(let i=0;i<20;i++){live.advance(4000);live.sockets[0].onmessage({data:'{"alive":true}'});for(const timer of [...live.intervals.values()])timer.fn();}
 assert.equal(live.sockets[0].closeCalls,0,'healthy heartbeats keep the same connection open');
 console.log('Recovery checks passed: hung probe fallback, revoked session stop, server input reset, fresh-down gate, liveness watchdog and healthy heartbeat endurance.');
})().catch(e=>{console.error(e);process.exitCode=1;});

const marker=fixture();marker.c.trackpadStart(false);const markerId=marker.c.connectionClientId;assert.match(markerId,/^[a-f0-9]{32}$/);assert(marker.sockets[0].url.endsWith('/ws?client='+markerId));marker.sockets[0].open();marker.sockets[0].finish();marker.advance(2000);assert(marker.sockets[1].url.endsWith('/ws?client='+markerId),'retry keeps same client instance');const separate=fixture();assert.notEqual(separate.c.connectionClientId,markerId,'different tabs cannot take over each other');console.log('Client instance checks passed: same browser page retries retain ID, separate tabs differ.');
