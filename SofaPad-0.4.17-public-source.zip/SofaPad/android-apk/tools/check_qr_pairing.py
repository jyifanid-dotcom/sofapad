#!/usr/bin/env python3
"""Mac's actual QR generator -> APK's actual QR decoder/validation, no camera or real Mac input."""
import argparse,base64,json,os,subprocess,sys,tempfile
from pathlib import Path
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from trackpad_security import SecureReceiver
from vendor.qrcodegen import QrCode
parser=argparse.ArgumentParser();parser.add_argument('--jdk',required=True,type=Path);args=parser.parse_args()
with tempfile.TemporaryDirectory(prefix='trackpad-qr-check-') as folder:
 p=Path(folder);sec=SecureReceiver(p/'state',names=['192.168.50.10','192.168.50.10','10.50.0.10'],port=8765,bootstrap_port=0)
 capsule=sec.capsule('192.168.50.10');payload=base64.urlsafe_b64decode(capsule+'='*(-len(capsule)%4));value=json.loads(payload)
 assert value['origin']=='http://192.168.50.10:8765' and value['origins']==['http://10.50.0.10:8765']
 assert set(value)=={'origin','origins','receiver','code'} and len(sec.codes)==1
 (p/'payload').write_bytes(payload)
 java=r'''import cc.trackpad.tablet.*;import java.nio.file.*;import java.util.*;
 public class QrCheck{
 static void check(boolean b,String m){if(!b)throw new AssertionError(m);}
 static void reject(String link)throws Exception{boolean bad=false;try{PairingRequest.payload(link);}catch(Exception e){bad=true;}check(bad,"invalid envelope accepted");}
 public static void main(String[] a)throws Exception{
 String link=a[0];int size=Integer.parseInt(a[2]);byte[] gray=Files.readAllBytes(Path.of(a[1]));String decoded=new QrDecoder().decode(gray,size,size);
 check(link.equals(decoded),"Mac QR decoding failed");check(Arrays.equals(PairingRequest.payload(decoded).getBytes(java.nio.charset.StandardCharsets.UTF_8),Files.readAllBytes(Path.of(a[3]))),"QR payload changed");
 List<String> endpoints=PairingRequest.origins(link,"http://192.168.50.10:8765",List.of("http://192.168.50.10:8765","http://10.50.0.10:8765"));
 check(endpoints.size()==2&&endpoints.get(0).equals("http://192.168.50.10:8765")&&endpoints.get(1).contains("10.50.0.10"),"Android DNS fallback order");
 PairingRequest.secrets("a".repeat(32),"B".repeat(32));boolean refused=false;try{PairingRequest.secrets("a", "bad");}catch(Exception e){refused=true;}check(refused,"invalid secrets");
 refused=false;try{PairingRequest.origins(link,"http://192.168.50.10:8765",List.of("http://evil.example:8765"));}catch(Exception e){refused=true;}check(refused,"public fallback accepted");
 refused=false;try{PairingRequest.origins(link,"http://192.168.50.10:8765",List.of("http://192.168.50.10:9999"));}catch(Exception e){refused=true;}check(refused,"port change accepted");
 String hash=link.substring(link.indexOf('#'));reject("https://192.168.50.10:8765/pair"+hash);reject("http://evil.example:8765/pair"+hash);reject("trackpad://pair?x=1"+hash);reject("trackpad://pair:80"+hash);reject("trackpad://attacker@pair"+hash);reject("http://192.168.50.10:8765/ca.cer"+hash);
 refused=false;try{PairingRequest.origins("http://other.local:8765/pair"+hash,"http://192.168.50.10:8765",List.of());}catch(Exception e){refused=true;}check(refused,"mismatched web QR authority accepted");
 check(new QrDecoder().decode(new byte[100],20,20)==null,"short luma buffer accepted");System.out.println("offline QR and pairing validation passed");
 }}'''
 (p/'QrCheck.java').write_text(java)
 lib=ROOT/'android-apk/app/libs/zxing-core-3.5.3.jar';src=ROOT/'android-apk/app/src/main/java/cc/trackpad/tablet'
 subprocess.run([str(args.jdk/'bin/javac'),'--release','17','-encoding','UTF-8','-cp',str(lib),'-d',str(p/'classes'),*[str(src/n) for n in ['LanConnection.java','QrDecoder.java','PairingRequest.java']],str(p/'QrCheck.java')],check=True)
 # Same independent encoder used for QR codes displayed by the actual Mac receiver.
 for scheme in ['trackpad://pair#','http://192.168.50.10:8765/pair#']:
  link=scheme+capsule;qr=QrCode.encode_text(link,QrCode.Ecc.MEDIUM);scale=5;side=(qr.get_size()+8)*scale
  raw=bytearray(255 for _ in range(side*side))
  for y in range(qr.get_size()):
   for x in range(qr.get_size()):
    if qr.get_module(x,y):
     for dy in range(scale):
      start=((y+4)*scale+dy)*side+(x+4)*scale;raw[start:start+scale]=bytes(scale)
  cases={'normal':raw,'low-contrast':bytes(50 if n==0 else 210 for n in raw),'inverted':bytes(255-n for n in raw),'rotated':bytes(raw[(side-1-x)*side+y] for y in range(side) for x in range(side))}
  for name,data in cases.items():
   image=p/'frame';image.write_bytes(data)
   run=subprocess.run([str(args.jdk/'bin/java'),'-cp',str(p/'classes')+os.pathsep+str(lib),'QrCheck',link,str(image),str(side),str(p/'payload')],capture_output=True,text=True,timeout=10)
   assert run.returncode==0,name+': '+run.stderr
 print('QR checks passed: actual Mac web/APK QR encoding -> actual APK offline decoder; normal, rotated, inverted and low-contrast frames; local-only validated endpoints, IPv4 fallback order, malformed/public/mismatched QR rejection. Camera hardware not exercised.')
