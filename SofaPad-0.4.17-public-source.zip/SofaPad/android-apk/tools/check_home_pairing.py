#!/usr/bin/env python3
"""Home Screen authorization contract; no real Mac input, no production state."""
import hashlib,json,sys,tempfile,time
from pathlib import Path
sys.dont_write_bytecode=True
sys.path.insert(0,str(Path(__file__).resolve().parents[2]))
from trackpad_security import SecureReceiver,COOKIE,home_pair_page
class Capture:
    def __init__(self):self.data=b''
    def sendall(self,b):self.data+=b
with tempfile.TemporaryDirectory(prefix='trackpad-home-test-') as folder:
    sec=SecureReceiver(folder,names=['127.0.0.1'],bootstrap_port=0)
    h={'host':'127.0.0.1:8765','origin':'http://127.0.0.1:8765','content-type':'application/json'}
    def post(path,data,headers=h):
        c=Capture();sec.route(c,'POST',path,headers,json.dumps(data).encode(),'test-home');return c.data
    req=post('/api/home/request',{'name':'iPhone 主屏幕'})
    d=json.loads(req.split(b'\r\n\r\n',1)[1]);assert len(d['number'])==6
    assert d['ticket'] not in json.dumps(sec.pending)
    assert sec.claim_home(d['ticket'],'test-home') is None
    pending=sec.pending_devices();assert len(pending)==1 and pending[0]['number']==d['number']
    assert b'403' in post('/api/home/request',{},dict(h,origin='http://evil.test'))[:30]
    assert b'403' in post('/api/home/claim',{'ticket':'bad'})[:30]
    sec.approve_home(pending[0]['id']);assert not sec.pending_devices()
    result=post('/api/home/claim',{'ticket':d['ticket']})
    assert b'HttpOnly; SameSite=Strict' in result
    cookie=result.split(b'Set-Cookie: ',1)[1].split(b'\r\n',1)[0].decode()
    ident=sec.authenticated({'cookie':cookie});assert ident
    assert b'403' in post('/api/home/claim',{'ticket':d['ticket']})[:30]
    restored=SecureReceiver(folder,names=['127.0.0.1'],bootstrap_port=0)
    assert restored.authenticated({'cookie':cookie})==ident
    restored.revoke(ident);assert restored.authenticated({'cookie':cookie}) is None
    req=sec.request_home('expired','other');sec.pending[hashlib.sha256(req['ticket'].encode()).hexdigest()]['expires']=time.time()-1
    try:sec.claim_home(req['ticket'],'other');raise AssertionError('expired accepted')
    except PermissionError:pass
    c=Capture();sec.route(c,'GET','/',{'host':'127.0.0.1:8765'},b'','home');assert b'401' in c.data[:30] and '连接这台 Mac'.encode() in c.data
    c=Capture();sec.route(c,'GET','/manifest.webmanifest',{'host':'127.0.0.1:8765'},b'','home');manifest=json.loads(c.data.split(b'\r\n\r\n',1)[1]);assert manifest['start_url']=='/' and manifest['display']=='standalone'
    # Request exhaustion is bounded and cannot silently enroll a device.
    for i in range(10):sec.request_home('pending',str(i))
    assert len(sec.devices)==1
print('Home pairing passed: explicit approval, same-origin checks, one-use claim, HttpOnly plaintext-session cookie, restart persistence, revocation, expiry, manifest; no Mac input.')

# A trusted second device remains paired while the first device owns the lease.
with tempfile.TemporaryDirectory(prefix='trackpad-two-devices-') as folder:
 sec=SecureReceiver(folder,names=['127.0.0.1'],bootstrap_port=0)
 cap=json.loads(__import__('base64').urlsafe_b64decode((value:=sec.capsule())+'='*(-len(value)%4)))
 phone_id,phone_token=sec.issue(cap['code'],'iPhone','phone')
 phone=Capture();assert sec.claim(phone_id,phone)
 h={'host':'127.0.0.1:8765','origin':'http://127.0.0.1:8765','content-type':'application/json'}
 def route(method,path,data=None,headers=h):
  c=Capture();sec.route(c,method,path,headers,json.dumps(data).encode() if data is not None else b'','ipad');return c.data
 def body(response):return json.loads(response.split(b'\r\n\r\n',1)[1])
 original=body(route('POST','/api/home/request',{'name':'iPad 主屏幕'}))
 resumed=body(route('POST','/api/home/request',{'name':'iPad 主屏幕','ticket':original['ticket']}))
 assert resumed['ticket']==original['ticket'] and resumed['number']==original['number'] and len(sec.pending)==1,'retry must reuse one Mac authorization request'
 pending_id=sec.pending_devices()[0]['id'];sec.approve_home(pending_id)
 resumed_after_approval=body(route('POST','/api/home/request',{'ticket':original['ticket']}))
 assert resumed_after_approval['number']==original['number'] and not sec.pending_devices(),'refresh after approval cannot create a new request'
 response=route('POST','/api/home/claim',{'ticket':original['ticket']})
 ipad_cookie=response.split(b'Set-Cookie: ',1)[1].split(b'\r\n',1)[0].decode();ipad_headers=dict(h,cookie=ipad_cookie)
 ipad_id=sec.authenticated(ipad_headers);assert ipad_id and ipad_id!=phone_id
 session=body(route('GET','/api/session',headers=ipad_headers))
 assert session['ok'] and session['busy'] and session['controllerName']=='iPhone' and not session['ownsControl'],'busy controller must not invalidate iPad pairing'
 before=len(sec.devices)
 repeat=body(route('POST','/api/home/request',{'name':'iPad'},ipad_headers));assert repeat['paired'] and not sec.pending and len(sec.devices)==before
 repeat_claim=body(route('POST','/api/home/claim',{'ticket':original['ticket']},ipad_headers));assert repeat_claim['paired'] and len(sec.devices)==before,'authenticated retry cannot issue a new credential'
 assert b'403' in route('POST','/api/home/claim',{'ticket':original['ticket']})[:30],'unauthenticated spent ticket still cannot be replayed'
 sec.release(phone)
 assert not body(route('GET','/api/session',headers=ipad_headers))['busy']
 assert sec.claim(ipad_id,Capture()),'iPad acquires the lease after phone releases, without reauthorization'
print('Two-device pairing checks passed: one pending ticket across retry/approval, persistent iPad cookie while phone is active, explicit standby state, no repeat enrollment, spent-ticket denial and lease handoff without reauthorization.')

# iOS 12 local-domain SameSite compatibility preserves the actual credential.
with tempfile.TemporaryDirectory(prefix='trackpad-ios12-cookie-') as folder:
 sec=SecureReceiver(folder,names=['127.0.0.1'],bootstrap_port=0)
 legacy_ua='Mozilla/5.0 (iPad; CPU OS 12_0 like Mac OS X) AppleWebKit/605.1.15 Version/12.1.2 Mobile Safari/604.1'
 modern_ua='Mozilla/5.0 (iPad; CPU OS 17_0 like Mac OS X) AppleWebKit/605.1.15 Version/17.0 Mobile Safari/604.1'
 h={'host':'127.0.0.1:8765','origin':'http://127.0.0.1:8765','content-type':'application/json','user-agent':legacy_ua}
 def call(method,path,data=None,headers=h):
  c=Capture();sec.route(c,method,path,headers,json.dumps(data).encode() if data is not None else b'','legacy-test');return c.data
 request=sec.request_home('iPad12','legacy-test');sec.approve_home(sec.pending_devices()[0]['id'])
 response=call('POST','/api/home/claim',{'ticket':request['ticket']})
 cookie=response.split(b'Set-Cookie: ',1)[1].split(b'\r\n',1)[0].decode()
 assert 'HttpOnly' in cookie and 'Secure' not in cookie and 'SameSite' not in cookie,'old WebKit omits only the incompatible SameSite attribute'
 auth=dict(h,cookie=cookie);ident=sec.authenticated(auth);assert ident
 before=len(sec.devices)
 resumed=call('GET','/session/continue',headers=auth)
 assert resumed.startswith(b'HTTP/1.1 303') and b'Location: /\r\n' in resumed and b'Set-Cookie:' in resumed and b'SameSite' not in resumed
 assert len(sec.devices)==before and sec.authenticated(auth)==ident,'recovery preserves the same approved identity'
 refreshed=sec.page_cookie_headers(auth)['Set-Cookie'];assert 'SameSite' not in refreshed
 assert 'SameSite=Strict' in sec.session_cookie('fixture',dict(h,**{'user-agent':modern_ua})),'modern Safari keeps Strict'
 assert 'SameSite=Strict' in sec.session_cookie('fixture',{}),'APK/native clients retain the original cookie policy'
 assert b'403' in call('POST','/api/home/request',{'name':'attack'},dict(auth,origin='http://evil.test'))[:30],'legacy compatibility does not permit cross-origin POST'
 assert b'403' in call('GET','/ws',headers=dict(auth,origin='http://evil.test'))[:30],'legacy compatibility does not permit foreign WebSockets'
 missing=call('GET','/session/continue')
 assert missing.startswith(b'HTTP/1.1 401') and b'Location:' not in missing,'failed recovery is a stable page, not a redirect loop'
 assert len(sec.devices)==before,'unauthenticated recovery cannot mint credentials'
print('iOS12 cookie checks passed: HttpOnly retained, Secure omitted for HTTP, only old WebKit omits SameSite, existing identity refreshed via top-level navigation, modern/native Strict preserved, Origin/WS guards and no enrollment on recovery failure.')
