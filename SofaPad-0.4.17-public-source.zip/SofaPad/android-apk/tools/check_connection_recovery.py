#!/usr/bin/env python3
"""Real HTTP/WS with delayed old-reader shutdown; all input and power assertions mocked."""
import argparse,ast,base64,hashlib,json,math,os,socket,struct,sys,tempfile,threading,time
from pathlib import Path
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from trackpad_security import SecureReceiver,MAX_BODY,COOKIE
p=argparse.ArgumentParser();p.add_argument('--expect-old',action='store_true');args=p.parse_args()
class Pad:
 def __init__(self):
  self.lock=threading.RLock();self.drag_down=self.dragging=self.drag_latched=False;self.last_tap_t=0;self.frames=[];self.releases=0;self.scroll_motion=type('Scroll',(),{'stop':lambda s:None})()
 def reset(self):self.drag_down=self.dragging=self.drag_latched=False;self.releases+=1
 def on_frame(self,*a):self.frames.append(a);self.drag_down=bool(a[0] and a[-1])
class Power:
 active=False;acquired=0;released=0
 def acquire(self):self.active=True;self.acquired+=1
 def release(self):self.active=False;self.released+=1
class DelayedReader:
 def __init__(self,conn,event):self.conn=conn;self.event=event
 def __getattr__(self,name):return getattr(self.conn,name)
 def recv(self,n):
  try:data=self.conn.recv(n)
  except OSError:
   self.event.wait(10);raise
  if not data:self.event.wait(10)
  return data
with tempfile.TemporaryDirectory(prefix='trackpad-recovery-') as folder:
 listener=socket.socket();listener.bind(('127.0.0.1',0));listener.listen(8);listener.settimeout(.1);port=listener.getsockname()[1]
 sec=SecureReceiver(folder,names=['127.0.0.1'],port=port,bootstrap_port=0);power=Power();sec.power=power;pad=Pad();old_done=threading.Event()
 names={'recv_exact','ws_handshake','ws_recv','ws_send_text','serve_client','InputFrameClock','reset_remote_input'};nodes=[n for n in ast.parse((ROOT/'trackpad.py').read_text()).body if isinstance(n,(ast.FunctionDef,ast.ClassDef)) and n.name in names]
 env={'time':time,'SECURITY':sec,'MAX_BODY':MAX_BODY,'PAD':pad,'socket':socket,'base64':base64,'hashlib':hashlib,'struct':struct,'json':json,'math':math,'os':os,'SELF_PATH':str(ROOT/'trackpad.py'),'PAGE':'isolated','MOD_MASK':0x1e0000,'WS_GUID':'258EAFA5-E914-47DA-95CA-C5AB0DC85B11','mouse_up':lambda *a:None,'type_text':lambda *a:None,'key_combo':lambda *a:None,'media_volume':lambda *a:None,'print':lambda *a,**k:None}
 exec(compile(ast.Module(body=nodes,type_ignores=[]),'recovery-receiver','exec'),env)
 running=True;threads=[]
 def serve():
  while running:
   try:conn,addr=listener.accept()
   except socket.timeout:continue
   except OSError:break
   if not threads:conn=DelayedReader(conn,old_done)
   t=threading.Thread(target=env['serve_client'],args=(conn,addr),daemon=True);threads.append(t);t.start()
 accept=threading.Thread(target=serve,daemon=True);accept.start()
 raw=sec.capsule();cap=json.loads(base64.urlsafe_b64decode(raw+'='*(-len(raw)%4)));ident,token=sec.issue(cap['code'],'phone','test')
 raw=sec.capsule();cap=json.loads(base64.urlsafe_b64decode(raw+'='*(-len(raw)%4)));other,other_token=sec.issue(cap['code'],'other phone','other')
 def exact(c,n):
  data=b''
  while len(data)<n:
   part=c.recv(n-len(data));assert part;data+=part
  return data
 def read(c):
  h=exact(c,2);n=h[1]&127
  if n==126:n=struct.unpack('>H',exact(c,2))[0]
  return json.loads(exact(c,n))
 def send(c,msg):
  data=json.dumps(msg).encode();mask=b'abcd';assert len(data)<126
  c.sendall(bytes([129,128|len(data)])+mask+bytes(b^mask[i%4] for i,b in enumerate(data)))
 def connect(client,credential=token,query=False):
  c=socket.create_connection(('127.0.0.1',port),timeout=3);c.settimeout(3)
  path='/ws'+('?client='+client if query else '')
  head='GET '+path+' HTTP/1.1\r\nHost: 127.0.0.1:%d\r\nOrigin: http://127.0.0.1:%d\r\nCookie: %s=%s\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Key: MDEyMzQ1Njc4OWFiY2RlZg==\r\nSec-WebSocket-Version: 13\r\n'%(port,port,COOKIE,credential)
  if not query:head+='X-Trackpad-Client: '+client+'\r\n'
  c.sendall((head+'\r\n').encode());data=b''
  while not data.endswith(b'\r\n\r\n'):data+=exact(c,1)
  return c,int(data.split(b' ')[1])
 connections=[]
 try:
  a,code=connect('a'*32);connections.append(a);assert code==101;read(a)
  for client,credential in [('b'*32,token),('a'*32,other_token)]:
   denied,code=connect(client,credential);denied.close();assert code==409,'other client/device cannot steal active control'
  b,code=connect('a'*32,query=not args.expect_old);connections.append(b)
  if args.expect_old:
   assert code==409
   print('REPRODUCED 0.4.14: reconnect by the same authorized client is rejected while its old socket still owns the control lease; retry cannot replace that half-open connection immediately. This is a reproduced code path, not confirmed company-network root cause.')
  else:
   assert code==101,'same authorized client should replace its obsolete socket'
   read(b);send(b,{'p':[[2,.5,.5]],'directDrag':True});send(b,{'heartbeat':True});assert read(b)['alive'];assert pad.drag_down
   resets=pad.releases;old_done.set();threads[0].join(3);assert not threads[0].is_alive()
   assert sec.active is not None and pad.drag_down and pad.releases==resets,'late old cleanup cannot reset or release new connection'
   assert power.active and power.acquired==1 and power.released==0,'power assertion stays with new owner'
   send(b,{'heartbeat':True});assert read(b)['alive'];b.close()
   deadline=time.monotonic()+3
   while sec.active is not None and time.monotonic()<deadline:time.sleep(.01)
   assert sec.active is None and not pad.drag_down and not power.active and power.released==1
   print('Connection recovery passed: actual header/query client IDs, same-client half-open takeover, different client/device denied, delayed old cleanup cannot clear new drag/lease, latest disconnect releases input/power. All Mac input/power mocked.')
 finally:
  old_done.set()
  for c in connections:c.close()
  running=False;listener.close();accept.join(2)
  for t in threads:t.join(2)
