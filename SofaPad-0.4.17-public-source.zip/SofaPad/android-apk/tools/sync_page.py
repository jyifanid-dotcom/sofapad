#!/usr/bin/env python3
"""Extract PAGE without importing/running the Mac input service. Never modify the source."""
import argparse
import ast
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BOOTSTRAP = r"""<script>
/* Local-asset-only native bridge. No network request in Bluetooth mode. */
(function () {
  var current = null;
  window.WebSocket = function () {
    var self = this;
    current = self;
    self.readyState = 0;
    self.send = function (value) {
      if (self.readyState === 1 && window.TrackpadNative) TrackpadNative.send(value);
    };
    self.close = function () { self.readyState = 3; };
    setTimeout(function () {
      window.nativeConnection(!!(window.TrackpadNative && TrackpadNative.isConnected()));
    }, 0);
  };
  window.nativeConnection = function (connected) {
    var self = current;
    if (!self) return;
    if (connected && self.readyState !== 1) {
      if (window.clearAll) clearAll();
      self.readyState = 1;
      if (self.onopen) self.onopen();
    } else if (!connected) {
      if(window.trackpadEndDirectDrag)trackpadEndDirectDrag();
      self.readyState = 0;
      if (window.clearAll) clearAll();
      var hud = document.getElementById('hud');
      if (hud) { hud.style.color = '#a33'; hud.textContent = '×'; }
    }
  };
})();
</script>
"""
TAIL = r"""<script>
/* Preserve down/up boundaries even when a tap fits within one animation frame. */
var nativeCount = 0;
var pageRefresh = refresh;
refresh = function () {
  pageRefresh();
  if (touches.size !== nativeCount) {
    nativeCount = touches.size;
    if (raf) { cancelAnimationFrame(raf); raf = 0; }
    flush();
  }
};
document.getElementById('kbInput').placeholder = '蓝牙：英文键位；中文请用局域网模式';
document.getElementById('hint').textContent = '单指移动 · 轻点点击 · 双击按住拖移 · 双指滚动 · 三指切桌面';
</script>
"""


def render(source: Path):
    raw = source.read_bytes()
    tree = ast.parse(raw.decode('utf-8'))
    pages = [ast.literal_eval(n.value) for n in tree.body
             if isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id == 'PAGE' for t in n.targets)]
    if len(pages) != 1 or not isinstance(pages[0], str):
        raise ValueError('Expected exactly one literal PAGE assignment')
    page = pages[0].replace('<script src="/app-ui.js"></script>\n', "")
    if page.count('<script>') != 1 or page.count('</body>') != 1:
        raise ValueError('Upstream page structure changed; review before extracting')
    page = page.replace("    url('/pad.png'),\n", '')
    page = page.replace('<script>', BOOTSTRAP + '<script>', 1)
    ui = (ROOT/'app/src/main/assets/app-ui.js').read_text()
    page = page.replace('</body>', TAIL + '<script>\n' + ui + '\n</script>\n</body>')
    old = "    add(e.pointerId, e.clientX, e.clientY, e.width, e.height);"
    assert page.count(old) == 1
    page = page.replace(old, old + "\n    if (touches.has(e.pointerId)) padEl.setPointerCapture(e.pointerId);")
    old = "    e.preventDefault(); del(e.pointerId);\n  }, { passive: false });\n} else"
    new = "    e.preventDefault(); TrackpadNative.send('{\"cancel\":true}'); clearAll();\n  }, { passive: false });\n} else"
    assert page.count(old) == 1
    page = page.replace(old, new)
    old = "window.addEventListener('blur', clearAll);"
    assert old in page
    page = page.replace(old, "window.addEventListener('blur', function () { TrackpadNative.send('{\"cancel\":true}'); clearAll(); });")
    page = page.replace("if (document.hidden) clearAll();", "if (document.hidden) { TrackpadNative.send('{\"cancel\":true}'); clearAll(); }")
    target = ROOT / 'app/src/main/assets/index.html'
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(page, encoding='utf-8')
    provenance = {
        'source_file': 'trackpad.py',
        'source_sha256': hashlib.sha256(raw).hexdigest(),
        'extraction': 'ast.literal_eval only; source not imported or executed',
        'page_sha256': hashlib.sha256(page.encode()).hexdigest(),
        'scope': 'HTML/CSS/JS only; no service code, logs, input records, or system backups',
    }
    (ROOT / 'PAGE_SOURCE.json').write_text(json.dumps(provenance, ensure_ascii=False, indent=2)+'\n')
    print('Local Bluetooth page extracted; original service unchanged.')


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--source', type=Path, default=ROOT.parent/'trackpad.py')
    render(parser.parse_args().source)
