/* Exercise the actual extracted scripts with a minimal DOM, not a duplicate recognizer. */
const fs = require('node:fs');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const path = require('node:path');
const html = fs.readFileSync(process.argv[2]||path.join(__dirname,'../app/src/main/assets/index.html'),'utf8');
const scripts = [...html.matchAll(/<script>([\s\S]*?)<\/script>/g)].map(m=>m[1]);
for (const script of scripts) new vm.Script(script);
class Element {
  constructor() { this.events={}; this.style={setProperty(){}}; this.children=[]; this.value='';this.offsetHeight=196;
    const classes=new Set();this.classList={add(s){classes.add(s);},remove(s){classes.delete(s);},toggle(s,on){
      const next=on===undefined?!classes.has(s):!!on;if(next)classes.add(s);else classes.delete(s);return next;},contains(s){return classes.has(s);}}; }
  addEventListener(name,fn,options) { (this.events[name] ||= []).push({fn,capture:options===true}); }
  emit(name,value={}) { let stop=false;value.preventDefault ||= ()=>{};value.stopPropagation ||= ()=>{};value.stopImmediatePropagation=()=>{stop=true;};
    for(const listener of [...(this.events[name]||[])].sort((a,b)=>Number(b.capture)-Number(a.capture))){if(stop)break;listener.fn(value);} }
  getBoundingClientRect(){ if(this.id==='padCommandStrip')return{left:0,top:0,right:1000,bottom:80,width:1000,height:80};return this.bounds||{left:0,top:0,width:1000,height:700,right:1000,bottom:700}; }
  appendChild(child){this.children.push(child);child.parentNode=this;}
  removeChild(child){this.children=this.children.filter(c=>c!==child);child.parentNode=null;}
  setAttribute(key,value){this.attrs ||= {};this.attrs[key]=value;}
  setPointerCapture(){} focus(){} blur(){} click(){this.emit('click');}
  getAttribute(key){return this.attrs?.[key]||null;}
}
const ids={}; for (const id of ['pad','dots','hud','gate','go','kbToggle','kbInput','kb']) ids[id]=new Element();
const deleteButton=new Element();deleteButton.attrs={'data-key':'51'};
const winEvents={}, docEvents={}, timers=[],rafs=new Map();let rafId=0; let connected=false, sent=[];
let drawnPoints=0,fakeTime=0;
const matrixInk={createRadialGradient(){return{addColorStop(){}};},fillRect(){},setTransform(){},clearRect(){},beginPath(){},arc(){drawnPoints++;},fill(){}};
const document={getElementById(id){return ids[id] ||= new Element();},createElement(tag){const el=new Element();if(tag==='canvas')el.getContext=()=>matrixInk;return el;},
  body:new Element(),head:new Element(),documentElement:new Element(),querySelectorAll(selector){return selector==='#kb [data-key]'||selector==='#kb [data-key="51"]'?[deleteButton]:[];},
  addEventListener(name,fn){(docEvents[name] ||= []).push(fn);}};
const context={document,console,Promise,Map,JSON,Math,performance:{now(){return fakeTime;}},innerWidth:1200,innerHeight:800,navigator:{},
  location:{protocol:'https:',host:'appassets.androidplatform.net'},
  TrackpadNative:{isConnected(){return connected;},send(s){sent.push(JSON.parse(s));}},
  setTimeout(fn,delay){timers.push({fn,delay});return timers.length;},
  clearTimeout(id){if(timers[id-1])timers[id-1].cancelled=true;},
  requestAnimationFrame(fn){rafs.set(++rafId,fn);return rafId;},cancelAnimationFrame(id){rafs.delete(id);},
  addEventListener(name,fn){(winEvents[name] ||= []).push(fn);},PointerEvent:function(){}};
context.window=context;
vm.createContext(context); for (const script of scripts) vm.runInContext(script,context);
function pointer(name,id,x,y){ids.pad.emit(name,{preventDefault(){},pointerType:'touch',pointerId:id,
  isPrimary:id===1,clientX:x,clientY:y,width:45,height:45});}
function frame(){const pending=[...rafs.values()];rafs.clear();fakeTime+=16;for(const fn of pending)fn(fakeTime);}
function settle(){for(const t of timers){if(t.delay===200&&!t.cancelled&&!t.ran){t.ran=true;t.fn();}}frame();frame();}
(async()=>{
  document.documentElement.requestFullscreen=()=>{throw Error('WebView has no browser fullscreen');};
  context.trackpadStart();
  for(const t of timers) if(t.delay===0)t.fn();
  assert.equal(sent.length,0,'offline page must not send input');
  connected=true; context.nativeConnection(true);
  assert(sent.some(m=>m.meta),'connected handshake reports page dimensions'); sent=[];
  pointer('pointerdown',1,500,350); pointer('pointerup',1,500,350);
  assert.deepEqual(sent.filter(m=>m.p).map(m=>m.p.length),[1,0],'fast tap keeps down/up even without RAF');
  sent=[]; pointer('pointerdown',1,500,350); pointer('pointerdown',2,700,350);
  assert.deepEqual(sent.filter(m=>m.p).map(m=>m.p.length),[1,2]);
  pointer('pointercancel',1,500,350);
  assert(sent.some(m=>m.cancel),'pointer cancellation sends cancel before clearing touches');
  assert.equal(context.touches.size,0);
  sent=[]; pointer('pointerdown',1,1500,350); pointer('pointerup',1,1500,350);
  assert(!sent.some(m=>m.p&&m.p.length),'outside touch must not reach input');
  pointer('pointerdown',1,500,350); sent=[];
  for(const fn of winEvents.blur)fn();
  assert.equal(sent[0].cancel,true,'blur cancels before empty frame can click');
  connected=false; context.nativeConnection(false); sent=[];
  pointer('pointerdown',1,500,350); pointer('pointerup',1,500,350);
  assert.equal(sent.length,0,'disconnected touches are never queued');
  connected=true; context.nativeConnection(true);
  assert.equal(context.touches.size,0,'reconnection clears old contact state');
  sent=[];context.setKb(true);pointer('pointerdown',1,500,350);
  assert.equal(context.touches.size,0,'keyboard opening must block contacts during transition');
  settle();pointer('pointerdown',1,500,350);pointer('pointerup',1,500,350);
  assert(sent.some(m=>m.p&&m.p.length===1),'new contact works after keyboard opening settles');
  sent=[];context.setKb(false);ids.pad.bounds={left:88,top:18,width:1000,height:700,right:1088,bottom:718};
  pointer('pointerdown',1,500,350);assert.equal(context.touches.size,0,'keyboard closing blocks contacts');
  context.trackpadLayoutChanged();settle();sent=[];
  pointer('pointerdown',1,588,368);pointer('pointerup',1,588,368);
  const p=sent.find(m=>m.p&&m.p.length===1).p[0];assert.equal(p[1],.5);assert.equal(p[2],.5);
  sent=[];ids.kbInput.value='';ids.kbInput.emit('beforeinput',{inputType:'deleteContentBackward'});
  assert.equal(sent.filter(m=>m.k&&m.k.c===51).length,1,'empty IME backspace must reach host');
  context.resetRemoteEditor();ids.kbInput.value='already forwarded';ids.kbInput.emit('input');sent=[];
  ids.kbInput.emit('beforeinput',{inputType:'deleteContentBackward'});
  assert.equal(sent.length,0,'nonempty native browser edit must not be consumed by beforeinput');
  ids.kbInput.value='already forwarde';ids.kbInput.emit('input');
  assert.equal(sent.filter(m=>m.k&&m.k.c===51).length,1,'actual full-buffer deletion forwards once');
  context.resetRemoteEditor();sent=[];
  for(const value of ['a','ab','abc']){ids.kbInput.value=value;ids.kbInput.emit('input');}
  ids.kbInput.emit('compositionend',{data:'abc'});ids.kbInput.emit('input');
  assert.equal(sent.filter(m=>m.t).map(m=>m.t).join(''),'abc','cumulative composition and duplicate commit notifications must not echo old letters');
  context.resetRemoteEditor();
  sent=[];ids.kbInput.emit('keydown',{key:'Backspace'});ids.kbInput.emit('beforeinput',{inputType:'deleteContentBackward'});
  assert.equal(sent.filter(m=>m.k&&m.k.c===51).length,1,'keydown and beforeinput must not double-delete');
  sent=[];deleteButton.emit('pointerdown');deleteButton.emit('click');
  assert.equal(sent.filter(m=>m.k&&m.k.c===51).length,1,'custom delete responds on press exactly once');
  pointer('pointerdown',1,588,368);frame();assert(drawnPoints>0,'touch feedback renders discrete matrix points');pointer('pointerup',1,588,368);for(let i=0;i<60;i++)frame();assert.equal(rafs.size,0,'matrix loop stops after pulses fade');
  const privacy=(ids.kbEssential||ids.kb).children.find(e=>typeof e.onclick==='function'&&e.textContent==='隐私输入：关');
  assert(privacy,'privacy input control exists');ids.kbInput.value='local-only';sent=[];privacy.onclick();assert.equal(ids.kbInput.type,'password');assert.equal(ids.kbInput.value,'');assert(!sent.some(m=>m.t),'privacy switch must not forward local buffer');privacy.onclick();assert.equal(ids.kbInput.type,'text');
  const bar=document.body.children.find(e=>e.id==='touchbar');
  const walk=e=>[e,...e.children.flatMap(walk)];
  const barNodes=walk(bar),barButton=label=>barNodes.find(e=>e.textContent===label&&typeof e.onclick==='function');
  const leftKeys=bar.children[0],rightKeys=bar.children[2];
  for(const label of ['音量−','静音','音量+','音量'])assert.equal(barButton(label).parentNode,leftKeys,'volume keys belong in left group');
  const strip=ids.pad.children.find(e=>e.id==='padCommandStrip');assert(strip,'glass direction strip exists');
  const arrows=walk(strip).filter(e=>e.classList.contains('glass-arrow'));
  assert.deepEqual(arrows.map(e=>e.textContent),['↑','↓','←','→'],'up/down first, seek pair far right');
  assert(!barNodes.some(e=>e.classList.contains('glass-arrow')||e.classList.contains('bar-arrow')),'external Bar has no duplicate arrows');
  assert.equal(arrows[0].parentNode,arrows[1].parentNode);assert.equal(arrows[2].parentNode,arrows[3].parentNode);assert.notEqual(arrows[0].parentNode,arrows[2].parentNode,'separate pairs');
  for(const [label,code] of [['←',123],['↑',126],['↓',125],['→',124]]){
    const button=arrows.find(e=>e.textContent===label);sent=[];button.onclick();assert.equal(sent.filter(m=>m.k&&m.k.c===code&&m.k.f===0).length,1,'each glass arrow sends one unmodified key');assert(!sent.some(m=>m.p&&m.p.length),'arrow click cannot inject pointer input');
  }
  assert.equal(barButton('截图').parentNode,leftKeys,'screenshot in main shortcuts');
  assert.equal(barButton('拖移').parentNode,leftKeys,'drag in main shortcuts');
  assert.equal(barButton('锁屏').parentNode,rightKeys,'lock stays isolated in original right group');
  sent=[];pointer('pointerdown',1,588,40);pointer('pointerup',1,588,40);frame();assert(!sent.some(m=>m.p&&m.p.length),'blank command strip rejects gesture starts');
  let stopped=false;const event={preventDefault(){},stopPropagation(){stopped=true;}};
  sent=[];strip.emit('pointerdown',event);assert(stopped,'strip stops pointer bubbling');assert(!sent.some(m=>m.p&&m.p.length),'strip contact only cancels held gestures');
  const sharedCss=document.head.children.find(e=>String(e.textContent).includes('body.tablet-bar')).textContent;
  assert(sharedCss.includes('width:52px;min-width:52px;height:52px;flex-basis:52px'),'tablet action keys share square 52px footprint');
  assert(sharedCss.includes('gap:28px')&&sharedCss.includes('gap:14px')&&sharedCss.includes('padding-left:28px!important'),'direction pairs and lock are separated');
  assert(sharedCss.includes('width:32px;min-width:32px;height:32px;flex-basis:32px'),'phone action keys keep compact 32px height');
  sent=[];barButton('锁屏').onclick();assert.equal(sent.filter(m=>m.k&&m.k.c===12&&m.k.f===1310720).length,1,'Touch Bar lock sends exactly Control+Command+Q');
  sent=[];barButton('音量').onclick();assert.equal(sent.filter(m=>m.k).length,0,'opening volume slider must not change volume');
  const volume=barNodes.find(e=>e.type==='range');volume.value='11';volume.emit('input');assert.equal(sent.filter(m=>m.k&&m.k.c===72).length,3,'relative volume slider sends only step delta');
  barButton('完成').onclick();assert(!bar.classList.contains('volume-open'));
  sent=[];barButton('截图').onclick();
  assert.equal(sent.filter(m=>m.k&&m.k.c===21&&m.k.f===1179648).length,1,'screenshot Bar button sends Command+Shift+4 once');
  assert.equal(context.trackpadDirectDrag,true,'screenshot button automatically prepares single-finger selection');
  pointer('pointerdown',1,588,368);pointer('pointermove',1,688,368);frame();pointer('pointerup',1,688,368);
  assert(sent.some(m=>m.p&&m.p.length===1&&m.directDrag),'screenshot selection keeps a single held press');
  assert.equal(context.trackpadDirectDrag,false,'screenshot mode clears after lift');
  sent=[];context.trackpadToggleDirectDrag();assert.equal(context.trackpadDirectDrag,true);
  frame();assert.equal(context.trackpadDirectDrag,true,'arming must not schedule an empty frame that consumes direct drag');
  pointer('pointerdown',1,588,368);pointer('pointermove',1,688,368);frame();pointer('pointerup',1,688,368);
  assert(sent.some(m=>m.p&&m.p.length===1&&m.directDrag===true),'direct drag travels on touch frames');
  assert.equal(context.trackpadDirectDrag,false,'one-shot drag clears after lift');
  context.trackpadToggleDirectDrag();const dragTimeout=timers.filter(t=>t.delay===15000&&!t.cancelled).at(-1);assert(dragTimeout);dragTimeout.fn();assert.equal(context.trackpadDirectDrag,false,'timeout cancels direct drag');
  context.trackpadToggleDirectDrag();context.nativeConnection(false);assert.equal(context.trackpadDirectDrag,false,'disconnect disarms direct drag');context.nativeConnection(true);
  // Run the actual browser scripts without the native bridge in fresh document contexts.
  function browserStart(standalone){
    const bid={};let sockets=0,requests=0;
    const bdoc={...document,body:new Element(),head:new Element(),documentElement:new Element(),getElementById(id){return bid[id] ||= new Element();}};
    bdoc.documentElement.requestFullscreen=()=>{requests++;return Promise.reject(Error('fullscreen unavailable'));};
    const browser={...context,document:bdoc,TrackpadNative:undefined,trackpadUiVersion:undefined,navigator:{userAgent:'iPhone',standalone},
      WebSocket:function(){sockets++;this.readyState=0;this.send=()=>{};this.close=()=>{};}};
    browser.window=browser;vm.createContext(browser);vm.runInContext(scripts[1],browser);vm.runInContext(scripts[3],browser);
    return {browser,bdoc,count:()=>sockets,requests:()=>requests};
  }
  const home=browserStart(true);assert.equal(home.count(),1,'home screen standalone automatically connects');assert.equal(home.requests(),0,'standalone does not request fullscreen');assert(home.bdoc.body.classList.contains('iphone'));
  const safari=browserStart(false);assert.equal(safari.count(),0,'regular browser waits for start');safari.browser.trackpadStart(true);assert.equal(safari.count(),1,'connection starts despite fullscreen rejection');assert.equal(safari.requests(),1);assert.equal(safari.bdoc.getElementById('gate').style.display,'none');
  safari.browser.trackpadStart(true);assert.equal(safari.count(),1,'fullscreen retries cannot duplicate socket');
  const rail=safari.bdoc.body.children.find(e=>e.id==='browserRail');
  rail.children[2].onclick();assert(safari.bdoc.body.classList.contains('sheet-open'),'settings opens sheet');
  const sheet=safari.bdoc.body.children.find(e=>e.classList.contains('trackpad-sheet')&&e.style.display==='block');
  sheet.children[0].children[1].onclick();assert(!safari.bdoc.body.classList.contains('sheet-open'),'sticky header closes sheet');
  rail.children[2].onclick();rail.children[2].onclick();assert(!safari.bdoc.body.classList.contains('sheet-open'),'same rail button toggles sheet closed');
  rail.children[2].onclick();safari.browser.trackpadClosePanels();assert(!safari.bdoc.body.classList.contains('sheet-open'));
  safari.browser.trackpadHandleServerStatus({machine:'test-Mac',inputReady:false,inputFrames:3});assert.equal(safari.browser.trackpadInputAllowed,false);
  safari.browser.trackpadHandleServerStatus({machine:'test-Mac',inputReady:true,inputFrames:4});assert.equal(safari.browser.trackpadInputAllowed,true);
  // Exercise the real browser path: APK previously had a private boundary fix.
  const b=safari.browser,bpad=safari.bdoc.getElementById('pad');let bsent=[];
  b.ws.readyState=1;b.ws.send=s=>bsent.push(JSON.parse(s));
  function bp(name,id,x,y){bpad.emit(name,{preventDefault(){},pointerType:'touch',pointerId:id,isPrimary:true,clientX:x,clientY:y,width:30,height:30});}
  bp('pointerdown',11,200,350);bp('pointerup',11,200,350);bp('pointerdown',12,800,350);
  assert.deepEqual(bsent.filter(m=>m.p).map(m=>m.p.length),[1,0,1],'browser preserves lift and recontact inside a single animation frame');
  const start=bsent.filter(m=>m.p&&m.p.length).at(-1);bsent=[];
  bpad.bounds={left:100,top:50,width:500,height:600,right:600,bottom:650};
  bp('pointermove',12,800,350);b.flush();
  const stationary=bsent.find(m=>m.p&&m.p.length);
  assert.deepEqual(stationary.p,start.p,'layout measurement cannot turn a stationary held finger into motion');
  assert.deepEqual(stationary.surface,start.surface,'gesture keeps one coordinate scale until release');
  bp('pointerup',12,800,350);bsent=[];bp('pointerdown',13,350,350);
  assert.equal(bsent.find(m=>m.p&&m.p.length).p[0][1],.5,'next contact adopts new bounds');
  bp('pointerup',13,350,350);bpad.bounds=undefined;
  console.log('Browser contact regressions passed: immediate down/up, no merged lift/recontact, stable held coordinates, new-layout adoption.');
  let backlogClosed=false;
  safari.browser.ws.readyState=1;safari.browser.ws.bufferedAmount=65536;safari.browser.ws.close=()=>{backlogClosed=true;};
  safari.browser.flush();assert(backlogClosed,'congested browser channel closes instead of replaying pointer frames');
  assert.equal(safari.browser.touches.size,0,'congestion clears active contacts');
  await Promise.resolve();
  console.log('Page checks passed: connection without fullscreen, tap, multi-touch, cancellation, reconnect, keyboard transition blocking/live bounds, IME and custom deletion.');
})().catch(e=>{console.error(e);process.exitCode=1;});
