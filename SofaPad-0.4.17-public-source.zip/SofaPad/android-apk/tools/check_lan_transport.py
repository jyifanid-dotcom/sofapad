#!/usr/bin/env python3
"""Actual HTTP receiver + actual Java socket client, temporary pairing state, mocked Mac input."""
import argparse,ast,base64,hashlib,json,math,os,socket,struct,subprocess,sys,tempfile,threading,time
from pathlib import Path
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from trackpad_security import SecureReceiver,MAX_BODY,COOKIE
p=argparse.ArgumentParser();p.add_argument('--jdk',required=True,type=Path);p.add_argument('--idle-seconds',type=int,default=60);args=p.parse_args()
class Pad:
 def __init__(self):
  self.lock=threading.RLock();self.drag_down=self.dragging=self.drag_latched=False;self.last_tap_t=0;self.frames=[];self.releases=0;self.scroll_motion=type('Scroll',(),{'stop':lambda s:None})()
 def reset(self):self.drag_down=self.dragging=self.drag_latched=False;self.releases+=1
 def on_frame(self,*a):self.frames.append(a)
with tempfile.TemporaryDirectory(prefix='trackpad-plain-test-') as folder:
 t=Path(folder);listener=socket.socket();listener.bind(('127.0.0.1',0));listener.listen(8);listener.settimeout(.2);port=listener.getsockname()[1]
 sec=SecureReceiver(t/'state',names=['127.0.0.1'],port=port,bootstrap_port=0);pad=Pad()
 assert not list((t/'state').glob('*.crt')) and not list((t/'state').glob('*.key')),'new mode must not generate certificates'
 tree=ast.parse((ROOT/'trackpad.py').read_text());names={'recv_exact','ws_handshake','ws_recv','ws_send_text','serve_client','InputFrameClock','reset_remote_input'};nodes=[n for n in tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef)) and n.name in names]
 env={'time':time,'SECURITY':sec,'MAX_BODY':MAX_BODY,'PAD':pad,'socket':socket,'base64':base64,'hashlib':hashlib,'struct':struct,'json':json,'math':math,'os':os,'SELF_PATH':str(ROOT/'trackpad.py'),'PAGE':'isolated','MOD_MASK':0x1e0000,'WS_GUID':'258EAFA5-E914-47DA-95CA-C5AB0DC85B11','mouse_up':lambda *a:None,'type_text':lambda *a:None,'key_combo':lambda *a:None,'media_volume':lambda *a:None,'print':lambda *a,**k:None}
 exec(compile(ast.Module(body=nodes,type_ignores=[]),'isolated-http-receiver','exec'),env)
 running=True;threads=[]
 def serve():
  while running:
   try:conn,addr=listener.accept()
   except socket.timeout:continue
   except OSError:break
   thread=threading.Thread(target=env['serve_client'],args=(conn,addr),daemon=True);threads.append(thread);thread.start()
 accept=threading.Thread(target=serve,daemon=True);accept.start()
 def request(path,method='GET',body=b'',headers=None):
  h={'Host':'127.0.0.1:'+str(port),'Connection':'close','Content-Length':str(len(body))};h.update(headers or {})
  with socket.create_connection(('127.0.0.1',port),timeout=3) as c:
   c.sendall((method+' '+path+' HTTP/1.1\r\n'+''.join(k+': '+v+'\r\n' for k,v in h.items())+'\r\n').encode()+body);out=b''
   while True:
    chunk=c.recv(4096)
    if not chunk:break
    out+=chunk
   return out
 response=request('/api/identity');assert response.startswith(b'HTTP/1.1 200') and sec.identity.encode() in response
 assert request('/ws').startswith(b'HTTP/1.1 401')
 assert request('/api/identity',headers={'Host':'evil.example:'+str(port)}).startswith(b'HTTP/1.1 403')
 cap=json.loads(base64.urlsafe_b64decode((raw:=sec.capsule())+'='*(-len(raw)%4)))
 assert 'pin' not in cap and 'ca' not in cap and cap['origin'].startswith('http://127.0.0.1:')
 payload=json.dumps({'code':cap['code'],'name':'cross-origin'}).encode()
 assert request('/api/pair','POST',payload,{'Origin':'http://evil.example','Content-Type':'application/json'}).startswith(b'HTTP/1.1 403')
 java=r'''import cc.trackpad.tablet.LanConnection;import java.util.*;import java.util.concurrent.*;import java.util.concurrent.atomic.*;
public class PlainCheck{public static void main(String[] a)throws Exception{
 String url=a[0],id=a[1],code=a[2];boolean refused=false;try{LanConnection.pair(url,"0".repeat(32),code,"wrong receiver");}catch(Exception e){refused=true;}if(!refused)throw new AssertionError("wrong receiver accepted");
 for(String bad:List.of("http://mac.local:8765","https://192.168.1.2:8765","http://evil.example:8765","http://999.1.1.1:8765")){refused=false;try{LanConnection.checkedOrigin(bad);}catch(Exception e){refused=true;}if(!refused)throw new AssertionError("non-IP/invalid endpoint accepted");}
 String unreachable=url.replace("127.0.0.1","127.0.0.2");LanConnection.PairResult result=LanConnection.pairCandidates(List.of(unreachable,url),id,code,"actual Java plaintext client");
 CountDownLatch first=new CountDownLatch(1),second=new CountDownLatch(1),revoked=new CountDownLatch(1);AtomicInteger opens=new AtomicInteger();
 LanConnection client=new LanConnection(List.of(unreachable,url),id,result.cookie,new LanConnection.Listener(){public void changed(String m,boolean ready){if(ready){if(opens.incrementAndGet()==1)first.countDown();else second.countDown();}}public void pairingRequired(){revoked.countDown();}});
 try{client.start();if(!first.await(10,TimeUnit.SECONDS))throw new AssertionError("no connection");Thread.sleep(Integer.parseInt(a[3])*1000L);if(!client.connected()||opens.get()!=1)throw new AssertionError("idle disconnected/reconnected");
 client.send("{\"p\":[[1,0.5,0.5]]}");Thread.sleep(200);System.out.println("IDLE_DONE");System.out.flush();if(!second.await(10,TimeUnit.SECONDS))throw new AssertionError("network drop did not recover");client.send("{\"p\":[[2,0.6,0.5]]}");Thread.sleep(200);System.out.println("RECONNECTED");System.out.flush();if(!revoked.await(10,TimeUnit.SECONDS))throw new AssertionError("revocation did not stop transport");}finally{client.stop();}
 System.out.println("PLAINTEXT_CLIENT_OK");}}
'''
 (t/'PlainCheck.java').write_text(java);src=ROOT/'android-apk/app/src/main/java/cc/trackpad/tablet/LanConnection.java'
 subprocess.run([str(args.jdk/'bin/javac'),'--release','17','-encoding','UTF-8','-d',str(t/'classes'),str(src),str(t/'PlainCheck.java')],check=True)
 proc=subprocess.Popen([str(args.jdk/'bin/java'),'-cp',str(t/'classes'),'PlainCheck',cap['origin'],sec.identity,cap['code'],str(args.idle_seconds)],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
 try:
  line=proc.stdout.readline().strip()
  if line!='IDLE_DONE':
   out,err=proc.communicate(timeout=10);raise AssertionError(line+out+err)
  assert len(sec.devices)==1 and len(pad.frames)==1 and sec.active is not None
  before=pad.releases;pad.drag_down=True;old=sec.active[1];old.shutdown(socket.SHUT_RDWR);old.close()
  line=proc.stdout.readline().strip()
  if line!='RECONNECTED':
   out,err=proc.communicate(timeout=10);raise AssertionError(line+out+err)
  assert len(sec.devices)==1 and len(pad.frames)==2 and pad.releases>before and not pad.drag_down
  sec.revoke(sec.active[0]);out,err=proc.communicate(timeout=15);assert proc.returncode==0,(out,err)
  deadline=time.monotonic()+3
  while sec.active is not None and time.monotonic()<deadline:time.sleep(.01)
  assert sec.active is None
 finally:
  if proc.poll() is None:proc.kill();proc.communicate()
  running=False;listener.close();accept.join(2)
  for thread in threads:thread.join(2)
print('Plain LAN passed: HTTP/no certificates, IP-only URLs, wrong receiver rejection before pairing, Origin/Host/unauth guards, %ds real idle without reconnect, forced disconnect automatic reconnect with same pairing, held-input release, revocation stops. All Mac input mocked.'%args.idle_seconds)
