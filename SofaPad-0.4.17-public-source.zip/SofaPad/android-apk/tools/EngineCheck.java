package cc.trackpad.tablet;

import java.util.ArrayList;
import java.util.List;

/** Deterministic invariants; no Android runtime, Mac input, or Bluetooth host required. */
public final class EngineCheck {
    private static final class Recorder implements GestureEngine.Output {
        final List<int[]> mice = new ArrayList<>(), keys = new ArrayList<>();
        public void mouse(int b,int x,int y,int w,int p) { mice.add(new int[]{b,x,y,w,p}); }
        public void key(int m,int k) { keys.add(new int[]{m,k}); }
        long clicks(int button) { return mice.stream().filter(v -> v[0] == button && v[1] == 0 && v[2] == 0).count(); }
    }
    static double[][] point(double x,double y) { return new double[][] {{1,x,y,45,45}}; }
    static double[][] fingers(int n,double offset) {
        double[][] p = new double[n][];
        for (int i=0;i<n;i++) p[i] = new double[]{i,.25+i*.12+offset,.4,45,45};
        return p;
    }
    static void check(boolean value,String message) { if (!value) throw new AssertionError(message); }
    public static void main(String[] args) {
        Recorder r = new Recorder(); GestureEngine e = new GestureEngine(r);
        e.frame(point(.5,.5),1000); e.frame(new double[0][],1100);
        check(r.clicks(1)==1,"one tap must make one left click");
        r.mice.clear();
        e.frame(point(.5,.5),2000); e.frame(point(.55,.5),2050); e.frame(new double[0][],2100);
        check(r.clicks(1)==0,"movement must not become a click");
        e.frame(point(.5,.5),3000); e.tick(3501); e.frame(new double[0][],3550);
        check(r.clicks(2)==0 && r.clicks(1)==0,"single finger hold must not click");
        r.mice.clear();
        e.frame(fingers(2,0),4000); e.frame(fingers(2,0),4030); e.frame(fingers(2,0),4060);
        e.frame(new double[0][],4100);
        check(r.clicks(2)==1,"real two-finger tap is right click");
        r.mice.clear();
        e.frame(fingers(2,0),5000); e.frame(fingers(2,.1),5100);
        e.frame(fingers(1,.1),5120); e.frame(new double[0][],5150);
        check(r.clicks(2)==0 && r.clicks(1)==0,"scroll lift-off must not become a click");
        e.frame(fingers(3,0),6000); e.frame(fingers(3,-.15),6100);
        e.frame(fingers(2,-.15),6120); e.frame(fingers(1,-.15),6140); e.frame(new double[0][],6160);
        check(r.keys.size()==1 && r.keys.get(0)[0]==1 && r.keys.get(0)[1]==79,
            "staggered three-finger lift must preserve Ctrl+Right");
        r.mice.clear();
        e.frame(point(.5,.5),7000); e.frame(new double[0][],7100);
        e.frame(point(.5,.5),7200);
        check(r.mice.get(r.mice.size()-1)[0]==1,"second contact must hold left before browser movement");
        e.frame(point(.6,.5),7250); e.tick(7266);
        check(r.mice.stream().anyMatch(v->v[0]==1 && v[1]!=0),"drag motion must retain left button");
        e.cancel();
        check(r.mice.get(r.mice.size()-1)[0]==0,"cancel during drag releases button");
        int old = r.mice.size();
        e.frame(new double[][]{{1,Double.NaN,.5}},8000);
        e.frame(new double[0][],8100);
        check(r.mice.size()==old,"invalid coordinates must not create clicks");
        e.frame(new double[][]{{1,.5,.5,140,140}},9000); e.frame(new double[0][],9100);
        check(r.mice.size()==old,"palm must not create clicks");
        r.mice.clear();
        e.frame(new double[][]{{1,.5,.5},{2,.501,.501}},10000); e.frame(new double[0][],10100);
        check(r.clicks(1)==1 && r.clicks(2)==0,"near-duplicate contact must be merged");
        byte[] report=HidReports.mouse(1,-32767,32767,-1,1);
        check(report.length==7 && report[1]==1 && report[2]==(byte)0x80 && report[3]==(byte)0xff
            && report[4]==0x7f,"mouse uses signed little-endian 16-bit axes");
        check(HidReports.keyboard(8,6).length==8,"keyboard layout must be 8 bytes");
        check(HidReports.macModifiers(0x140000)==9,"Command+Control mapping");
        check(HidReports.macKey(123)==80 && HidReports.macKey(124)==79,"Mac arrow mapping");
        check(HidReports.ascii('中')==null,"no false Unicode support over standard HID");
        check(HidReports.ascii('A')[0]==2 && HidReports.ascii('A')[1]==4,"ASCII uppercase");
        for (char c=32;c<127;c++) check(HidReports.ascii(c)!=null,"ASCII coverage: "+c);
        check(ServerAddress.normalize("192.168.1.20").equals("http://192.168.1.20:8765/"),"bare IP gets receiver port");
        boolean plainRejected=false;try{ServerAddress.normalize("https://192.168.1.20");}catch(IllegalArgumentException ex){plainRejected=true;}check(plainRejected,"old HTTPS address rejected");
        check(ServerAddress.normalize("192.168.1.20：9000").equals("http://192.168.1.20:9000/"),"explicit port preserved");
        check(ServerAddress.normalize("http://192.168.1.20/").equals("http://192.168.1.20:8765/"),"HTTP default preserved");
        for(String invalid:new String[]{"","http://user:pass@mac.local","http://mac.local/ws","file:///tmp/x","http://mac.local:70000","http://mac.local","http://8.8.8.8","http://999.1.1.1","http://192.168.01.2"}){
            boolean rejected=false;try{ServerAddress.normalize(invalid);}catch(IllegalArgumentException ex){rejected=true;}
            check(rejected,"invalid receiver address must be rejected");
        }
        Recorder aspectOutput=new Recorder();GestureEngine aspectGesture=new GestureEngine(aspectOutput);aspectGesture.setSurface(300,600);
        aspectGesture.frame(point(.5,.5),60000);aspectGesture.frame(point(.51,.505),60016);
        for(int i=0;i<12;i++)aspectGesture.tick(60016+i*16);
        int aspectX=aspectOutput.mice.stream().mapToInt(v->v[1]).sum(),aspectY=aspectOutput.mice.stream().mapToInt(v->v[2]).sum();
        check(aspectX==aspectY&&aspectX>0,"rectangular surface has equal physical X/Y pointer gain");
        Recorder directOutput=new Recorder();GestureEngine directGesture=new GestureEngine(directOutput);directGesture.setFeel(1,1,true);directGesture.setDirectDrag(true);
        directGesture.frame(point(.5,.5),70000);check(directOutput.mice.size()==1&&directOutput.mice.get(0)[0]==1,"direct drag starts held with no leading click");
        directGesture.frame(point(.6,.5),70016);directGesture.tick(70016);check(directOutput.mice.get(1)[0]==1&&directOutput.mice.get(1)[1]>0,"direct drag moves while held");
        directGesture.frame(new double[0][],70032);check(directOutput.mice.get(directOutput.mice.size()-1)[0]==0,"direct drag releases even with drag lock enabled");
        directGesture.setDirectDrag(true);directGesture.frame(point(.5,.5),71000);directGesture.tick(87000);
        check(directOutput.mice.get(directOutput.mice.size()-1)[0]==0,"native watchdog releases direct drag if page timer stalls");
        RelativeMotion smooth=new RelativeMotion();smooth.add(12,0);
        int[] first=smooth.step(1000);check(first[0]>0&&first[0]<12,"small move should be distributed, not one jump");
        int total=first[0];for(int i=1;i<12;i++)total+=smooth.step(1000+i*16)[0];
        check(total==12,"smoothing must preserve total displacement without overshoot");
        smooth.add(50,50);smooth.clear();int[] stopped=smooth.step(1300);
        check(stopped[0]==0&&stopped[1]==0,"cancellation must discard pending movement");
        smooth.scroll(10,0);check(smooth.step(1400)[2]<=8,"wheel burst is bounded per frame");
        int[] distances=new int[2];
        for(int mode=0;mode<2;mode++){
            RelativeMotion wheel=new RelativeMotion();long now=10000;wheel.beginScroll(now);wheel.step(now);
            for(int i=0;i<6;i++){now+=mode==0?80:16;wheel.scroll(.68,0,now);distances[mode]+=wheel.step(now)[2];}
            wheel.releaseScroll(now);
            for(int i=0;i<60;i++){now+=16;int amount=wheel.step(now)[2];check(Math.abs(amount)<=8,"fast scroll burst stays bounded");distances[mode]+=amount;}
            check(wheel.step(now+1000)[2]==0,"momentum settles to zero");
        }
        check(distances[1]>distances[0]*2,"same travel fast flick must scroll further than slow movement");
        RelativeMotion flick=new RelativeMotion();flick.beginScroll(20000);flick.scroll(0,2.72,20016);flick.step(20016);flick.releaseScroll(20020);
        check(flick.step(20036)[3]>0,"horizontal momentum preserves direction");flick.beginScroll(20040);
        check(flick.step(20056)[3]==0,"new touch stops old momentum immediately");
        flick.scroll(2.72,0,20072);flick.releaseScroll(20080);flick.clear();check(flick.step(20096)[2]==0,"cancel stops wheel momentum");
        Recorder scrollingOutput=new Recorder();GestureEngine scrollGesture=new GestureEngine(scrollingOutput);
        scrollGesture.frame(fingers(2,0),30000);scrollGesture.frame(fingers(2,.06),30016);scrollGesture.tick(30016);
        scrollGesture.frame(fingers(1,.06),30024);scrollGesture.frame(new double[0][],30030);int beforeFling=scrollingOutput.mice.size();scrollGesture.tick(30046);
        check(scrollingOutput.mice.size()>beforeFling&&scrollingOutput.mice.get(scrollingOutput.mice.size()-1)[4]>0,"staggered two-finger lift must retain horizontal flick");
        scrollGesture.frame(point(.5,.5),30050);int afterStop=scrollingOutput.mice.size();scrollGesture.tick(30066);
        check(scrollingOutput.mice.size()==afterStop,"new contact interrupts old wheel output");
        RelativeMotion reverse=new RelativeMotion();reverse.beginScroll(40000);reverse.scroll(2.72,0,40016);reverse.scroll(-2.72,0,40032);check(reverse.step(40032)[2]<0,"direction reversal discards old queued wheel motion");
        Recorder axisOut=new Recorder();GestureEngine axis=new GestureEngine(axisOut);
        axis.frame(fingers(2,0),50000);axis.frame(new double[][]{{0,.253,.48,45,45},{1,.373,.48,45,45}},50016);axis.tick(50016);axis.frame(new double[0][],50030);axis.tick(50046);
        check(axisOut.mice.stream().anyMatch(v->v[3]!=0)&&axisOut.mice.stream().noneMatch(v->v[4]!=0),"vertical intent filters small horizontal motion including momentum");
        Recorder palmOut=new Recorder();GestureEngine palm=new GestureEngine(palmOut);palm.frame(point(.5,.5),51000);palm.frame(new double[][]{{1,.5,.5,150,150}},51020);palm.frame(new double[0][],51040);
        check(palmOut.clicks(1)==0&&palmOut.clicks(2)==0,"palm replacing a finger must cancel rather than click");
        Recorder jumpOut=new Recorder();GestureEngine jump=new GestureEngine(jumpOut);jump.frame(point(.2,.5),52000);jump.frame(point(.8,.5),52016);jump.tick(52016);check(jumpOut.mice.isEmpty(),"isolated impossible jump must not move pointer");jump.frame(new double[0][],52030);check(jumpOut.clicks(1)==0,"discarded jump must not become a tap");jump.cancel();
        Recorder stillOut=new Recorder();GestureEngine still=new GestureEngine(stillOut);
        still.frame(point(.3,.5),70000);
        still.frame(new double[][]{{1,.3,.5,45,45},{2,.5,.5,45,45}},70020);
        still.frame(new double[][]{{2,.5,.5,45,45}},70120);still.frame(new double[0][],70140);
        check(stillOut.clicks(2)==1&&stillOut.clicks(1)==0,"stationary two-finger tap needs no move events");
        Recorder ghostOut=new Recorder();GestureEngine ghost=new GestureEngine(ghostOut);
        ghost.frame(new double[][]{{1,.3,.5,45,45},{2,.5,.5,45,45}},71000);
        ghost.frame(point(.3,.5),71010);ghost.frame(new double[0][],71110);
        check(ghostOut.clicks(2)==0,"short overlap cannot borrow a single-finger tail to right-click");
        Recorder idOut=new Recorder();GestureEngine idChange=new GestureEngine(idOut);
        idChange.frame(point(.2,.5),72000);idChange.frame(new double[][]{{2,.7,.5,45,45}},72040);idChange.tick(72040);
        check(idOut.mice.isEmpty(),"replacement contact cannot teleport pointer");
        idChange.frame(new double[0][],72080);check(idOut.clicks(1)==0,"rebased contact cannot click on lift");
        Recorder dragLostOut=new Recorder();GestureEngine dragLost=new GestureEngine(dragLostOut);
        dragLost.setDirectDrag(true);dragLost.frame(point(.2,.5),73000);
        dragLost.frame(new double[][]{{2,.7,.5,45,45}},73040);
        check(dragLostOut.mice.size()==2&&dragLostOut.mice.get(1)[0]==0,"lost dragged contact releases without teleport");
        Recorder repeatOut=new Recorder();GestureEngine repeatJump=new GestureEngine(repeatOut);
        repeatJump.frame(point(.2,.5),74000);repeatJump.frame(point(.8,.5),74016);
        repeatJump.frame(point(.8,.5),74032);repeatJump.frame(point(.8,.5),74048);repeatJump.tick(74048);
        check(repeatOut.mice.isEmpty(),"rejected discontinuity must rebase rather than reappear a frame later");
        RelativeMotion noInertia=new RelativeMotion();noInertia.settings(1,0);noInertia.beginScroll(53000);noInertia.scroll(2.72,0,53016);noInertia.step(53016);noInertia.step(53032);noInertia.releaseScroll(53040);check(noInertia.step(53056)[2]==0,"zero inertia disables new momentum");
        Recorder lockOut=new Recorder();GestureEngine lock=new GestureEngine(lockOut);lock.setFeel(1,1,true);
        lock.frame(point(.5,.5),54000);lock.frame(new double[0][],54080);lock.frame(point(.5,.5),54200);lock.frame(point(.6,.5),54250);lock.tick(54266);lock.frame(new double[0][],54280);
        check(lockOut.mice.get(lockOut.mice.size()-1)[0]==1,"optional drag lock holds left after movement and lift");
        lock.frame(point(.2,.5),54500);lock.frame(new double[0][],54580);check(lockOut.mice.get(lockOut.mice.size()-1)[0]==0,"tap ends a latched drag without another click");
        lock.frame(point(.5,.5),55000);lock.frame(new double[0][],55080);lock.frame(point(.5,.5),55200);lock.frame(point(.6,.5),55250);lock.frame(new double[0][],55280);lock.tick(60300);check(lockOut.mice.get(lockOut.mice.size()-1)[0]==0,"drag latch must release after five idle seconds");
        Recorder twice=new Recorder();GestureEngine doubleTap=new GestureEngine(twice);
        doubleTap.frame(point(.5,.5),20000);doubleTap.frame(new double[0][],20080);
        doubleTap.frame(point(.5,.5),20200);doubleTap.frame(point(.503,.501),20230);
        doubleTap.tick(20245);doubleTap.frame(new double[0][],20280);doubleTap.tick(20300);
        check(twice.clicks(1)==2,"two taps must produce two left button press/release pairs");
        check(twice.mice.stream().noneMatch(v->v[1]!=0||v[2]!=0),"second tap jitter must not move the double-click target");
        for(int n=3;n<=4;n++){
            Recorder tapsOut=new Recorder();GestureEngine taps=new GestureEngine(tapsOut);
            taps.frame(fingers(n,0),80000);
            for(int left=n-1;left>=1;left--)taps.frame(fingers(left,0),80000+(n-left)*40);
            taps.frame(new double[0][],80200);
            check(tapsOut.mice.isEmpty()&&tapsOut.keys.isEmpty(),"three/four-finger tap with staggered lift must be silent");
            taps.frame(fingers(n,0),81000);taps.frame(fingers(n,.12),81080);
            for(int left=n-1;left>=1;left--)taps.frame(fingers(left,.12),81100+(n-left)*20);
            taps.frame(new double[0][],81200);
            check(tapsOut.keys.size()==1,"real three/four-finger swipes must remain enabled");
        }
        check(HidReports.macKey(21)==33&&HidReports.macModifiers(1179648)==10,"Bluetooth screenshot is Command+Shift+4");
        EdgeSwipe edge=new EdgeSwipe();
        edge.frame(new double[][]{{.98,.4}},1000,.95);
        check(!edge.frame(new double[][]{{.98,.4},{.97,.5}},1050,.95),"edge swipe must not fire on touch down");
        check(edge.frame(new double[][]{{.90,.4},{.89,.5}},1120,.95),"two fingers inward from edge must fire once");
        check(!edge.frame(new double[][]{{.85,.4},{.84,.5}},1150,.95),"edge swipe must not repeat");
        edge.frame(new double[0][],1200,.95);
        check(!edge.frame(new double[][]{{.7,.4},{.69,.5}},1300,.95),"ordinary two-finger scroll is not an edge gesture");
        final StringBuilder mac=new StringBuilder("before ");final boolean[] ready={true};
        RemoteComposer ime=new RemoteComposer(new RemoteComposer.Sink(){
            public boolean ready(){return ready[0];}
            public void text(String s){mac.append(s);}
            public void backspace(int n){mac.setLength(Math.max(0,mac.length()-n));}
            public void key(int usage){}
            public void unsupported(){}
        });
        ime.compose("hello");check(mac.toString().equals("before hello"),"composing English is already present on Mac");
        ime.compose("hell");check(mac.toString().equals("before hell"),"IME composing-text deletion immediately edits Mac");
        ime.commit("hell");check(mac.toString().equals("before hell"),"commit must not duplicate mirrored text");
        ime.delete(1,0);check(mac.toString().equals("before hel"),"first delete after commit edits Mac even with no local text");
        ime.compose("abc");ime.compose("axc");check(mac.toString().equals("before helaxc"),"autocorrection updates remote composing suffix");
        ime.commit("axc");ime.delete(3,0);check(mac.toString().equals("before hel"),"delete count applies to remote content");
        String snapshot=mac.toString();check(!ime.commit("中文"),"Bluetooth must reject unsupported Unicode");
        check(mac.toString().equals(snapshot),"unsupported input must not change Mac text");
        ready[0]=false;ime.compose("offline");ime.delete(5,0);
        check(mac.toString().equals(snapshot)&&ime.surrounding().isEmpty(),"offline input must not leave remote composing state");
        final StringBuilder lanMac=new StringBuilder("remote ");
        final int[] deletes={0};
        RemoteComposer lanIme=new RemoteComposer(new RemoteComposer.Sink(){
            public boolean ready(){return true;}public boolean unicode(){return true;}
            public void text(String value){lanMac.append(value);}
            public void backspace(int count){deletes[0]+=count;for(int i=0;i<count&&lanMac.length()>0;i++)lanMac.setLength(lanMac.offsetByCodePoints(lanMac.length(),-1));}
            public void key(int usage){}public void unsupported(){throw new AssertionError("LAN Unicode rejected");}
        });
        lanIme.compose("hello");int previousDeletes=deletes[0];lanIme.compose("hell");
        check(deletes[0]==previousDeletes+1&&lanMac.toString().equals("remote hell"),"LAN English composing delete forwards exactly one remote backspace");
        lanIme.commit("hell");previousDeletes=deletes[0];lanIme.delete(1,0);
        check(deletes[0]==previousDeletes+1&&lanMac.toString().equals("remote hel"),"LAN first post-commit delete forwards exactly once");
        lanIme.compose("zhongwen");lanIme.commit("中文");
        check(lanMac.toString().equals("remote hel中文"),"LAN pinyin conversion preserves Chinese without duplicate commit");
        lanIme.delete(1,0);check(lanMac.toString().equals("remote hel中"),"LAN Chinese delete removes one remote character");
        lanIme.compose("😀");lanIme.compose("😃");lanIme.commit("😃");lanIme.delete(1,0);
        check(lanMac.toString().equals("remote hel中"),"Unicode suffix replacement never splits a surrogate pair");
        System.out.println("Gesture/report checks passed: tap, move, hold, scroll, staggered lift, drag cancellation, invalid/palm/duplicate contacts, HID layout, key mapping, ASCII.");
        System.out.println("Additional checks passed: double-tap target stability, right-edge notification gesture, native IME composing/commit/delete synchronization and offline reset.");
    }
}
