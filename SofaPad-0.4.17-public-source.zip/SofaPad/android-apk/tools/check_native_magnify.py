#!/usr/bin/env python3
"""Build actual Quartz events, inspect AppKit + an optional real preview handler.
CGEventPost is intercepted; no global input, windows or real project PDFs.
Primary references: Apple NSEvent.magnification; Hammerspoon eventtap.newGesture;
https://github.com/noah-nuebling/mac-mouse-fix/discussions/366 (gesture fields).
Fields are undocumented; passing this test does not certify every macOS/app.
"""
import argparse,ast,ctypes,math,subprocess,tempfile
from pathlib import Path
parser=argparse.ArgumentParser();parser.add_argument('--source',type=Path,default=Path(__file__).resolve().parents[2]/'trackpad.py');parser.add_argument('--preview-source',type=Path);args=parser.parse_args()
handler='- (NSEvent *)handlePdfPreviewEvent:(NSEvent *)event { return event; }'
if args.preview_source:
    text=args.preview_source.read_text();start=text.index('- (NSEvent *)handlePdfPreviewEvent:');end=text.index('- (void)installScrollPhaseBridge',start);handler=text[start:end]
objc='''#import <AppKit/AppKit.h>
#import <PDFKit/PDFKit.h>
#import <WebKit/WebKit.h>
@interface PreviewOwner:NSObject
@property(nonatomic,strong) PDFView *pdfView;
@property(nonatomic,strong) WKWebView *webView;
- (void)closeNativePdfPreview;
- (NSEvent *)handlePdfPreviewEvent:(NSEvent *)event;
@end
@implementation PreviewOwner
- (void)closeNativePdfPreview {}
HANDLER
@end
int inspectEvent(CGEventRef cg,double amount,int phase,const char *pdfPath,int checkPreview){@autoreleasepool{
 NSEvent *event=[NSEvent eventWithCGEvent:cg];
 NSEventPhase expected=phase==1?NSEventPhaseBegan:phase==2?NSEventPhaseChanged:phase==4?NSEventPhaseEnded:NSEventPhaseCancelled;
 if(!event||event.type!=NSEventTypeMagnify||event.phase!=expected||fabs(event.magnification-amount)>1e-8)return 1;
 if(checkPreview){
  [NSApplication sharedApplication];PreviewOwner *owner=[PreviewOwner new];
  owner.pdfView=[[PDFView alloc] initWithFrame:NSMakeRect(0,0,10000,10000)];
  owner.pdfView.document=[[PDFDocument alloc] initWithURL:[NSURL fileURLWithPath:[NSString stringWithUTF8String:pdfPath]]];
  owner.pdfView.minScaleFactor=.1;owner.pdfView.maxScaleFactor=6;owner.pdfView.scaleFactor=1;
  double before=owner.pdfView.scaleFactor;
  NSEvent *returned=[owner handlePdfPreviewEvent:event];
  if(returned!=nil||fabs(owner.pdfView.scaleFactor-before*(1+amount))>1e-6)return 2;
 }
 return 0;
}}
'''.replace('HANDLER',handler)
# A disposable, blank single-page PDF; no user documents.
def pdf():
    objects=[b'<< /Type /Catalog /Pages 2 0 R >>',b'<< /Type /Pages /Kids [3 0 R] /Count 1 >>',b'<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Resources << >> >>']
    data=bytearray(b'%PDF-1.4\n');offsets=[0]
    for i,o in enumerate(objects,1):offsets.append(len(data));data.extend(str(i).encode()+b' 0 obj\n'+o+b'\nendobj\n')
    at=len(data);data.extend(b'xref\n0 4\n0000000000 65535 f \n')
    for o in offsets[1:]:data.extend(('%010d 00000 n \n'%o).encode())
    data.extend(('trailer\n<< /Size 4 /Root 1 0 R >>\nstartxref\n%d\n%%%%EOF\n'%at).encode());return bytes(data)
with tempfile.TemporaryDirectory(prefix='trackpad-magnify-test-') as folder:
    tmp=Path(folder);(tmp/'probe.m').write_text(objc);(tmp/'blank.pdf').write_bytes(pdf())
    subprocess.run(['/usr/bin/clang','-fobjc-arc','-dynamiclib','-framework','AppKit','-framework','PDFKit','-framework','WebKit',str(tmp/'probe.m'),'-o',str(tmp/'probe.dylib')],check=True)
    bridge=ctypes.CDLL(str(tmp/'probe.dylib'));bridge.inspectEvent.argtypes=[ctypes.c_void_p,ctypes.c_double,ctypes.c_int,ctypes.c_char_p,ctypes.c_int];bridge.inspectEvent.restype=ctypes.c_int
    tree=ast.parse(args.source.read_text());point=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='CGPoint');fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='native_magnify')
    ns={'ctypes':ctypes,'math':math,'cursor_pos':lambda:(100,100),'TAP_HID':0}
    exec(compile(ast.Module(body=[point],type_ignores=[]),'point','exec'),ns)
    cg=ctypes.CDLL('/System/Library/Frameworks/CoreGraphics.framework/CoreGraphics');cf=ctypes.CDLL('/System/Library/Frameworks/CoreFoundation.framework/CoreFoundation')
    cg.CGEventCreate.argtypes=[ctypes.c_void_p];cg.CGEventCreate.restype=ctypes.c_void_p
    cg.CGEventSetType.argtypes=[ctypes.c_void_p,ctypes.c_uint32];cg.CGEventSetFlags.argtypes=[ctypes.c_void_p,ctypes.c_uint64]
    cg.CGEventSetIntegerValueField.argtypes=[ctypes.c_void_p,ctypes.c_uint32,ctypes.c_int64];cg.CGEventSetDoubleValueField.argtypes=[ctypes.c_void_p,ctypes.c_uint32,ctypes.c_double];cg.CGEventSetLocation.argtypes=[ctypes.c_void_p,ns['CGPoint']];cf.CFRelease.argtypes=[ctypes.c_void_p]
    expected=[];captured=[]
    class NoPost:
        def __getattr__(self,name):return getattr(cg,name)
        def CGEventPost(self,target,event):
            amount,phase=expected[-1];result=bridge.inspectEvent(event,amount,phase,str(tmp/'blank.pdf').encode(),int(bool(args.preview_source)))
            assert result==0,('native event/preview verification failed',result,amount,phase)
            captured.append((amount,phase))
    ns.update(cg=NoPost(),cf=cf);exec(compile(ast.Module(body=[fn],type_ignores=[]),'native-magnify','exec'),ns)
    for amount,phase in [(0,1),(.125,2),(-.1,2),(0,4),(0,8)]:
        expected.append((amount,phase));assert ns['native_magnify'](amount,phase)
    assert len(captured)==5
    print('Actual Python Quartz -> AppKit magnify conversion passed: phase and amount preserved; global post intercepted.')
    if args.preview_source:print('Actual knowledge-app preview handler + PDFKit disposable PDF passed: enlarge, shrink and zero-delta phases; no user data/windows/global input.')
