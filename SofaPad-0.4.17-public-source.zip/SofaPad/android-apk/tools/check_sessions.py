#!/usr/bin/env python3
"""Plain LAN session policy in isolated state and loopback admin; no Mac input."""
import base64,json,stat,sys,tempfile,time,urllib.request,urllib.error
from pathlib import Path
sys.dont_write_bytecode=True
sys.path.insert(0,str(Path(__file__).resolve().parents[2]))
from trackpad_security import SecureReceiver,COOKIE,digest
class Capture:
 def __init__(self):self.data=b''
 def sendall(self,b):self.data+=b
 def shutdown(self,*a):pass
 def close(self):pass
with tempfile.TemporaryDirectory(prefix='trackpad-session-test-') as folder:
 root=Path(folder);(root/'legacy.crt').write_bytes(b'untouched rollback fixture')
 sec=SecureReceiver(root,names=['192.168.50.10','mac.local'],bootstrap_port=0)
 def capsule():
  raw=sec.capsule();return json.loads(base64.urlsafe_b64decode(raw+'='*(-len(raw)%4)))
 cap=capsule();assert cap['origin']=='http://192.168.50.10:8765' and cap['receiver']==sec.identity
 assert set(cap)=={'origin','origins','receiver','code'} and sec.names==['127.0.0.1','192.168.50.10']
 saved=SecureReceiver(root,names=['192.168.50.10'],bootstrap_port=0)
 assert saved.identity==sec.identity and saved.admin==sec.admin
 ident,token=saved.issue(cap['code'],'fixture device','isolated')
 try:saved.issue(cap['code'],'replay','isolated');raise AssertionError('QR replay accepted')
 except PermissionError:pass
 sec=saved;expired=capsule();sec.codes[digest(expired['code'])]=time.time()-1
 try:sec.issue(expired['code'],'expired','isolated');raise AssertionError('expired QR accepted')
 except PermissionError:pass
 headers={'host':'192.168.50.10:8765','origin':'http://192.168.50.10:8765','cookie':COOKIE+'='+token}
 assert sec.authenticated(headers)==ident
 cookie=sec.session_cookie(token,{})
 assert 'HttpOnly' in cookie and 'SameSite=Strict' in cookie and 'Secure' not in cookie
 a,b=Capture(),Capture();assert sec.claim(ident,a) and not sec.claim(ident,b);sec.release(a);assert sec.claim(ident,b);sec.release(b)
 restarted=SecureReceiver(root,names=['192.168.50.10'],bootstrap_port=0)
 assert restarted.authenticated(headers)==ident and token not in (root/'devices.json').read_text()
 restarted.revoke(ident);assert restarted.authenticated(headers) is None
 assert (root/'legacy.crt').read_bytes()==b'untouched rollback fixture' and not list(root.glob('*.key'))
 for path in root.glob('*.json'):assert stat.S_IMODE(path.stat().st_mode)==0o600
 assert stat.S_IMODE(root.stat().st_mode)==0o700
 # An old selected IP is replaced when the Mac changes network and refreshes its QR.
 restarted._discover_addresses=True;restarted.discover_names=lambda:['10.50.0.10'];restarted.refresh_addresses()
 assert restarted.names==['127.0.0.1','10.50.0.10'] and restarted.origin=='http://10.50.0.10:8765'
 server=restarted.bootstrap(bind='127.0.0.1');base='http://127.0.0.1:'+str(server.server_address[1])
 def get(path,authorized=False):
  request=urllib.request.Request(base+path,headers={'X-Trackpad-Admin':restarted.admin} if authorized else {})
  try:
   with urllib.request.urlopen(request,timeout=3) as response:return response.status,response.read()
  except urllib.error.HTTPError as error:return error.code,error.read()
 try:
  assert get('/api/admin')[0]==403 and get('/api/admin/devices')[0]==403
  assert get('/ca.crt')[0]==403 and get('/install')[0]==403,'no certificate installation endpoint'
  status,body=get('/api/admin?host=192.168.50.10',True);data=json.loads(body)
  assert status==200 and data['selectedHost']=='10.50.0.10' and data['origin'].startswith('http://10.50.0.10:')
  assert 'qr' in data and 'qrApk' not in data and 'qrInstall' not in data and 'fingerprint' not in data
 finally:server.shutdown();server.server_close()
print('LAN sessions passed: IP-only shared QR, no certificates, persistent receiver/device identity, one-use/expiry, HttpOnly HTTP cookie, private hashed registry, exclusive control, revocation, local admin capability and network-change QR refresh. Isolated state only.')
