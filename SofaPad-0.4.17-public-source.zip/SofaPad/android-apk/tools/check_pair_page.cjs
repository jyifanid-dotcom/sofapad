/* Actual local admin page script; fake storage/fetch, no real capabilities. */
const cp=require('node:child_process'),vm=require('node:vm'),assert=require('node:assert/strict'),path=require('node:path');
const source=process.argv[2]||path.join(__dirname,'../../trackpad_security.py');
const html=cp.execFileSync('python3',['-c',"import importlib.util,sys; s=importlib.util.spec_from_file_location('pair_test_module',sys.argv[1]); m=importlib.util.module_from_spec(s); s.loader.exec_module(m); print(m.admin_page())",source],{encoding:'utf8'});
const script=[...html.matchAll(/<script>([\s\S]*?)<\/script>/g)][0][1];
const fakeToken='fixture-admin-capability-'+'x'.repeat(24); // Test data only.
function fixture(hash,storage){
 const ids={},requests=[];const node=()=>({textContent:'',innerHTML:'',children:[],appendChild(v){this.children.push(v);}});
 const c={console,Promise,JSON,encodeURIComponent,location:{hash,pathname:'/admin'},document:{getElementById:id=>ids[id]||=node(),createElement:()=>node()},
 history:{replaceState(){c.location.hash='';}},sessionStorage:{setItem:(k,v)=>storage.set(k,v),getItem:k=>storage.get(k)||null},setInterval(){},
 fetch:async(url,opts)=>{requests.push({url,token:opts.headers['X-Trackpad-Admin']});const ok=opts.headers['X-Trackpad-Admin']===fakeToken;return{ok,json:async()=>({hosts:['192.168.50.10'],selectedHost:'192.168.50.10',qr:'web fixture',devices:[],pending:[],inputStatus:{machine:'fixture',inputReady:true}})};}};
 vm.createContext(c);vm.runInContext(script,c);return{c,ids,requests};
}
(async()=>{
 const storage=new Map(),first=fixture('#'+fakeToken,storage);await first.c.refresh();
 assert.equal(first.c.location.hash,'','capability removed from address bar');assert.equal(first.ids.qr.innerHTML,'web fixture');
 const reload=fixture('',storage);await reload.c.refresh();
 assert.equal((reload.ids.qr||{innerHTML:''}).innerHTML,'web fixture','page reload restores management authorization and QR');
 assert(reload.requests.every(r=>r.token===fakeToken),'all reload requests use the same tab capability');
 const other=fixture('',new Map());await other.c.refresh();assert.equal(other.ids.qr.innerHTML,'','a new unauthorized tab cannot acquire the capability');
 reload.c.fetch=async()=>({ok:false});await reload.c.refresh();assert.equal(reload.ids.qr.innerHTML,'','failed refresh cannot leave a stale QR displayed');
 assert(reload.ids.status.textContent.includes('重新打开'),'invalid authorization gives a recovery instruction');
 console.log('Pairing admin page checks passed: first-open hash hiding, refresh persistence in same tab, separate-tab isolation and stale-QR removal on failure. Fake capability only.');
})().catch(e=>{console.error(e);process.exitCode=1;});
