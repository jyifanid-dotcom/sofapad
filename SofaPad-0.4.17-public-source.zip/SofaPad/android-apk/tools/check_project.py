#!/usr/bin/env python3
"""Static package checks, also run before cloud compilation. Does not certify an APK."""
import hashlib
import json
import re
import xml.etree.ElementTree as ET
from pathlib import Path

root = Path(__file__).resolve().parents[1]
for path in root.rglob('*.xml'):
    ET.parse(path)
page = root/'app/src/main/assets/index.html'
source = json.loads((root/'PAGE_SOURCE.json').read_text())
assert hashlib.sha256(page.read_bytes()).hexdigest() == source['page_sha256'], 'Page provenance mismatch'
text = page.read_text()
assert 'TrackpadNative' in text and 'nativeConnection' in text
assert "url('/pad.png')" not in text
assert 'pointercancel' in text and '"cancel":true' in text
assert 'nativeCount' in text and 'setPointerCapture' in text
for java in root.glob('app/src/main/java/**/*.java'):
    assert 'package cc.trackpad.tablet;' in java.read_text(), java
manifest = (root/'app/src/main/AndroidManifest.xml').read_text()
assert 'BOOT_COMPLETED' not in manifest and '<service' not in manifest
assert 'usesCleartextTraffic="true"' in manifest, 'User-requested HTTP LAN mode is required'
transport=(root/'app/src/main/java/cc/trackpad/tablet/LanConnection.java').read_text()
assert 'new Socket()' in transport and 'SSLContext' not in transport and 'getHost' in transport
assert not (root/'app/src/main/java/cc/trackpad/tablet/SecureLan.java').exists()
assert 'android:scheme="trackpad"' in manifest, 'Camera pairing deep link missing'
assert 'android.permission.CAMERA' in manifest and 'android:name=".QrScanActivity" android:exported="false"' in manifest
assert 'READ_MEDIA_IMAGES' not in manifest and 'READ_EXTERNAL_STORAGE' not in manifest
qr=root/'app/libs/zxing-core-3.5.3.jar'
qr_info=json.loads((qr.parent/'ZXING_PROVENANCE.json').read_text())
assert hashlib.sha256(qr.read_bytes()).hexdigest()==qr_info['sha256'], 'Offline QR decoder hash mismatch'
assert (root/'app/src/main/assets/licenses/ZXing-LICENSE.txt').stat().st_size>10000
assert 'BLUETOOTH_CONNECT' in manifest and 'BLUETOOTH_ADVERTISE' in manifest
assert 'READ_EXTERNAL_STORAGE' not in manifest and 'ACCESS_FINE_LOCATION' not in manifest
for path in root.rglob('*'):
    if path.is_file() and not any(x in path.parts for x in ['build','.gradle','.local-signing','dist']):
        assert path.suffix not in ['.log','.plist','.bak','.jks','.keystore'], f'Unexpected upload file: {path}'
        if path.suffix in ['.java','.html','.gradle','.yml']:
            # Documentation examples are fine; device addresses must not be a loadUrl default.
            assert not re.search(r'loadUrl\("https?://(?:192\.168\.|10\.)',path.read_text()), f'Hardcoded connection: {path}'
print('Static package checks passed: XML, page hash, permission scope, local assets, no logs/backups/keys.')
