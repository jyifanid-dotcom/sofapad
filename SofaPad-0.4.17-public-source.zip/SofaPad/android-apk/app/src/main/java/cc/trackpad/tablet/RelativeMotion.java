package cc.trackpad.tablet;

/** Bounded pointer smoothing plus velocity-sensitive, interruptible wheel momentum. */
public final class RelativeMotion {
    private double x, y, wheel, pan, velocityWheel, velocityPan;
    private long lastTick, lastScroll, released;
    private boolean momentum;
    private double scrollSpeed=1,inertia=1;
    public void settings(double speed,double strength){scrollSpeed=Math.max(.5,Math.min(2,speed));inertia=Math.max(0,Math.min(1.5,strength));}
    public void lockAxis(int axis){if(axis==1){pan=velocityPan=0;}else if(axis==2){wheel=velocityWheel=0;}}
    public void add(double dx, double dy) { x += dx; y += dy; }
    public void beginScroll(long now) {
        wheel=pan=velocityWheel=velocityPan=0;momentum=false;lastScroll=now;released=0;
    }
    public void scroll(double vertical,double horizontal) { scroll(vertical,horizontal,lastScroll+16); }
    public void scroll(double vertical, double horizontal,long now) {
        double dt=Math.max(.008,Math.min(.08,(now-lastScroll)/1000.0));
        double speed=Math.hypot(vertical,horizontal)/34/dt;
        double gain=1+Math.min(3,Math.max(0,speed-.25)*1.6);
        vertical*=gain*scrollSpeed;horizontal*=gain*scrollSpeed;
        wheel=Math.max(-34,Math.min(34,wheel+vertical));
        pan=Math.max(-34,Math.min(34,pan+horizontal));
        double alpha=1-Math.exp(-dt/.035);
        double v=vertical/dt,p=horizontal/dt,length=Math.hypot(v,p);
        if(length>102*scrollSpeed){v*=102*scrollSpeed/length;p*=102*scrollSpeed/length;}
        if(v*velocityWheel+p*velocityPan<0){velocityWheel=velocityPan=0;wheel=vertical;pan=horizontal;}
        velocityWheel+=(v-velocityWheel)*alpha;velocityPan+=(p-velocityPan)*alpha;
        lastScroll=now;momentum=false;
    }
    public void releaseScroll(long now) {
        momentum=inertia>0&&now-lastScroll<=90&&Math.hypot(velocityWheel,velocityPan)>11.9;
        released=now;
    }
    public int[] step(long now) {
        double dt = lastTick == 0 ? 16 : Math.max(1,Math.min(40,now-lastTick));
        lastTick = now;
        if(momentum){
            double tau=180*Math.max(.05,inertia);double decay=Math.exp(-dt/tau);
            wheel+=velocityWheel*tau/1000*(1-decay);pan+=velocityPan*tau/1000*(1-decay);
            velocityWheel*=decay;velocityPan*=decay;
            if(now-released>=700*inertia||Math.hypot(velocityWheel,velocityPan)<1.7)momentum=false;
        }
        double alpha = Math.hypot(x,y)>18 ? .86 : 1-Math.exp(-dt/18.0);
        int dx=(int)Math.rint(x*alpha), dy=(int)Math.rint(y*alpha);
        x-=dx; y-=dy;
        int w=(int)Math.max(-8,Math.min(8,wheel)), p=(int)Math.max(-8,Math.min(8,pan));
        wheel-=w; pan-=p;
        return new int[]{dx,dy,w,p};
    }
    public int[] drainPointer() {
        int dx=(int)Math.rint(x),dy=(int)Math.rint(y); x=y=0;
        return new int[]{dx,dy};
    }
    public void clear() { x=y=wheel=pan=velocityWheel=velocityPan=0;lastTick=lastScroll=released=0;momentum=false; }
}
