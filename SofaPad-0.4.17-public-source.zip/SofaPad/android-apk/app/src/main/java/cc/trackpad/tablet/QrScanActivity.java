package cc.trackpad.tablet;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.ImageFormat;
import android.hardware.Camera;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.Gravity;
import android.view.Surface;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.atomic.AtomicBoolean;

/** Small built-in scanner, no external scanning app, Google service or camera upload. */
@SuppressWarnings("deprecation")
public final class QrScanActivity extends Activity implements SurfaceHolder.Callback {
    private final ExecutorService decoder=Executors.newSingleThreadExecutor();
    private final AtomicBoolean decoding=new AtomicBoolean();
    private final QrDecoder qr=new QrDecoder();
    private SurfaceView preview;
    private FrameLayout previewArea;
    private TextView hint;
    private Camera camera;
    private boolean resumed,surfaceReady,permissionAsked,completed;
    private int width,height,rotation,generation;
    private long lastFrame;
    @Override public void onCreate(Bundle saved){
        super.onCreate(saved);getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON|WindowManager.LayoutParams.FLAG_SECURE);
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(Color.rgb(8,10,13));
        hint=new TextView(this);hint.setTextColor(Color.WHITE);hint.setTextSize(17);hint.setPadding(24,28,24,20);hint.setGravity(Gravity.CENTER);hint.setText("Mac打开触摸板图标\n对准二维码，扫码后自动连接");root.addView(hint);
        previewArea=new FrameLayout(this);root.addView(previewArea,new LinearLayout.LayoutParams(-1,0,1));
        preview=new SurfaceView(this);previewArea.addView(preview,new FrameLayout.LayoutParams(-1,-1,Gravity.CENTER));preview.getHolder().addCallback(this);
        previewArea.addOnLayoutChangeListener((v,l,t,r,b,ol,ot,or,ob)->fitPreview());
        Button cancel=new Button(this);cancel.setText("取消，返回连接设置");cancel.setOnClickListener(v->finish());root.addView(cancel,new LinearLayout.LayoutParams(-1,64));
        setContentView(root);
    }
    @Override protected void onResume(){super.onResume();resumed=true;
        if(checkSelfPermission(Manifest.permission.CAMERA)==PackageManager.PERMISSION_GRANTED)openCamera();
        else if(!permissionAsked){permissionAsked=true;requestPermissions(new String[]{Manifest.permission.CAMERA},31);}
    }
    @Override protected void onPause(){resumed=false;releaseCamera();super.onPause();}
    @Override protected void onDestroy(){releaseCamera();decoder.shutdownNow();super.onDestroy();}
    @Override public void onRequestPermissionsResult(int request,String[] permissions,int[] grants){
        super.onRequestPermissionsResult(request,permissions,grants);
        if(request==31){if(checkSelfPermission(Manifest.permission.CAMERA)==PackageManager.PERMISSION_GRANTED)openCamera();else hint.setText("未允许相机权限。可返回后选择粘贴配对链接，或在系统应用权限中允许相机。");}
    }
    @Override public void surfaceCreated(SurfaceHolder holder){surfaceReady=true;openCamera();}
    @Override public void surfaceChanged(SurfaceHolder holder,int format,int w,int h){fitPreview();}
    @Override public void surfaceDestroyed(SurfaceHolder holder){surfaceReady=false;releaseCamera();}
    private void openCamera(){
        if(!resumed||!surfaceReady||completed||camera!=null||checkSelfPermission(Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED)return;
        try{
            int id=-1;Camera.CameraInfo info=new Camera.CameraInfo();
            for(int i=0;i<Camera.getNumberOfCameras();i++){Camera.getCameraInfo(i,info);if(info.facing==Camera.CameraInfo.CAMERA_FACING_BACK){id=i;break;}}
            if(id<0)throw new IllegalStateException("No rear camera");
            Camera current=Camera.open(id);camera=current;Camera.Parameters params=current.getParameters();
            Camera.Size best=null;double score=Double.MAX_VALUE;
            for(Camera.Size size:params.getSupportedPreviewSizes()){
                if(size.width>1920||size.height>1080)continue;
                double next=Math.abs(size.width*size.height-1280.0*720);
                if(next<score){score=next;best=size;}
            }
            if(best!=null)params.setPreviewSize(best.width,best.height);
            params.setPreviewFormat(ImageFormat.NV21);
            List<String> focus=params.getSupportedFocusModes();
            if(focus!=null&&focus.contains(Camera.Parameters.FOCUS_MODE_CONTINUOUS_PICTURE))params.setFocusMode(Camera.Parameters.FOCUS_MODE_CONTINUOUS_PICTURE);
            else if(focus!=null&&focus.contains(Camera.Parameters.FOCUS_MODE_CONTINUOUS_VIDEO))params.setFocusMode(Camera.Parameters.FOCUS_MODE_CONTINUOUS_VIDEO);
            current.setParameters(params);Camera.Size size=current.getParameters().getPreviewSize();width=size.width;height=size.height;
            int display=getWindowManager().getDefaultDisplay().getRotation();int degrees=display==Surface.ROTATION_90?90:display==Surface.ROTATION_180?180:display==Surface.ROTATION_270?270:0;
            rotation=(info.orientation-degrees+360)%360;current.setDisplayOrientation(rotation);fitPreview();
            current.setPreviewDisplay(preview.getHolder());final int token=++generation;
            current.setPreviewCallbackWithBuffer((data,source)->frame(data,source,token));
            int length=width*height*ImageFormat.getBitsPerPixel(ImageFormat.NV21)/8;
            current.addCallbackBuffer(new byte[length]);current.addCallbackBuffer(new byte[length]);current.startPreview();
        }catch(Exception failure){releaseCamera();hint.setText("相机暂不可用，请检查相机权限或关闭占用相机的应用，再重试。也可返回粘贴链接配对。");}
    }
    private void fitPreview(){
        if(width<=0||height<=0||previewArea.getWidth()==0||previewArea.getHeight()==0)return;
        float aspect=(rotation==90||rotation==270)?height/(float)width:width/(float)height;
        int w=previewArea.getWidth(),h=Math.round(w/aspect);
        if(h>previewArea.getHeight()){h=previewArea.getHeight();w=Math.round(h*aspect);}
        FrameLayout.LayoutParams old=(FrameLayout.LayoutParams)preview.getLayoutParams();
        if(old.width!=w||old.height!=h)preview.setLayoutParams(new FrameLayout.LayoutParams(w,h,Gravity.CENTER));
    }
    private void frame(byte[] data,Camera source,int token){
        if(source!=camera||token!=generation||!resumed||completed)return;
        long now=SystemClock.uptimeMillis();
        if(now-lastFrame<160||!decoding.compareAndSet(false,true)){source.addCallbackBuffer(data);return;}
        lastFrame=now;final int w=width,h=height;byte[] luma=Arrays.copyOf(data,w*h);source.addCallbackBuffer(data);
        try{decoder.execute(()->{
            String result=null;try{result=qr.decode(luma,w,h);}catch(RuntimeException ignored){}finally{Arrays.fill(luma,(byte)0);decoding.set(false);}
            if(result==null)return;final String link=result;
            runOnUiThread(()->{
                if(token!=generation||!resumed||completed||isFinishing())return;
                try{PairingRequest.payload(link);}catch(Exception invalid){hint.setText("这不是触摸板连接二维码，请对准Mac配对页中的网页连接码或APK专用码。");return;}
                completed=true;setResult(RESULT_OK,new Intent().putExtra("pairLink",link));releaseCamera();finish();
            });
        });}catch(RejectedExecutionException ignored){decoding.set(false);}
    }
    private void releaseCamera(){
        generation++;Camera old=camera;camera=null;
        if(old!=null){try{old.setPreviewCallbackWithBuffer(null);old.stopPreview();}catch(RuntimeException ignored){}try{old.release();}catch(RuntimeException ignored){}}
    }
}
