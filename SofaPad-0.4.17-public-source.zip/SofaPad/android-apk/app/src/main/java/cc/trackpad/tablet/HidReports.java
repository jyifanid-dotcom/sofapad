package cc.trackpad.tablet;

/** Standard relative mouse + boot-layout keyboard reports; no vendor/Apple protocol. */
public final class HidReports {
    private HidReports() {}
    public static final int MOUSE = 1, KEYBOARD = 2, CONSUMER = 3;
    public static final byte[] DESCRIPTOR = hex(
        // Mouse: buttons, signed 16-bit relative x/y, wheel, horizontal pan.
        "05 01 09 02 A1 01 85 01 09 01 A1 00 " +
        "05 09 19 01 29 03 15 00 25 01 95 03 75 01 81 02 " +
        "95 01 75 05 81 03 " +
        "05 01 09 30 09 31 16 01 80 26 FF 7F 75 10 95 02 81 06 " +
        "09 38 15 81 25 7F 75 08 95 01 81 06 " +
        "05 0C 0A 38 02 15 81 25 7F 75 08 95 01 81 06 C0 C0 " +
        // Keyboard: modifiers, reserved, six usages; no output/LED report.
        "05 01 09 06 A1 01 85 02 05 07 19 E0 29 E7 15 00 25 01 " +
        "75 01 95 08 81 02 75 08 95 01 81 03 " +
        "19 00 29 65 15 00 25 65 75 08 95 06 81 00 C0" +
        // Consumer volume up/down/mute, three bits plus padding.
        "05 0C 09 01 A1 01 85 03 15 00 25 01 09 E9 09 EA 09 E2 75 01 95 03 81 02 75 05 95 01 81 03 C0");

    private static byte[] hex(String s) {
        String[] parts = s.trim().split(" +");
        byte[] bytes = new byte[parts.length];
        for (int i = 0; i < parts.length; i++) bytes[i] = (byte) Integer.parseInt(parts[i], 16);
        return bytes;
    }

    public static byte[] mouse(int buttons, int dx, int dy, int wheel, int pan) {
        dx = Math.max(-32767, Math.min(32767, dx));
        dy = Math.max(-32767, Math.min(32767, dy));
        return new byte[] {(byte)(buttons & 7), (byte)dx, (byte)(dx >> 8),
            (byte)dy, (byte)(dy >> 8), (byte)Math.max(-127, Math.min(127, wheel)),
            (byte)Math.max(-127, Math.min(127, pan))};
    }

    public static byte[] keyboard(int modifiers, int usage) {
        return new byte[] {(byte)modifiers, 0, (byte)usage, 0, 0, 0, 0, 0};
    }

    public static int macKey(int code) {
        return switch (code) {
            case 0 -> 4; case 1 -> 22; case 6 -> 29; case 7 -> 27;
            case 8 -> 6; case 9 -> 25; case 12 -> 20; case 13 -> 26;
            case 21 -> 33; case 24 -> 46; case 27 -> 45; case 36 -> 40; case 48 -> 43;
            case 49 -> 44; case 51 -> 42; case 53 -> 41; case 103 -> 68;
            case 123 -> 80; case 124 -> 79; case 125 -> 81; case 126 -> 82;
            default -> 0;
        };
    }

    public static int macModifiers(int flags) {
        return ((flags & 0x40000) != 0 ? 1 : 0) | ((flags & 0x20000) != 0 ? 2 : 0)
            | ((flags & 0x80000) != 0 ? 4 : 0) | ((flags & 0x100000) != 0 ? 8 : 0);
    }

    /** US ANSI key position; actual text follows the Mac's active input source. */
    public static int[] ascii(char c) {
        if (c >= 'a' && c <= 'z') return new int[] {0, 4 + c - 'a'};
        if (c >= 'A' && c <= 'Z') return new int[] {2, 4 + c - 'A'};
        if (c >= '1' && c <= '9') return new int[] {0, 30 + c - '1'};
        if (c == '0') return new int[] {0, 39};
        // Explicit punctuation avoids relying on a locale keyboard layout.
        String normal = "-=[]\\;'`,./";
        String shifted = "_+{}|:\"~<>?";
        int[] usages = {45,46,47,48,49,51,52,53,54,55,56};
        int i = normal.indexOf(c);
        if (i >= 0) return new int[] {0, usages[i]};
        i = shifted.indexOf(c);
        if (i >= 0) return new int[] {2, usages[i]};
        i = "!@#$%^&*()".indexOf(c);
        if (i >= 0) return new int[] {2, i == 9 ? 39 : 30 + i};
        return switch (c) {
            case '\n', '\r' -> new int[] {0, 40};
            case '\t' -> new int[] {0, 43}; case ' ' -> new int[] {0, 44};
            default -> null;
        };
    }
}
