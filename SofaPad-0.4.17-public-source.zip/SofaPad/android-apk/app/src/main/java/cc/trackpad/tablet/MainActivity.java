package cc.trackpad.tablet;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.provider.Settings;
import android.view.View;
import android.view.WindowManager;
import android.view.MotionEvent;
import android.view.Gravity;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.inputmethod.InputMethodManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.SeekBar;
import android.widget.CheckBox;
import android.widget.ScrollView;
import android.widget.Toast;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.Executors;
import java.util.concurrent.ExecutorService;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public final class MainActivity extends Activity {
    private static final String LOCAL = "https://appassets.androidplatform.net/assets/index.html";
    private final Handler main = new Handler(Looper.getMainLooper());
    private SharedPreferences prefs;
    private FrameLayout layout;
    private LinearLayout rail;
    private Button connectionButton;
    private WebView web;
    private TextView panelStatus;
    private String statusMessage = "请选择连接方式";
    private String uiScript = "";
    private final ExecutorService network = Executors.newSingleThreadExecutor();
    private final EdgeSwipe notificationSwipe=new EdgeSwipe();
    private BluetoothController bluetooth;
    private LanConnection lan;
    private GestureEngine gestures;
    private volatile boolean wifi, foreground, pageReady;
    private volatile boolean online;
    private volatile int pageGeneration;
    private TextView panelDetails;
    private String macPowerStatus="";
    private volatile String wifiOrigin = "";
    private boolean pairingNow,pairingRequired,onboardingShown;
    private long lastNotice;
    private long lastEditorLayout,lastBluetoothPoll;
    private RemoteEditText remoteInput;
    private boolean remoteKeyboardOpen;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("trackpad", MODE_PRIVATE);
        wifi = prefs.getBoolean("wifi", true);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        layout = new FrameLayout(this);
        layout.setBackgroundColor(Color.rgb(8,10,13));
        if (Build.VERSION.SDK_INT >= 30) getWindow().setDecorFitsSystemWindows(true);
        try { uiScript=readAsset("app-ui.js"); }
        catch (IOException e) { throw new IllegalStateException("Missing packaged interface",e); }
        rail = new LinearLayout(this); rail.setOrientation(LinearLayout.VERTICAL);
        rail.setPadding(dp(12),dp(18),dp(12),0);
        FrameLayout.LayoutParams railParams = new FrameLayout.LayoutParams(dp(76),-1);
        layout.addView(rail,railParams);
        connectionButton = addTool("连接",this::showConnections);
        addTool("键盘",this::toggleKeyboard);
        addTool("手感",this::showPointerSettings);
        View edge=new View(this);
        FrameLayout.LayoutParams edgeParams=new FrameLayout.LayoutParams(dp(56),-1,Gravity.RIGHT);
        layout.addView(edge,edgeParams);
        edge.setContentDescription("从右侧黑色留白双指向左滑，打开 Mac 通知中心");
        edge.setOnTouchListener((view,event)->{
            int action=event.getActionMasked(),skip=action==MotionEvent.ACTION_POINTER_UP?event.getActionIndex():-1;
            boolean ended=action==MotionEvent.ACTION_UP||action==MotionEvent.ACTION_CANCEL;
            double[][] points=new double[ended?0:event.getPointerCount()-(skip>=0?1:0)][2];
            int j=0;for(int i=0;i<event.getPointerCount()&&!ended;i++)if(i!=skip){
                points[j][0]=(event.getX(i)+layout.getWidth()-view.getWidth())/Math.max(1.0,layout.getWidth());
                points[j++][1]=event.getY(i)/Math.max(1.0,layout.getHeight());
            }
            if(notificationSwipe.frame(points,SystemClock.uptimeMillis(),1-dp(56)/Math.max(1.0,layout.getWidth())))requestNotification();
            if(action==MotionEvent.ACTION_UP)view.performClick();return true;
        });
        setContentView(layout);
        makeWebView();
        handlePairIntent(getIntent());
    }

    private Button addTool(String text,Runnable action) {
        Button button = new Button(this); button.setText(text); button.setTextSize(12);
        button.setTextColor(Color.rgb(175,184,198)); button.setAllCaps(false); button.setPadding(0,0,0,0);
        GradientDrawable bg = new GradientDrawable(); bg.setColor(Color.rgb(23,27,34));
        bg.setCornerRadius(dp(16)); bg.setStroke(dp(1),Color.rgb(43,50,63));
        button.setBackground(bg);
        button.setContentDescription(text.equals("连接") ? "连接和模式设置" : "展开或收起键盘");
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(dp(52),dp(48)); p.bottomMargin=dp(12);
        rail.addView(button,p); button.setOnClickListener(v -> action.run()); return button;
    }
    private String readAsset(String name) throws IOException {
        try(java.io.InputStream in=getAssets().open(name);ByteArrayOutputStream out=new ByteArrayOutputStream()){
            byte[] buf=new byte[4096];int n;while((n=in.read(buf))!=-1)out.write(buf,0,n);
            return new String(out.toByteArray(),StandardCharsets.UTF_8);
        }
    }
    private String connectionDetails(){return "版本 0.4.17\nAPK通道："+(online?"已建立":"未建立")+"\n"+statusMessage+"\n"+(remoteInput==null?"编辑器未初始化":remoteInput.diagnostics())+"\n"+(wifi?"IP局域网直连（明文）\n"+(lan==null?"":lan.diagnostics())+macPowerStatus:bluetooth==null?"HID：尚未初始化":bluetooth.diagnostics());}
    private void setStatus(String message) {
        statusMessage=message;
        connectionButton.setText("连接\n"+(online?"●":"○"));connectionButton.setTextColor(online?Color.rgb(149,186,174):Color.rgb(175,184,198));
        if (panelStatus!=null) panelStatus.setText(message);
        if(panelDetails!=null)panelDetails.setText(connectionDetails());
        connectionButton.setContentDescription("连接和模式设置："+message);
    }
    private void showConnections() {
        cancelPointer();
        boolean remembered=PairingStore.paired(prefs)&&!pairingRequired;
        LinearLayout content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);content.setPadding(dp(20),dp(8),dp(20),dp(8));
        panelStatus=new TextView(this);panelStatus.setText(statusMessage);panelStatus.setPadding(0,0,0,dp(14));content.addView(panelStatus);
        TextView steps=new TextView(this);steps.setText(remembered?"已记住这台Mac；Mac换过Wi-Fi后，请重新扫码更新IP。":"Mac打开触摸板图标 → 点下面扫码 → 对准二维码即可。无需安装证书。");content.addView(steps);
        ScrollView scroll=new ScrollView(this);scroll.addView(content);
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle(remembered?"连接Mac":"首次连接Mac").setView(scroll).setNegativeButton("返回触摸板",null).create();
        Button connect=new Button(this);connect.setText(remembered?"连接这台Mac":"扫码连接Mac");content.addView(connect);
        connect.setOnClickListener(v->{dialog.dismiss();switchMode(true);if(remembered){stopLan();beginMode();}else scanPairing();});
        if(remembered){Button change=new Button(this);change.setText("换网络／换Mac／重新扫码");content.addView(change);change.setOnClickListener(v->{dialog.dismiss();switchMode(true);scanPairing();});}
        LinearLayout extras=new LinearLayout(this);extras.setOrientation(LinearLayout.VERTICAL);extras.setVisibility(View.GONE);
        Button more=new Button(this);more.setText("其他连接方式与诊断");content.addView(more);content.addView(extras);
        more.setOnClickListener(v->extras.setVisibility(extras.getVisibility()==View.VISIBLE?View.GONE:View.VISIBLE));
        Button bt=new Button(this);bt.setText("使用蓝牙");extras.addView(bt);bt.setOnClickListener(v->{dialog.dismiss();switchMode(false);chooseDevice();});
        Button paste=new Button(this);paste.setText("粘贴连接链接");extras.addView(paste);paste.setOnClickListener(v->{dialog.dismiss();switchMode(true);addressDialog();});
        panelDetails=new TextView(this);panelDetails.setText(connectionDetails());panelDetails.setTextIsSelectable(true);extras.addView(panelDetails);
        dialog.setOnDismissListener(d->{panelStatus=null;panelDetails=null;immersive();});dialog.show();
    }
    private void switchMode(boolean next) {
        if(next==wifi)return;
        stopLan();stopBluetooth();wifi=next;prefs.edit().putBoolean("wifi",wifi).apply();makeWebView();
        if(foreground)beginMode();
    }
    private void positionEditor(boolean focus) {
        if(web==null||remoteInput==null||!remoteKeyboardOpen)return;
        final int marker=pageGeneration;
        web.evaluateJavascript("(function(){var r=document.getElementById('kbInput').getBoundingClientRect();return [r.left,r.top,r.width,r.height,innerWidth];})()",value->{
            if(marker!=pageGeneration||!remoteKeyboardOpen)return;
            try{
                JSONArray rect=new JSONArray(value);double scale=web.getWidth()/Math.max(1,rect.getDouble(4));
                FrameLayout.LayoutParams p=new FrameLayout.LayoutParams(Math.max(1,(int)(rect.getDouble(2)*scale)),Math.max(1,(int)(rect.getDouble(3)*scale)));
                p.leftMargin=web.getLeft()+(int)(rect.getDouble(0)*scale);p.topMargin=web.getTop()+(int)(rect.getDouble(1)*scale);
                FrameLayout.LayoutParams old=(FrameLayout.LayoutParams)remoteInput.getLayoutParams();
                if(old.width!=p.width||old.height!=p.height||old.leftMargin!=p.leftMargin||old.topMargin!=p.topMargin)remoteInput.setLayoutParams(p);
                remoteInput.setVisibility(View.VISIBLE);
                if(focus){remoteInput.requestFocus();InputMethodManager ime=(InputMethodManager)getSystemService(INPUT_METHOD_SERVICE);if(ime!=null)ime.showSoftInput(remoteInput,InputMethodManager.SHOW_IMPLICIT);}
            }catch(JSONException ignored){}
        });
    }
    private void toggleKeyboard() {
        if(web==null||!pageReady){notice("请先连接触摸板页面");return;}
        cancelPointer();remoteKeyboardOpen=!remoteKeyboardOpen;
        if(!remoteKeyboardOpen){
            InputMethodManager ime=(InputMethodManager)getSystemService(INPUT_METHOD_SERVICE);
            if(ime!=null)ime.hideSoftInputFromWindow(remoteInput.getWindowToken(),0);
            remoteInput.clearFocus();remoteInput.resetRemoteComposition();remoteInput.setVisibility(View.GONE);
        }
        web.evaluateJavascript("if(window.setKb)setKb("+remoteKeyboardOpen+");",v->{if(remoteKeyboardOpen)positionEditor(true);});
    }
    private String feelScript(){
        return "if(window.trackpadSetSettings)trackpadSetSettings({pointerGain:"+prefs.getInt("pointerGain",720)+",scrollSpeed:"+prefs.getInt("scrollSpeed",100)/100.0+",inertia:"+prefs.getInt("inertia",100)/100.0+",dragLock:"+prefs.getBoolean("dragLock",false)+"});";
    }
    private void applyFeel(){
        if(gestures!=null){gestures.setPointerGain(prefs.getInt("pointerGain",720));gestures.setFeel(prefs.getInt("scrollSpeed",100)/100.0,prefs.getInt("inertia",100)/100.0,prefs.getBoolean("dragLock",false));}
        if(wifi&&web!=null&&pageReady)web.evaluateJavascript(feelScript(),null);
    }
    private SeekBar feelSlider(LinearLayout content,String title,String key,int minimum,int maximum,int initial){
        TextView label=new TextView(this);content.addView(label);
        SeekBar bar=new SeekBar(this);bar.setMax(maximum-minimum);bar.setProgress(prefs.getInt(key,initial)-minimum);content.addView(bar);
        label.setText(title+"："+prefs.getInt(key,initial));
        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
            public void onProgressChanged(SeekBar view,int progress,boolean fromUser){label.setText(title+"："+(progress+minimum));if(fromUser){prefs.edit().putInt(key,progress+minimum).apply();applyFeel();}}
            public void onStartTrackingTouch(SeekBar view){}
            public void onStopTrackingTouch(SeekBar view){}
        });return bar;
    }
    private void showPointerSettings() {
        cancelPointer();
        if(wifi&&web!=null)web.evaluateJavascript("if(window.wsSend)wsSend({cancel:true,p:[]});",null);
        LinearLayout content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);content.setPadding(dp(22),dp(12),dp(22),dp(12));
        TextView note=new TextView(this);note.setText("立即生效并保存。惯性为0时关闭；拖拽锁定需主动开启。");content.addView(note);
        LinearLayout presets=new LinearLayout(this);presets.setOrientation(LinearLayout.HORIZONTAL);content.addView(presets);
        SeekBar pointer=feelSlider(content,"指针速度","pointerGain",250,1400,720);
        SeekBar scrolling=feelSlider(content,"滚动速度 %","scrollSpeed",50,200,100);
        SeekBar inertia=feelSlider(content,"惯性强度 %","inertia",0,150,100);
        String[] names={"精细","标准","快速"};int[][] values={{450,75,65},{720,100,100},{1000,140,120}};
        for(int i=0;i<names.length;i++){final int n=i;Button button=new Button(this);button.setText(names[i]);presets.addView(button,new LinearLayout.LayoutParams(0,dp(44),1));button.setOnClickListener(v->{
            prefs.edit().putInt("pointerGain",values[n][0]).putInt("scrollSpeed",values[n][1]).putInt("inertia",values[n][2]).apply();pointer.setProgress(values[n][0]-250);scrolling.setProgress(values[n][1]-50);inertia.setProgress(values[n][2]);applyFeel();
        });}
        CheckBox drag=new CheckBox(this);drag.setText("拖拽锁定：抬指换位续拖，轻点结束，5秒无接触自动释放");drag.setChecked(prefs.getBoolean("dragLock",false));content.addView(drag);
        drag.setOnCheckedChangeListener((view,checked)->{prefs.edit().putBoolean("dragLock",checked).apply();applyFeel();});
        Button notifications=new Button(this);notifications.setText("Mac 通知中心手势设置");content.addView(notifications);
        ScrollView scroll=new ScrollView(this);scroll.addView(content);
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle("手感").setView(scroll).setPositiveButton("完成",null).create();dialog.setOnDismissListener(d->immersive());dialog.show();
        notifications.setOnClickListener(v->{dialog.dismiss();showNotificationSetup();});
    }
    private void requestNotification(){
        cancelPointer();
        if(!prefs.getBoolean("notificationShortcut",false)){showNotificationSetup();return;}
        if(wifi){
            if(!pageReady||!online){notice("局域网尚未连接");return;}
            web.evaluateJavascript("if(window.wsSend)wsSend({k:{c:45,f:1835008}});",null);
        }else if(bluetooth!=null&&online)bluetooth.key(13,17);
        else notice("蓝牙尚未连接");
    }
    private void showNotificationSetup(){
        new AlertDialog.Builder(this).setTitle("Mac 通知中心手势")
            .setMessage("首次需要在 Mac 设置一次：\n系统设置 → 键盘 → 键盘快捷键 → 调度中心 → 显示通知中心，设置为 Control＋Option＋Command＋N。\n\n完成后点下方启用。以后在右侧黑色留白，两指向左滑即可发送该快捷键。\n无需安装接收服务；应用不会替你修改 Mac 设置。")
            .setPositiveButton("已配置，启用",(d,w)->{prefs.edit().putBoolean("notificationShortcut",true).apply();immersive();})
            .setNeutralButton("停用",(d,w)->prefs.edit().putBoolean("notificationShortcut",false).apply())
            .setNegativeButton("稍后",null).show();
    }
    private void immersive() {
        if(Build.VERSION.SDK_INT>=30){WindowInsetsController c=getWindow().getInsetsController();
            if(c!=null){c.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);c.hide(WindowInsets.Type.systemBars());}}
        else getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY|View.SYSTEM_UI_FLAG_FULLSCREEN|View.SYSTEM_UI_FLAG_HIDE_NAVIGATION);
    }
    @Override public void onWindowFocusChanged(boolean hasFocus){super.onWindowFocusChanged(hasFocus);if(hasFocus)immersive();}

    @Override protected void onResume() {
        super.onResume(); foreground = true; beginMode(); main.post(ticker); immersive();
        if (web != null) web.onResume();
        if(wifi&&!PairingStore.paired(prefs)&&!onboardingShown&&!pairingNow){onboardingShown=true;showConnections();}
    }
    @Override protected void onPause() {
        cancelInput();
        foreground = false; main.removeCallbacks(ticker);
        stopLan();
        if (web != null) { web.evaluateJavascript("if(window.ws&&ws.readyState===1)ws.send('{\"cancel\":true,\"p\":[]}');if(window.trackpadEndDirectDrag)trackpadEndDirectDrag();if(window.clearAll)clearAll();",null); web.onPause(); }
        super.onPause();
    }
    @Override protected void onStop() { if(bluetooth!=null){bluetooth.suspend();online=false;} super.onStop(); }
    @Override protected void onDestroy() {
        stopLan();stopBluetooth(); network.shutdownNow(); if (web != null) web.destroy(); super.onDestroy();
    }
    private final Runnable ticker = new Runnable() {
        @Override public void run() {
            if (!foreground) return;
            if(remoteKeyboardOpen&&SystemClock.uptimeMillis()-lastEditorLayout>120){lastEditorLayout=SystemClock.uptimeMillis();positionEditor(false);}
            if(!wifi&&bluetooth!=null&&permissionReady()&&SystemClock.uptimeMillis()-lastBluetoothPoll>2000){
                lastBluetoothPoll=SystemClock.uptimeMillis();try{bluetooth.refresh();if(panelStatus!=null)panelStatus.setText(connectionDetails());}catch(SecurityException|IllegalStateException e){setStatus("蓝牙服务尚未就绪");}
            }
            if (gestures != null && online) gestures.tick(SystemClock.uptimeMillis());
            main.postDelayed(this,16);
        }
    };
    private void beginMode() {
        if (wifi) { beginLan(); return; }
        if (!permissionReady()) {
            setStatus("蓝牙模式需要附近设备权限；请点连接设置授权"); return;
        }
        if (bluetooth == null) {
            bluetooth = new BluetoothController(this, new BluetoothController.Listener(){
                @Override public void remembered(String address){prefs.edit().putString("host",address).apply();}
                @Override public void changed(String message, boolean connected){
                if (wifi || !foreground) return;
                boolean wasOnline = online; online = connected;
                if(wasOnline!=connected&&remoteInput!=null)remoteInput.resetRemoteComposition();
                setStatus(message);
                if (wasOnline && !connected && gestures != null) gestures.cancel();
                notifyPage();
                }
            });
            gestures = new GestureEngine(bluetooth);
            applyFeel();
        }
        try { bluetooth.start(prefs.getString("host", "")); }
        catch (SecurityException | IllegalStateException e) {
            setStatus("蓝牙服务或权限不可用，请点连接设置重试"); online = false;
        }
    }

    private boolean permissionReady() {
        return Build.VERSION.SDK_INT < 31 ||
            (checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED
            && checkSelfPermission(Manifest.permission.BLUETOOTH_ADVERTISE) == PackageManager.PERMISSION_GRANTED);
    }
    private void chooseDevice() {
        if (!permissionReady()) {
            requestPermissions(new String[] {Manifest.permission.BLUETOOTH_CONNECT,
                Manifest.permission.BLUETOOTH_ADVERTISE},11); return;
        }
        beginMode();
        if (bluetooth == null || !bluetooth.supported()) {
            setStatus("此设备没有可用的蓝牙适配器，请用局域网模式"); return;
        }
        if (!bluetooth.enabled()) {
            startActivity(new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE)); return;
        }
        try {
            List<BluetoothDevice> devices = bluetooth.bonded();
            String[] names = new String[devices.size()];
            for (int i = 0; i < names.length; i++) {
                BluetoothDevice d = devices.get(i);
                names[i] = BluetoothController.name(d) + "\n" + d.getAddress();
            }
            new AlertDialog.Builder(this).setTitle("选择已配对的 Mac")
                .setItems(names, (d,which) -> {
                    BluetoothDevice selected=devices.get(which);
                    try {
                        cancelPointer();bluetooth.selectHost(selected.getAddress());
                        notice("已选择 · "+BluetoothController.name(selected));
                        main.post(this::showConnections);
                    } catch(SecurityException|IllegalStateException e) {
                        setStatus("设备已选择，但蓝牙服务暂不可用，请重新连接");
                        main.post(this::showConnections);
                    }
                })
                .setMessage(names.length == 0 ? "尚无已配对设备。先开启可发现，再到 Mac 的蓝牙设置中配对 Tablet Trackpad。" : null)
                .setPositiveButton("开启可发现", (d,which) -> {
                    Intent discover = new Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE);
                    discover.putExtra(BluetoothAdapter.EXTRA_DISCOVERABLE_DURATION,120);
                    startActivity(discover);
                })
                .setNeutralButton("系统蓝牙设置", (d,which) -> startActivity(new Intent(Settings.ACTION_BLUETOOTH_SETTINGS)))
                .setNegativeButton("取消",null).show();
        } catch (SecurityException e) { setStatus("蓝牙权限不可用，请在系统应用权限中允许附近设备"); }
    }
    @Override public void onRequestPermissionsResult(int request, String[] permissions, int[] grants) {
        super.onRequestPermissionsResult(request,permissions,grants);
        if (request == 11 && permissionReady() && !wifi && foreground) chooseDevice();
    }

    private void makeWebView() {
        cancelInput(); pageGeneration++; pageReady = false;
        if (web != null) { layout.removeView(web); web.removeJavascriptInterface("TrackpadNative"); web.destroy(); }
        if(remoteInput!=null)layout.removeView(remoteInput);remoteKeyboardOpen=false;
        web = new WebView(this);
        web.getSettings().setUserAgentString(web.getSettings().getUserAgentString()+" TrackpadAPK");
        web.setBackgroundColor(Color.rgb(8,10,13));
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.getSettings().setAllowFileAccess(false);
        web.getSettings().setAllowContentAccess(false);
        web.getSettings().setSupportMultipleWindows(false);
        layout.addView(web,0,new FrameLayout.LayoutParams(-1,-1));
        remoteInput=nativeInputView(pageGeneration);
        remoteInput.setTextColor(Color.rgb(217,224,233));remoteInput.setBackgroundColor(Color.rgb(23,28,36));remoteInput.setTextSize(16);remoteInput.setPadding(dp(12),0,dp(12),0);
        remoteInput.setHint("输入同步到 Mac");remoteInput.setHintTextColor(Color.rgb(155,165,178));
        remoteInput.setVisibility(View.GONE);layout.addView(remoteInput,new FrameLayout.LayoutParams(1,1));
        web.addJavascriptInterface(new Bridge(pageGeneration),"TrackpadNative");
        web.setWebViewClient(new WebViewClient() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                String url = request.getUrl().toString();
                if (url.equals(LOCAL)) {
                    try { return new WebResourceResponse("text/html","UTF-8",getAssets().open("index.html")); }
                    catch (IOException e) { return blocked(); }
                }
                return blocked();
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return !request.getUrl().toString().equals(LOCAL);
            }
            @Override public void onPageFinished(WebView view, String url) {
                if (view != web) return;
                if(!LOCAL.equals(url))return;
                pageReady = true;
                if(remoteInput!=null)remoteInput.resetRemoteComposition();
                web.evaluateJavascript("window.TrackpadApk=true;"+uiScript,ignored->{
                    if(view!=web)return;
                    notifyPage();
                    // Browser fullscreen support must not determine whether input can connect.
                    web.evaluateJavascript(feelScript()+"if(window.trackpadStart)trackpadStart();",null);
                });
            }
            @Override public void onReceivedError(WebView view, WebResourceRequest request,
                    android.webkit.WebResourceError error) {
                if (request.isForMainFrame()) {setStatus("页面连接失败（"+error.getErrorCode()+"）：请检查 Mac 接收程序、地址与 Wi-Fi");notice("页面未连接，请点左侧连接查看原因");}
            }
        });
        web.loadUrl(LOCAL);
    }
    private static WebResourceResponse blocked() {
        return new WebResourceResponse("text/plain","UTF-8",403,"Blocked",null,
            new ByteArrayInputStream(new byte[0]));
    }
    private RemoteEditText nativeInputView(int marker) {
        final boolean networkMode=wifi;
        return new RemoteEditText(this,new RemoteComposer.Sink(){
            @Override public boolean unicode(){return networkMode;}
            @Override public boolean ready(){return marker==pageGeneration&&networkMode==wifi&&foreground&&online&&pageReady;}
            private void run(Runnable action){main.post(()->{
                if(marker!=pageGeneration||networkMode!=wifi||!foreground)return;
                if(!online||!pageReady){notice("输入连接尚未建立，文字未发送");return;}
                action.run();
            });}
            private void network(String message){
                // Only send to the current validated same-origin receiver; no network JS bridge.
                web.evaluateJavascript("(function(){if(window.ws&&ws.readyState===1){ws.send("+JSONObject.quote(message)+");return true;}return false;})()",result->{
                    if(marker==pageGeneration&&!"true".equals(result)){online=false;notice("局域网输入已断开，文字未发送");}
                });
            }
            @Override public void text(String value){run(()->{
                if(networkMode){try{network(new JSONObject().put("t",value).toString());}catch(JSONException ignored){}return;}
                if(bluetooth!=null)for(int i=0;i<value.length();i++){
                    int[] k=HidReports.ascii(value.charAt(i));if(k!=null)bluetooth.key(k[0],k[1]);
                }
            });}
            @Override public void backspace(int count){run(()->{
                if(remoteInput!=null)remoteInput.noteBackspace(count);
                if(networkMode){for(int i=0;i<count;i++)network("{\"k\":{\"c\":51,\"f\":0}}");}
                else if(bluetooth!=null)for(int i=0;i<count;i++)bluetooth.key(0,42);
            });}
            @Override public void key(int usage){run(()->{
                if(networkMode){int code=usage==40?36:usage==76?117:-1;if(code>=0)network("{\"k\":{\"c\":"+code+",\"f\":0}}");}
                else if(bluetooth!=null)bluetooth.key(0,usage);
            });}
            @Override public void unsupported(){main.post(()->notice(networkMode?"输入过长，请分段输入":"蓝牙支持英文键位；中文请使用局域网模式"));}
        });
    }
    @Override protected void onNewIntent(Intent intent){super.onNewIntent(intent);setIntent(intent);handlePairIntent(intent);}
    private void handlePairIntent(Intent intent){
        Uri data=intent==null?null:intent.getData();
        if(data!=null&&"trackpad".equals(data.getScheme())&&"pair".equals(data.getHost())){String link=data.toString();intent.setData(null);pairLink(link);}
    }
    private void scanPairing(){
        if(pairingNow){notice("正在配对，请稍候");return;}
        cancelInput();stopLan();
        startActivityForResult(new Intent(this,QrScanActivity.class),32);
    }
    @Override protected void onActivityResult(int request,int result,Intent data){
        super.onActivityResult(request,result,data);
        if(request==32&&result==RESULT_OK&&data!=null){String link=data.getStringExtra("pairLink");if(link!=null)pairLink(link);}
    }
    private void addressDialog() {
        EditText input=new EditText(this);input.setSingleLine(true);
        input.setHint("粘贴Mac网页连接码或APK专用码的完整链接");
        new AlertDialog.Builder(this).setTitle("安全配对Mac")
            .setMessage("推荐在应用内直接扫码。这里也支持粘贴Mac的网页连接链接或APK专用链接；不接受HTTP明文地址。")
            .setView(input).setPositiveButton("配对",(d,w)->pairLink(input.getText().toString())).setNegativeButton("取消",null).show();
    }
    private void pairLink(String link){
        if(pairingNow){notice("正在配对，请稍候");return;}
        try{
            JSONObject value=new JSONObject(PairingRequest.payload(link));
            String origin=value.getString("origin"),receiver=value.getString("receiver"),code=value.getString("code");
            PairingRequest.secrets(receiver,code);
            java.util.ArrayList<String> alternatives=new java.util.ArrayList<>();JSONArray origins=value.optJSONArray("origins");
            if(origins!=null){if(origins.length()>4)throw new IllegalArgumentException("备用地址过多");for(int i=0;i<origins.length();i++)alternatives.add(origins.getString(i));}
            List<String> candidates=PairingRequest.origins(link,origin,alternatives);
            completePair(candidates,receiver,code);
        }catch(Exception e){setStatus("配对链接无效：请扫描Mac配对页的网页连接码或APK专用码");notice("请刷新Mac连接二维码后在应用内重扫");}
    }
    private void completePair(List<String> origins,String receiver,String code){
        if(pairingNow)return;pairingNow=true;stopLan();setStatus("已识别二维码，正在连接Mac…");
        network.execute(()->{
            try{
                LanConnection.PairResult paired=LanConnection.pairCandidates(origins,receiver,code,Build.MODEL);
                main.post(()->{
                    if(isDestroyed())return;
                    try{
                        PairingStore.save(prefs,paired.origin,receiver,paired.cookie,origins);
                        stopLan();pairingNow=false;pairingRequired=false;switchMode(true);wifiOrigin=paired.origin;if(foreground)beginLan();
                        notice("配对成功，正在连接Mac");
                    }catch(Exception e){pairingNow=false;setStatus("配对已完成，但设备无法保存连接凭据；请重新扫码");}
                });
            }catch(Exception e){main.post(()->{
                if(isDestroyed())return;pairingNow=false;setStatus("配对未完成："+LanConnection.failureMessage(e));if(foreground)showConnections();
            });}
        });
    }
    private void beginLan(){
        if(!foreground||!wifi||lan!=null||pairingNow)return;
        try{
            wifiOrigin=prefs.getString("url","");String receiver=prefs.getString("lanReceiver","");
            if(!PairingStore.paired(prefs)||pairingRequired){setStatus("点扫码连接Mac，即可记住设备");return;}
            final LanConnection[] holder=new LanConnection[1];
            LanConnection transport=new LanConnection(PairingStore.origins(prefs),receiver,PairingStore.cookie(prefs),new LanConnection.Listener(){
                @Override public void pairingRequired(){main.post(()->{if(wifi&&foreground&&lan==holder[0])pairingRequired=true;});}
                @Override public void changed(String message,boolean connected){main.post(()->{
                    if(!wifi||!foreground||lan!=holder[0])return;
                    boolean before=online;online=connected;
                    if(before!=connected&&remoteInput!=null)remoteInput.resetRemoteComposition();
                    setStatus(message);notifyPage();
                });}
                @Override public void serverMessage(String message){main.post(()->{
                    if(!wifi||!foreground||lan!=holder[0]||web==null)return;
                    try{JSONObject value=new JSONObject(message);
                        if(value.has("inputReset")){if(remoteInput!=null)remoteInput.resetRemoteComposition();web.evaluateJavascript("if(window.handleInputReset)handleInputReset("+JSONObject.quote(value.optString("inputReset"))+");",null);}
                        JSONObject volume=value.optJSONObject("volume");
                        if(volume!=null)web.evaluateJavascript("if(window.trackpadVolumeStatus)trackpadVolumeStatus("+volume.toString()+");",null);
                        JSONObject state=value.optJSONObject("status");if(state!=null){
                            macPowerStatus="\nMac接收端："+state.optString("receiverVersion","旧版")+"；空闲休眠保护："+(state.optBoolean("sleepProtected")?"已启用":"未启用");
                            boolean allowed=!state.has("inputReady")||state.isNull("inputReady")||state.optBoolean("inputReady");
                            if(online&&!allowed)cancelPointer();
                            if(online!=allowed&&remoteInput!=null)remoteInput.resetRemoteComposition();
                            online=allowed;setStatus(state.optString("machine","Mac")+(allowed?" · 已连接":" · Mac未授权辅助功能，请在Mac系统设置授权后重新启动接收端"));notifyPage();
                        }
                    }catch(Exception ignored){}
                });}
            });holder[0]=transport;lan=transport;transport.start();
        }catch(Exception e){setStatus("点扫码连接Mac，即可恢复连接");}
    }
    private void stopLan(){if(lan!=null){lan.stop();lan=null;}if(wifi){online=false;notifyPage();}}

    private void notifyPage() {
        if (pageReady && web != null)
            web.evaluateJavascript("if(window.nativeConnection)nativeConnection(" + online + ");if(window.trackpadConnectionStatus)trackpadConnectionStatus("+JSONObject.quote(statusMessage)+");",null);
    }
    private void cancelInput() {
        cancelPointer();
        if (bluetooth != null) bluetooth.release();
    }
    private void cancelPointer() {
        if(wifi&&lan!=null)lan.send("{\"cancel\":true,\"p\":[]}");
        if(gestures!=null)gestures.cancel();
    }
    private void stopBluetooth() {
        cancelInput(); online = false;
        if (bluetooth != null) { bluetooth.stop(); bluetooth = null; }
        gestures = null;
    }
    private void notice(String text) {
        long now = SystemClock.uptimeMillis();
        if (now-lastNotice < 1800) return;
        lastNotice = now; Toast.makeText(this,text,Toast.LENGTH_LONG).show();
    }
    private int dp(int value) { return Math.round(value*getResources().getDisplayMetrics().density); }

    private final class Bridge {
        private final int generation;
        Bridge(int generation) { this.generation = generation; }
        @JavascriptInterface public boolean isConnected() { return online; }
        @JavascriptInterface public boolean isTablet() { return getResources().getConfiguration().smallestScreenWidthDp>=600; }
        @JavascriptInterface public void closeKeyboard(){main.post(()->{if(generation==pageGeneration&&remoteKeyboardOpen)toggleKeyboard();});}
        @JavascriptInterface public void privateInput(boolean enabled){main.post(()->{
            if(generation!=pageGeneration||remoteInput==null)return;
            remoteInput.resetRemoteComposition();
            if(enabled)getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_SECURE);
            remoteInput.setInputType(android.text.InputType.TYPE_CLASS_TEXT|(enabled?android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD:android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE)|android.text.InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
            remoteInput.setImeOptions(android.view.inputmethod.EditorInfo.IME_FLAG_NO_PERSONALIZED_LEARNING);
        });}
        @JavascriptInterface public void send(String json) {
            if (json == null || json.length() > 32768) return;
            main.post(() -> {
                if (!foreground || !online || generation != pageGeneration) return;
                if(wifi){if(lan!=null)lan.send(json);return;}
                if(gestures==null)return;
                try {
                    JSONObject msg = new JSONObject(json);
                    if (msg.optBoolean("cancel")) { cancelPointer(); return; }
                    gestures.setDirectDrag(msg.optBoolean("directDrag"));
                    JSONArray surface=msg.optJSONArray("surface");
                    if(surface!=null&&surface.length()==2)gestures.setSurface(surface.optDouble(0),surface.optDouble(1));
                    JSONArray p = msg.optJSONArray("p");
                    if (p != null && p.length() <= 5) {
                        double[][] points = new double[p.length()][];
                        for (int i = 0; i < p.length(); i++) {
                            JSONArray point = p.getJSONArray(i);
                            points[i] = new double[] {point.getDouble(0),point.getDouble(1),point.getDouble(2),
                                point.optDouble(3,0),point.optDouble(4,0)};
                        }
                        gestures.frame(points,SystemClock.uptimeMillis());
                    }
                    JSONObject key = msg.optJSONObject("k");
                    if (key != null) {
                        int code=key.optInt("c",-1);
                        if(code>=72&&code<=74)bluetooth.media(code);
                        else bluetooth.key(HidReports.macModifiers(key.optInt("f")),HidReports.macKey(code));
                    }
                    String text = msg.optString("t","");
                    if (!text.isEmpty()) {
                        if (text.length() > 128) { notice("请分成较短的段落输入"); return; }
                        for (int i = 0; i < text.length(); i++) {
                            if (HidReports.ascii(text.charAt(i)) == null) {
                                notice("蓝牙仅发送英文键位；中文、表情请切换局域网模式"); return;
                            }
                        }
                        for (int i = 0; i < text.length(); i++) {
                            int[] k = HidReports.ascii(text.charAt(i)); bluetooth.key(k[0],k[1]);
                        }
                        // The page clears committed text after forwarding. Ask Android's IME to
                        // refresh surrounding text too, so backspace doesn't erase a stale local echo.
                        InputMethodManager ime=(InputMethodManager)getSystemService(INPUT_METHOD_SERVICE);
                        if(ime!=null&&web!=null)ime.restartInput(web);
                    }
                } catch (JSONException | IllegalArgumentException e) {
                    // Discard malformed frames without logging user input.
                }
            });
        }
    }
}
