package cc.trackpad.tablet;

import android.content.Context;
import android.text.Editable;
import android.text.TextWatcher;
import android.text.InputType;
import android.view.KeyEvent;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.view.inputmethod.InputConnectionWrapper;
import android.widget.EditText;

/** Ordinary Android editing/composition. Only actual buffer changes are forwarded. */
public final class RemoteEditText extends EditText {
    private final RemoteComposer.Sink sink;
    private final RemoteTextMirror mirror;
    private boolean internal;
    private int edits,deletes;
    public void noteBackspace(int count){deletes+=count;}
    public String diagnostics(){return "原生编辑器：变化 "+edits+"，退格提交 "+deletes;}
    private String body(){String text=getText().toString();return text.startsWith("\u200B")?text.substring(1):text;}
    public RemoteEditText(Context context,RemoteComposer.Sink sink){
        super(context);this.sink=sink;mirror=new RemoteTextMirror(sink);
        setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS|(sink.unicode()?0:InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD));
        setSingleLine(true);setText("\u200B");setSelection(1);
        addTextChangedListener(new TextWatcher(){
            public void beforeTextChanged(CharSequence s,int start,int count,int after){}
            public void onTextChanged(CharSequence s,int start,int before,int count){}
            public void afterTextChanged(Editable text){
                if(internal)return;
                edits++;mirror.update(body());
                // Restore only a removed anchor. Do not rewrite composing text or report synthetic selections.
                if(!text.toString().startsWith("\u200B"))post(()->{
                    if(!getText().toString().startsWith("\u200B")){
                        internal=true;getText().insert(0,"\u200B");setSelection(getText().length());internal=false;
                    }
                });
            }
        });
    }
    public void resetRemoteComposition(){
        mirror.forget();internal=true;setText("\u200B");setSelection(1);internal=false;
    }
    private void enter(){if(sink.ready())sink.key(40);resetRemoteComposition();}
    @Override public boolean onKeyDown(int code,KeyEvent event){
        if(code==KeyEvent.KEYCODE_DEL&&body().isEmpty()){
            edits++;if(sink.ready())sink.backspace(1);return true;
        }
        if(code==KeyEvent.KEYCODE_ENTER){enter();return true;}
        return super.onKeyDown(code,event);
    }
    @Override public InputConnection onCreateInputConnection(EditorInfo info){
        InputConnection base=super.onCreateInputConnection(info);if(base==null)return null;
        info.imeOptions=EditorInfo.IME_ACTION_DONE|EditorInfo.IME_FLAG_NO_EXTRACT_UI;
        return new InputConnectionWrapper(base,false){
            private boolean delete(int before,int after,boolean codePoints){
                String text=body();int known=codePoints?text.codePointCount(0,text.length()):text.length();
                int extra=Math.max(0,Math.min(128,before)-known);
                if(extra>0){edits++;if(sink.ready())sink.backspace(extra);}
                // Real native editor applies deletion and emits the single TextWatcher diff.
                return codePoints?super.deleteSurroundingTextInCodePoints(Math.min(Math.max(0,before),known),after)
                    :super.deleteSurroundingText(Math.min(Math.max(0,before),known),after);
            }
            @Override public boolean deleteSurroundingText(int before,int after){return delete(before,after,false);}
            @Override public boolean deleteSurroundingTextInCodePoints(int before,int after){return delete(before,after,true);}
            @Override public boolean performEditorAction(int action){enter();return true;}
        };
    }
}
