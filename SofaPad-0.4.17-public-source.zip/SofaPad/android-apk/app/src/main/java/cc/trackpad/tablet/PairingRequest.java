package cc.trackpad.tablet;

import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Base64;
import java.util.LinkedHashSet;
import java.util.List;

/** Validates QR envelopes and local endpoints before any connection or credential is sent. */
public final class PairingRequest {
    private PairingRequest() {}
    public static String payload(String link) throws Exception {
        URI uri=new URI(link.trim());
        boolean nativeLink="trackpad".equals(uri.getScheme())&&"pair".equals(uri.getHost())&&uri.getPort()==-1&&(uri.getPath()==null||uri.getPath().isEmpty());
        boolean webLink="http".equals(uri.getScheme())&&"/pair".equals(uri.getPath());
        if(uri.getRawUserInfo()!=null||uri.getRawQuery()!=null||(!nativeLink&&!webLink))throw new IllegalArgumentException("请扫描Mac触摸板配对页的连接二维码");
        if(webLink)LanConnection.checkedOrigin("http://"+uri.getRawAuthority());
        String raw=uri.getRawFragment();
        if(raw==null||!raw.matches("[A-Za-z0-9_-]{20,4096}"))throw new IllegalArgumentException("二维码没有配对信息，请刷新Mac上的连接二维码");
        byte[] decoded=Base64.getUrlDecoder().decode(raw);
        if(decoded.length>3072)throw new IllegalArgumentException("配对码过长");
        return new String(decoded,StandardCharsets.UTF_8);
    }
    public static List<String> origins(String link,String primary,List<String> alternatives) throws Exception {
        URI origin=LanConnection.checkedOrigin(primary),envelope=new URI(link.trim());
        if("http".equals(envelope.getScheme())&&!envelope.getRawAuthority().equalsIgnoreCase(origin.getRawAuthority()))throw new IllegalArgumentException("二维码外部地址与Mac配对信息不一致");
        if(alternatives.size()>4)throw new IllegalArgumentException("配对地址过多");
        LinkedHashSet<String> unique=new LinkedHashSet<>();unique.add(primary);
        for(String next:alternatives){URI candidate=LanConnection.checkedOrigin(next);if(candidate.getPort()!=origin.getPort())throw new IllegalArgumentException("备用地址端口不匹配");unique.add(next);}
        return new ArrayList<>(unique);
    }
    public static void secrets(String receiver,String code){
        if(receiver==null||code==null||!receiver.matches("[a-f0-9]{32}")||!code.matches("[A-Za-z0-9_-]{20,80}"))throw new IllegalArgumentException("配对码无效，请刷新Mac二维码");
    }
}
