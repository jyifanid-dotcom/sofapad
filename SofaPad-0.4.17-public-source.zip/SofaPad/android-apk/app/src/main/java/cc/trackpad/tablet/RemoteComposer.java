package cc.trackpad.tablet;

/** Bluetooth English input state. Composing text is mirrored remotely, never stored in the DOM. */
public final class RemoteComposer {
    public interface Sink {
        boolean ready();
        default boolean unicode(){return false;}
        void text(String value);
        void backspace(int count);
        void key(int usage);
        void unsupported();
    }
    private final Sink sink;
    private String mirrored = "";
    public RemoteComposer(Sink sink) { this.sink=sink; }
    public synchronized String surrounding() { return mirrored; }
    public synchronized void finish() { mirrored=""; }
    public synchronized boolean compose(CharSequence value) {
        if(!sink.ready()){mirrored="";return false;}
        String next=value==null?"":value.toString();
        if(next.length()>128){sink.unsupported();return false;}
        for(int i=0;i<next.length();i++) if(!sink.unicode()&&HidReports.ascii(next.charAt(i))==null){sink.unsupported();return false;}
        int common=0;
        while(common<mirrored.length()&&common<next.length()&&mirrored.charAt(common)==next.charAt(common))common++;
        // Never split a surrogate pair when replacing a Unicode composing suffix.
        if(common>0 && common<mirrored.length() && Character.isHighSurrogate(mirrored.charAt(common-1)))common--;
        int remove=mirrored.codePointCount(common,mirrored.length());
        if(remove>0)sink.backspace(remove);
        if(common<next.length())sink.text(next.substring(common));
        mirrored=next;return true;
    }
    public synchronized boolean commit(CharSequence value) {
        boolean accepted=compose(value);
        if(accepted)mirrored="";
        return accepted;
    }
    public synchronized void deleteUnits(int before,int after) {
        int units=Math.max(0,Math.min(128,before));
        int known=Math.min(units,mirrored.length());
        int count=mirrored.codePointCount(mirrored.length()-known,mirrored.length())+units-known;
        delete(count,after);
    }
    public synchronized void delete(int before,int after) {
        if(!sink.ready()){mirrored="";return;}
        int n=Math.max(0,Math.min(128,before));
        if(n>0){sink.backspace(n);int keep=Math.max(0,mirrored.codePointCount(0,mirrored.length())-n);mirrored=mirrored.substring(0,mirrored.offsetByCodePoints(0,keep));}
        int forward=Math.max(0,Math.min(128,after));
        for(int i=0;i<forward;i++)sink.key(76);
    }
}
