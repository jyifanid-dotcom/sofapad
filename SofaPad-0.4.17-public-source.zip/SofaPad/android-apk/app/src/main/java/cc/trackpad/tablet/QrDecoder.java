package cc.trackpad.tablet;

import com.google.zxing.BinaryBitmap;
import com.google.zxing.DecodeHintType;
import com.google.zxing.PlanarYUVLuminanceSource;
import com.google.zxing.ReaderException;
import com.google.zxing.common.HybridBinarizer;
import com.google.zxing.qrcode.QRCodeReader;
import java.util.EnumMap;
import java.util.Map;

/** Offline QR-only decoder. The luma buffer never leaves memory or goes to a server. */
public final class QrDecoder {
    public String decode(byte[] luma,int width,int height){
        if(luma==null||width<1||height<1||(long)width*height>luma.length)return null;
        Map<DecodeHintType,Object> hints=new EnumMap<>(DecodeHintType.class);
        hints.put(DecodeHintType.TRY_HARDER,Boolean.TRUE);
        PlanarYUVLuminanceSource source=new PlanarYUVLuminanceSource(luma,width,height,0,0,width,height,false);
        QRCodeReader reader=new QRCodeReader();
        try{return reader.decode(new BinaryBitmap(new HybridBinarizer(source)),hints).getText();}
        catch(ReaderException ignored){
            try{return reader.decode(new BinaryBitmap(new HybridBinarizer(source.invert())),hints).getText();}
            catch(ReaderException absent){return null;}
        }finally{reader.reset();}
    }
}
