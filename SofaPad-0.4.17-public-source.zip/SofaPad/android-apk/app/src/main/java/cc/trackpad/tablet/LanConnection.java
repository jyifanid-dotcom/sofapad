package cc.trackpad.tablet;

import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.security.*;
import java.util.*;
import java.util.concurrent.*;

/** IP-only HTTP/WebSocket transport. Pairing auth remains; traffic is plaintext. */
public final class LanConnection {
    public interface Listener { void changed(String message, boolean connected); default void serverMessage(String message){} default void pairingRequired(){} }
    public static final class Reply {
        public final int code;public final Map<String,String> headers;public final byte[] body;
        Reply(int c,Map<String,String> h,byte[] b){code=c;headers=h;body=b;}
    }
    private static final String CLIENT_INSTANCE=UUID.randomUUID().toString().replace("-","");
    private volatile String phase="尚未开始",lastFailure="无";
    private volatile int attempts;
    private volatile URI origin;
    private final List<URI> origins;
    private final String receiver,cookie;
    private final Listener listener;
    private final ExecutorService workers=Executors.newSingleThreadExecutor();
    private final ScheduledExecutorService heartbeat=Executors.newSingleThreadScheduledExecutor();
    private final ThreadPoolExecutor outgoing=new ThreadPoolExecutor(1,1,0,TimeUnit.MILLISECONDS,new ArrayBlockingQueue<>(256));
    private final Object writeLock=new Object();
    private volatile Socket socket;
    private volatile boolean active,ready;
    private volatile long connectionGeneration;
    private final SecureRandom random=new SecureRandom();
    public LanConnection(String url,String identity,String credential,Listener listener)throws Exception{
        this(Collections.singletonList(url),identity,credential,listener);
    }
    public LanConnection(List<String> urls,String identity,String credential,Listener listener)throws Exception{
        if(urls==null||urls.isEmpty()||urls.size()>5)throw new IllegalArgumentException("请扫码连接Mac");
        List<URI> checked=new ArrayList<>();for(String url:urls)checked.add(checkedOrigin(url));
        origins=Collections.unmodifiableList(checked);origin=origins.get(0);receiver=identity;cookie=credential;this.listener=listener;
        if(!receiver.matches("[a-f0-9]{32}")||!cookie.matches("trackpad-device=[A-Za-z0-9_-]{32,128}"))throw new IllegalArgumentException("请扫码连接Mac");
    }
    public static URI checkedOrigin(String value)throws Exception{
        URI uri=new URI(value);
        if(!"http".equals(uri.getScheme())||uri.getHost()==null||uri.getPort()<1||uri.getPort()>65535||uri.getRawUserInfo()!=null||uri.getQuery()!=null||uri.getFragment()!=null||!(uri.getPath().isEmpty()||uri.getPath().equals("/")))throw new IllegalArgumentException("请使用Mac二维码中的IP地址");
        String host=uri.getHost();String[] pieces=host.split("\\.");
        if(pieces.length!=4)throw new IllegalArgumentException("连接地址需要局域网IP");
        int[] ip=new int[4];for(int i=0;i<4;i++){if(!pieces[i].matches("0|[1-9][0-9]{0,2}"))throw new IllegalArgumentException("无效IP");ip[i]=Integer.parseInt(pieces[i]);if(ip[i]>255)throw new IllegalArgumentException("无效IP");}
        boolean local=ip[0]==10||ip[0]==192&&ip[1]==168||ip[0]==172&&ip[1]>=16&&ip[1]<=31||ip[0]==127;
        if(!local)throw new IllegalArgumentException("连接地址必须是局域网IP");return uri;
    }
    private static Socket openSocket(URI origin)throws IOException{return openSocket(origin,s->{});}
    private static Socket openSocket(URI origin,java.util.function.Consumer<Socket> track)throws IOException{
        Socket result=new Socket();
        try{
            track.accept(result);
            result.connect(new InetSocketAddress(origin.getHost(),origin.getPort()),3000);
            result.setSoTimeout(5000);result.setTcpNoDelay(true);return result;
        }catch(IOException|RuntimeException e){try{result.close();}catch(IOException ignored){}throw e;}
    }
    private static final class ReceiverMismatch extends IOException {
        ReceiverMismatch(){super("这个IP不是已配对的Mac，请刷新Mac二维码重扫");}
    }
    private static final class BusyChannel extends IOException {
        BusyChannel(){super("已有其他窗口或设备控制Mac，请先退出那边的触摸板");}
    }
    public static void verifyReceiver(URI origin,String receiver)throws Exception{verifyReceiver(origin,receiver,s->{});}
    private static void verifyReceiver(URI origin,String receiver,java.util.function.Consumer<Socket> track)throws Exception{
        if(!receiver.matches("[a-f0-9]{32}"))throw new IllegalArgumentException("请扫码连接Mac");
        try(Socket probe=openSocket(origin,track)){
            probe.getOutputStream().write(("GET /api/identity HTTP/1.1\r\nHost: "+authority(origin)+"\r\nConnection: close\r\n\r\n").getBytes(StandardCharsets.US_ASCII));probe.getOutputStream().flush();
            Reply reply=readHead(probe.getInputStream(),true);
            if(reply.code!=200||!receiver.equals(reply.headers.get("x-trackpad-receiver")))throw new ReceiverMismatch();
        }
    }
    private void trackSocket(Socket next){
        socket=next;
        if(!active)try{next.close();}catch(IOException ignored){}
    }
    private Socket connectKnown()throws Exception{
        List<URI> candidates=new ArrayList<>();candidates.add(origin);for(URI next:origins)if(!candidates.contains(next))candidates.add(next);
        Exception failure=null;
        for(URI next:candidates){
            if(!active)throw new InterruptedIOException("Connection stopped");
            try{
                origin=next;phase="核对Mac · "+authority(next);listener.changed(phase,false);
                verifyReceiver(next,receiver,this::trackSocket);
                phase="建立控制通道 · "+authority(next);
                return openSocket(next,this::trackSocket);
            }catch(IOException e){failure=e;lastFailure=authority(next)+" · "+failureMessage(e);}
        }
        if(failure!=null)throw failure;throw new IOException("Mac暂不可达");
    }
    public String currentOrigin(){return origin.toString();}
    public String diagnostics(){return "目标IP："+authority(origin)+"\n当前步骤："+phase+"\n连接尝试："+attempts+"\n最近原因："+lastFailure;}
    private static byte[] exact(InputStream input,int n)throws IOException{
        if(n<0||n>131072)throw new IOException("响应过大");byte[] data=new byte[n];int at=0;while(at<n){int r=input.read(data,at,n-at);if(r<0)throw new EOFException();at+=r;}return data;
    }
    private static Reply readHead(InputStream input,boolean body)throws IOException{
        ByteArrayOutputStream out=new ByteArrayOutputStream();int b,tail=0;
        while((b=input.read())>=0){out.write(b);tail=(tail<<8)|b;if(tail==0x0d0a0d0a)break;if(out.size()>16384)throw new IOException("响应头过大");}
        if(b<0)throw new EOFException();String[] lines=out.toString("ISO-8859-1").split("\r\n");
        int code=Integer.parseInt(lines[0].split(" ")[1]);Map<String,String> headers=new HashMap<>();
        for(int i=1;i<lines.length;i++){int colon=lines[i].indexOf(':');if(colon>0)headers.put(lines[i].substring(0,colon).toLowerCase(Locale.ROOT),lines[i].substring(colon+1).trim());}
        if(headers.containsKey("transfer-encoding"))throw new IOException("不支持分块响应");
        byte[] data=body?exact(input,Integer.parseInt(headers.getOrDefault("content-length","0"))):new byte[0];return new Reply(code,headers,data);
    }
    private static String authority(URI uri){return uri.getHost()+":"+uri.getPort();}
    public static String pair(String url,String receiver,String code,String label)throws Exception{
        URI origin=checkedOrigin(url);if(!receiver.matches("[a-f0-9]{32}")||!code.matches("[A-Za-z0-9_-]{20,80}"))throw new IllegalArgumentException("配对码无效");
        String safe=label.replace("\\","_").replace("\"","_").replaceAll("[\\p{Cntrl}]","");if(safe.length()>64)safe=safe.substring(0,64);
        byte[] payload=("{\"code\":\""+code+"\",\"name\":\""+safe+"\"}").getBytes(StandardCharsets.UTF_8);
        verifyReceiver(origin,receiver);
        try(Socket s=openSocket(origin)){
            String head="POST /api/pair HTTP/1.1\r\nHost: "+authority(origin)+"\r\nOrigin: http://"+authority(origin)+"\r\nContent-Type: application/json\r\nContent-Length: "+payload.length+"\r\nConnection: close\r\n\r\n";
            s.getOutputStream().write(head.getBytes(StandardCharsets.US_ASCII));s.getOutputStream().write(payload);s.getOutputStream().flush();Reply r=readHead(s.getInputStream(),true);
            if(r.code!=200)throw new PairRejected();String cookie=r.headers.getOrDefault("set-cookie","").split(";",2)[0];
            if(!cookie.matches("trackpad-device=[A-Za-z0-9_-]{32,128}"))throw new IOException("Mac未返回有效凭据");return cookie;
        }
    }
    public static final class PairResult {
        public final String origin,cookie;
        PairResult(String origin,String cookie){this.origin=origin;this.cookie=cookie;}
    }
    private static final class PairRejected extends IOException {
        PairRejected(){super("二维码已使用或过期，请在Mac刷新连接码后重扫");}
    }
    public static PairResult pairCandidates(List<String> origins,String receiver,String code,String label)throws Exception{
        if(origins.isEmpty()||origins.size()>5)throw new IllegalArgumentException("没有有效的Mac配对地址");
        for(String url:origins)checkedOrigin(url);
        Exception failure=null;
        for(String url:origins){
            try{return new PairResult(url,pair(url,receiver,code,label));}
            catch(PairRejected e){throw e;}
            catch(IOException e){failure=e;}
        }
        if(failure!=null)throw failure;
        throw new IOException("Mac暂不可达");
    }
    public static String failureMessage(Throwable failure){
        if(failure instanceof PairRejected)return "二维码已失效，请刷新Mac二维码后重扫";
        if(failure instanceof ReceiverMismatch||failure instanceof BusyChannel)return failure.getMessage();
        if(failure instanceof SocketTimeoutException)return "等待Mac回应超时；换过Wi-Fi请重新扫码，否则检查Mac是否休眠或网络未放行";
        if(failure instanceof ConnectException)return "Mac控制端口未响应；换过Wi-Fi请重新扫码，否则检查接收端与Mac是否唤醒";
        if(failure instanceof NoRouteToHostException)return "当前网络无法到达Mac；请检查公司Wi-Fi设备隔离或网络切换";
        if(failure instanceof SocketException)return "网络连接中断，正在重试；请确认Mac在线";
        if(failure instanceof EOFException)return "Mac关闭了通道，正在重新连接";
        return "控制通道中断，正在重新连接（"+failure.getClass().getSimpleName()+"）";
    }
    public boolean connected(){return ready&&active;}
    public void start(){if(active)return;active=true;workers.execute(this::loop);heartbeat.scheduleAtFixedRate(()->send("{\"heartbeat\":true}"),4,4,TimeUnit.SECONDS);}
    private void loop(){
        long delay=1000;
        while(active){
            try{
                attempts++;listener.changed("正在连接已记住的Mac…",false);Socket current=connectKnown();socket=current;
                if(!active){current.close();break;}
                byte[] nonce=new byte[16];random.nextBytes(nonce);String key=Base64.getEncoder().encodeToString(nonce);
                String head="GET /ws HTTP/1.1\r\nHost: "+authority(origin)+"\r\nOrigin: http://"+authority(origin)+"\r\nCookie: "+cookie+"\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Key: "+key+"\r\nSec-WebSocket-Version: 13\r\nX-Trackpad-Client: "+CLIENT_INSTANCE+"\r\n\r\n";
                current.getOutputStream().write(head.getBytes(StandardCharsets.US_ASCII));current.getOutputStream().flush();Reply r=readHead(current.getInputStream(),false);
                if(r.code==401){if(active){active=false;listener.pairingRequired();listener.changed("配对权限已失效，请重新扫码连接Mac",false);}break;}
                if(r.code==409)throw new BusyChannel();
                String expected=Base64.getEncoder().encodeToString(MessageDigest.getInstance("SHA-1").digest((key+"258EAFA5-E914-47DA-95CA-C5AB0DC85B11").getBytes(StandardCharsets.US_ASCII)));
                if(r.code!=101||!expected.equals(r.headers.get("sec-websocket-accept")))throw new IOException("Mac未建立控制通道");
                current.setSoTimeout(12000);connectionGeneration++;ready=true;delay=1000;phase="已连接";listener.changed("已连接，可以控制",true);
                while(active){int first=current.getInputStream().read(),second=current.getInputStream().read();if(first<0||second<0)throw new EOFException();int op=first&15;if((first&0xf0)!=0x80||(second&128)!=0)throw new IOException("无效服务端帧");long len=second&127;if(len==126){byte[] ext=exact(current.getInputStream(),2);len=((ext[0]&255)<<8)|(ext[1]&255);}else if(len==127)throw new IOException("响应过大");byte[] data=exact(current.getInputStream(),(int)len);if(op==8)throw new EOFException();if(op==9)frame(10,data);if(op==1)listener.serverMessage(new String(data,StandardCharsets.UTF_8));}
            }catch(Exception e){
                ready=false;
                if(active){lastFailure=authority(origin)+" · "+phase+" · "+failureMessage(e);listener.changed(failureMessage(e)+"\nIP："+authority(origin),false);}
            }finally{ready=false;connectionGeneration++;outgoing.getQueue().clear();Socket current=socket;socket=null;if(current!=null)try{current.close();}catch(IOException ignored){}}
            if(active)try{Thread.sleep(delay);delay=Math.min(15000,delay*2);}catch(InterruptedException e){Thread.currentThread().interrupt();break;}
        }
    }
    private void frame(int opcode,byte[] data)throws IOException{frame(opcode,data,-1,0,socket);}
    private void frame(int opcode,byte[] data,long generation,long queuedAt,Socket expectedSocket)throws IOException{
        if(data.length>32768)throw new IOException("帧过大");synchronized(writeLock){
            Socket current=expectedSocket;
            if(current!=socket)return;
            if(generation>=0){
                if(!connected()||generation!=connectionGeneration)return;
                if(System.nanoTime()-queuedAt>250_000_000L){closeSocket(current);throw new IOException("输入队列已过期");}
            }
            if(current==null)throw new EOFException();OutputStream out=current.getOutputStream();ByteArrayOutputStream frame=new ByteArrayOutputStream();frame.write(0x80|opcode);
            if(data.length<126)frame.write(0x80|data.length);else{frame.write(0x80|126);frame.write((data.length>>8)&255);frame.write(data.length&255);}byte[] mask=new byte[4];random.nextBytes(mask);frame.write(mask);for(int i=0;i<data.length;i++)frame.write(data[i]^mask[i%4]);out.write(frame.toByteArray());out.flush();}
    }
    public void send(String message){
        if(!connected()||message==null||message.length()>32768)return;
        final long generation=connectionGeneration,queuedAt=System.nanoTime();
        final Socket target=socket;
        try{outgoing.execute(()->{if(!connected()||generation!=connectionGeneration)return;try{frame(1,message.getBytes(StandardCharsets.UTF_8),generation,queuedAt,target);}catch(IOException e){closeSocket(target);}});}catch(RejectedExecutionException e){closeSocket(target);}
    }
    private void closeSocket(Socket current){if(current!=null)try{current.close();}catch(IOException ignored){}}
    public void stop(){if(ready)send("{\"cancel\":true,\"p\":[]}");active=false;ready=false;Socket current=socket;if(current!=null)try{current.close();}catch(IOException ignored){}heartbeat.shutdownNow();workers.shutdownNow();outgoing.shutdownNow();}
}
