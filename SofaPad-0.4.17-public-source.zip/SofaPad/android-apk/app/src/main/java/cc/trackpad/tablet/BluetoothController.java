package cc.trackpad.tablet;

import android.annotation.SuppressLint;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothHidDevice;
import android.bluetooth.BluetoothHidDeviceAppSdpSettings;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothProfile;
import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;

/** Foreground-only HID lifecycle; no boot service, scanning, or hidden API. */
@SuppressLint("MissingPermission") // MainActivity gates all calls on runtime CONNECT permission.
public final class BluetoothController implements GestureEngine.Output {
    public interface Listener { void changed(String message, boolean connected); default void remembered(String address){} }
    private final Context context;
    private final Listener listener;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final BluetoothAdapter adapter;
    private BluetoothHidDevice hid;
    private BluetoothDevice host, connectedHost;
    private boolean active, registered, requesting, registering, resetting, retryPending;
    private int tries, generation, registrationAttempt, channelResets;
    private String profileState="未查询",connectResult="未请求",reportResult="尚未发送";
    private byte[] mouseState = HidReports.mouse(0,0,0,0,0);
    private byte[] keyboardState = new byte[8];
    private byte[] consumerState = new byte[1];
    private final ArrayDeque<byte[]> keys = new ArrayDeque<>();
    private boolean keyBusy;
    private final Runnable keyPump = this::pumpKey;

    public BluetoothController(Context context, Listener listener) {
        this.context = context;
        this.listener = listener;
        BluetoothManager manager = context.getSystemService(BluetoothManager.class);
        adapter = manager == null ? null : manager.getAdapter();
    }

    public String diagnostics(){return "HID："+(registered?"已注册":"未注册")+"，"+(connectedHost==null?"通道未建立":"通道已建立")+
        "\n目标："+(host==null?"尚未选择":name(host))+"\n协议状态："+profileState+"；连接请求："+connectResult+
        "\n报告："+reportResult+"\n重试 "+tries+"；通道恢复 "+channelResets;}
    private String stateName(int state){return state==BluetoothProfile.STATE_CONNECTED?"已连接":state==BluetoothProfile.STATE_CONNECTING?"连接中":state==BluetoothProfile.STATE_DISCONNECTED?"未连接":"正在断开";}
    public boolean enabled() { return adapter != null && adapter.isEnabled(); }
    public boolean supported() { return adapter != null; }
    public boolean connected() { return connectedHost != null && registered && active; }
    public List<BluetoothDevice> bonded() {
        return adapter == null ? new ArrayList<>() : new ArrayList<>(adapter.getBondedDevices());
    }

    public void start(String address) {
        if (!enabled()) { listener.changed("请先开启平板蓝牙", false); return; }
        main.removeCallbacks(retry);retryPending=false;
        active = true;
        try {
            host = address == null || address.isEmpty() ? null : adapter.getRemoteDevice(address);
        } catch (IllegalArgumentException e) { host = null; }
        tries = 0;channelResets=0;resetting=false;
        if (registered) { connectHost(); return; }
        if (hid != null) { register(); return; }
        if (requesting) return;
        requesting = true;
        listener.changed("正在检查蓝牙输入设备支持…", false);
        boolean accepted = adapter.getProfileProxy(context, service, BluetoothProfile.HID_DEVICE);
        if (!accepted) { requesting = false; listener.changed("此系统未提供蓝牙 HID 接口，请用局域网模式", false); }
        int marker = generation;
        main.postDelayed(() -> {
            if (active && marker == generation && !registered)
                {registering=false;if(hid==null)requesting=false;listener.changed("蓝牙 HID 尚未就绪，正在自动恢复…", false);scheduleReconnect();}
        }, 10000);
    }

    /** Select on the existing registration: unregister/register races can lose the new app. */
    public void selectHost(String address) {
        BluetoothDevice next=adapter.getRemoteDevice(address);
        release();
        BluetoothDevice previous=host;
        generation++;main.removeCallbacks(retry);retryPending=false;
        host=next;connectedHost=null;tries=0;channelResets=0;
        profileState="未查询";connectResult="准备请求";
        listener.remembered(address);
        listener.changed("已选择 · "+name(next)+"，正在建立HID输入通道…",false);
        if(hid!=null&&previous!=null&&!previous.equals(next))hid.disconnect(previous);
        // A fresh user selection supersedes any delayed recovery for the previous target.
        resetting=false;
        if(registered&&hid!=null){active=true;connectHost();}
        else start(address);
    }

    private final BluetoothProfile.ServiceListener service = new BluetoothProfile.ServiceListener() {
        @Override public void onServiceConnected(int profile, BluetoothProfile proxy) {
            requesting = false;
            if (profile != BluetoothProfile.HID_DEVICE) return;
            if (!active) { adapter.closeProfileProxy(profile, proxy); return; }
            hid = (BluetoothHidDevice)proxy;
            register();
        }
        @Override public void onServiceDisconnected(int profile) {
            requesting = false; registered = false; connectedHost = null; hid = null;
            clearQueue();
            registering=false;
            if (active) {listener.changed("蓝牙服务已断开，正在自动恢复…", false);scheduleReconnect();}
        }
    };

    private void register() {
        if (!active || hid == null || registered || registering || resetting) return;
        BluetoothHidDeviceAppSdpSettings sdp = new BluetoothHidDeviceAppSdpSettings(
            "Tablet Trackpad", "Tablet mouse and keyboard", "Trackpad",
            BluetoothHidDevice.SUBCLASS1_COMBO, HidReports.DESCRIPTOR);
        registering=true;
        final int attempt=++registrationAttempt;
        main.postDelayed(()->{
            if(active && attempt==registrationAttempt && !registered){registering=false;scheduleReconnect();}
        },3000);
        if (!hid.registerApp(sdp, null, null, main::post, callbacks)) {
            registering=false;registrationAttempt++;
            listener.changed("蓝牙注册暂未就绪，正在自动恢复…", false);
            scheduleReconnect();
        }
    }

    private final BluetoothHidDevice.Callback callbacks = new BluetoothHidDevice.Callback() {
        @Override public void onAppStatusChanged(BluetoothDevice pluggedDevice, boolean isRegistered) {
            registering=false;registrationAttempt++;registered = isRegistered;
            // stop() already requested unregister; a late callback must not unregister a new instance.
            if (!active||resetting) return;
            if (!isRegistered) {
                connectedHost = null; clearQueue();
                listener.changed("蓝牙输入设备注册已结束，正在自动恢复…", false);
                scheduleReconnect();
                return;
            }
            if(host==null&&pluggedDevice!=null&&pluggedDevice.getBondState()==BluetoothDevice.BOND_BONDED){host=pluggedDevice;listener.remembered(host.getAddress());}
            // Never silently choose another host: use only the user-selected remembered Mac.
            connectHost();
        }
        @Override public void onConnectionStateChanged(BluetoothDevice device, int state) {
            if (!active || hid == null || resetting) return;
            profileState=stateName(state);
            if(host==null&&state==BluetoothProfile.STATE_CONNECTED&&device.getBondState()==BluetoothDevice.BOND_BONDED){host=device;listener.remembered(host.getAddress());}
            if (host == null || !host.equals(device)) {
                if (state == BluetoothProfile.STATE_CONNECTED) hid.disconnect(device);
                return;
            }
            if (state == BluetoothProfile.STATE_CONNECTED) {
                connectedHost = device; tries = 0;main.removeCallbacks(retry);retryPending=false;
                release();
                if (connected()) listener.changed("蓝牙已连接 · " + name(device), true);
            } else if (state == BluetoothProfile.STATE_DISCONNECTED) {
                connectedHost = null; clearQueue();
                listener.changed("蓝牙已断开，正在尝试重连…", false);
                scheduleReconnect();
            } else if (state == BluetoothProfile.STATE_CONNECTING) {
                listener.changed("正在连接 · " + name(device), false);
            }
        }
        @Override public void onGetReport(BluetoothDevice device, byte type, byte id, int bufferSize) {
            if (hid == null || !active || host == null || !host.equals(device)) return;
            if (type != BluetoothHidDevice.REPORT_TYPE_INPUT || (id != 1 && id != 2 && id != 3)) {
                hid.reportError(device, BluetoothHidDevice.ERROR_RSP_UNSUPPORTED_REQ); return;
            }
            // Relative movement must not be replayed when the host polls current state.
            byte[] data = id == 1 ? HidReports.mouse(mouseState[0],0,0,0,0) : id == 2 ? keyboardState : consumerState;
            if (bufferSize > 0 && bufferSize < data.length) {
                hid.reportError(device, BluetoothHidDevice.ERROR_RSP_INVALID_PARAM); return;
            }
            hid.replyReport(device, type, id, data);
        }
        @Override public void onVirtualCableUnplug(BluetoothDevice device) {
            if (host != null && host.equals(device)) {
                connectedHost = null; clearQueue(); tries = 3;
                listener.changed("Mac 已解除输入设备连接，请重新配对或选择设备", false);
            }
        }
    };

    private void connectHost() {
        if (!active || !registered || hid == null || resetting) return;
        if(host==null){
            List<BluetoothDevice> current=hid.getConnectedDevices();
            if(current.size()==1&&current.get(0).getBondState()==BluetoothDevice.BOND_BONDED){host=current.get(0);listener.remembered(host.getAddress());}
            else {listener.changed("蓝牙输入设备已就绪，请点连接选择已配对的 Mac",false);return;}
        }
        if (host.getBondState() != BluetoothDevice.BOND_BONDED) {
            listener.changed("此 Mac 尚未配对，请先完成系统蓝牙配对", false); return;
        }
        List<BluetoothDevice> current = hid.getConnectedDevices();
        if (current.contains(host)) {
            profileState="已连接";connectResult="复用现有通道";
            connectedHost = host; release();
            if (connected()) listener.changed("蓝牙已连接 · " + name(host), true);
            return;
        }
        int state=hid.getConnectionState(host);profileState=stateName(state);
        if(state==BluetoothProfile.STATE_CONNECTED){connectedHost=host;tries=0;release();if(connected())listener.changed("蓝牙输入通道已恢复 · "+name(host),true);return;}
        if(state==BluetoothProfile.STATE_CONNECTING){listener.changed("HID连接处理中 · "+name(host),false);scheduleReconnect();return;}
        boolean accepted=hid.connect(host);connectResult=accepted?"系统已接受":"系统未接受";
        if(!connected())listener.changed((accepted?"正在建立HID输入通道 · ":"系统暂未接受HID连接请求 · ")+name(host),false);
        scheduleReconnect();
    }

    private void resetChannel(){
        if(!active||hid==null||resetting||host==null)return;
        resetting=true;channelResets++;registered=false;registering=false;registrationAttempt++;
        connectedHost=null;clearQueue();main.removeCallbacks(retry);retryPending=false;
        final int marker=generation;
        listener.changed("连接连续失败，正在重新初始化HID输入通道…",false);
        hid.disconnect(host);hid.unregisterApp();
        main.postDelayed(()->{
            if(!active||generation!=marker)return;
            resetting=false;registered=false;registering=false;tries=0;
            try{register();}catch(SecurityException|IllegalStateException e){listener.changed("HID恢复失败，请检查蓝牙权限",false);}
        },1200);
    }
    private void scheduleReconnect() {
        if (!active || host == null || connectedHost != null || resetting) return;
        // Three fast attempts, then a grace interval before one bounded HID reinitialization.
        if(tries>=4&&channelResets==0&&hid!=null&&registered){resetChannel();return;}
        int delay=tries<3?new int[]{1500,3500,7000}[tries]:tries==3?15000:30000;
        tries++;
        if(tries>=4)listener.changed("已记住目标，但HID输入通道未建立；请在Mac蓝牙设置点击Tablet Trackpad连接。前台将继续重试 · "+name(host),false);
        main.removeCallbacks(retry);retryGeneration=generation;retryPending=true;main.postDelayed(retry,delay);
    }
    private int retryGeneration;
    private final Runnable retry = this::recover;
    private void recover() {
        retryPending=false;
        if (!active || generation != retryGeneration || connected()) return;
        try {
            if (!enabled()) {listener.changed("请先开启平板蓝牙",false);return;}
            if (hid==null) {
                if(!requesting){
                    requesting=true;
                    if(!adapter.getProfileProxy(context,service,BluetoothProfile.HID_DEVICE)){requesting=false;scheduleReconnect();}
                    else {int marker=generation;main.postDelayed(()->{if(active&&generation==marker&&requesting&&hid==null){requesting=false;scheduleReconnect();}},3000);}
                }
            } else if (!registered) register();
            else connectHost();
        } catch(SecurityException|IllegalStateException e){listener.changed("蓝牙权限或服务不可用，请检查系统设置",false);}
    }

    @Override public void mouse(int buttons, int dx, int dy, int wheel, int pan) {
        mouseState = HidReports.mouse(buttons,dx,dy,wheel,pan);
        send(HidReports.MOUSE, mouseState);
    }
    @Override public void key(int modifiers, int usage) {
        if (!connected() || usage == 0 || keys.size() > 512) return;
        keys.add(HidReports.keyboard(modifiers,usage));
        keys.add(new byte[8]);
        if (!keyBusy) { keyBusy = true; pumpKey(); }
    }
    public void media(int code) {
        int bits=code==72?1:code==73?2:code==74?4:0;
        if(!connected()||bits==0||keys.size()>512)return;
        keys.add(new byte[]{(byte)bits});keys.add(new byte[1]);
        if(!keyBusy){keyBusy=true;pumpKey();}
    }
    private void pumpKey() {
        if (!connected() || keys.isEmpty()) { keyBusy = false; return; }
        byte[] report=keys.remove();
        if(report.length==1){consumerState=report;send(HidReports.CONSUMER,report);}
        else {keyboardState=report;send(HidReports.KEYBOARD,report);}
        main.postDelayed(keyPump, 4);
    }
    private void send(int id, byte[] report) {
        if (connected() && hid != null) {
            try {
                if (!hid.sendReport(connectedHost,id,report)) {
                    reportResult=id==HidReports.CONSUMER?"音量报告未被系统接受；鼠标键盘通道保留":"鼠标或键盘报告未被系统接受";
                    // Older paired hosts may cache the pre-media report descriptor.
                    // An optional media rejection must not take down an established input channel.
                    if(id==HidReports.CONSUMER){consumerState=new byte[1];return;}
                    connectedHost = null; clearQueue();
                    listener.changed("蓝牙报告发送失败，正在尝试重连…", false);
                    scheduleReconnect();
                } else reportResult=id==HidReports.CONSUMER?"音量报告已提交":"输入报告已提交";
            } catch (SecurityException e) {
                connectedHost = null; clearQueue();
                listener.changed("蓝牙权限已撤销，请重新授权", false);
            }
        }
    }
    private void clearQueue() {
        main.removeCallbacks(keyPump); keys.clear(); keyBusy = false;
        mouseState = HidReports.mouse(0,0,0,0,0); keyboardState = new byte[8];consumerState=new byte[1];
    }
    public void refresh(){
        if(!active)return;
        if(hid==null){if(!requesting&&!retryPending)recover();return;}
        if(!registered){if(!registering&&!resetting&&!retryPending)register();return;}
        if(host==null){connectHost();return;}
        int state=hid.getConnectionState(host);profileState=stateName(state);
        if(state==BluetoothProfile.STATE_CONNECTED&&connectedHost==null){connectedHost=host;tries=0;release();if(connected())listener.changed("蓝牙输入通道已恢复 · "+name(host),true);}
        else if(state==BluetoothProfile.STATE_DISCONNECTED&&connectedHost!=null){connectedHost=null;clearQueue();listener.changed("HID通道已断开，正在恢复",false);scheduleReconnect();}
    }
    public void suspend(){release();active=false;generation++;resetting=false;retryPending=false;main.removeCallbacks(retry);connectedHost=null;}
    public void release() {
        boolean releaseConsumer=consumerState[0]!=0;
        clearQueue(); send(HidReports.MOUSE, mouseState); send(HidReports.KEYBOARD, keyboardState);
        if(releaseConsumer)send(HidReports.CONSUMER,consumerState);
    }
    public void stop() {
        release(); active = false; generation++;retryPending=false;
        main.removeCallbacks(retry);
        if (hid != null) {
            if (registered) hid.unregisterApp();
            adapter.closeProfileProxy(BluetoothProfile.HID_DEVICE, hid);
        }
        hid = null; registered = false; requesting = false; registering=false;connectedHost = null;
    }
    public static String name(BluetoothDevice device) {
        String name = device.getName(); return name == null ? device.getAddress() : name;
    }
}
