package cc.trackpad.tablet;
import android.content.SharedPreferences;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;
import java.security.KeyStore;
import javax.crypto.*;
import javax.crypto.spec.GCMParameterSpec;
/** Device-local pairing secret, protected by AndroidKeyStore and excluded from backups. */
public final class PairingStore {
    private static final String ALIAS="trackpad.lan.pairing.v1";
    private static javax.crypto.SecretKey key()throws Exception{
        KeyStore store=KeyStore.getInstance("AndroidKeyStore");store.load(null);
        if(store.containsAlias(ALIAS))return (javax.crypto.SecretKey)store.getKey(ALIAS,null);
        KeyGenerator generator=KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore");
        generator.init(new KeyGenParameterSpec.Builder(ALIAS,KeyProperties.PURPOSE_ENCRYPT|KeyProperties.PURPOSE_DECRYPT).setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build());return generator.generateKey();
    }
    public static void save(SharedPreferences prefs,String origin,String receiver,String cookie)throws Exception{
        save(prefs,origin,receiver,cookie,java.util.Collections.singletonList(origin));
    }
    public static void save(SharedPreferences prefs,String origin,String receiver,String cookie,java.util.List<String> origins)throws Exception{
        Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding");cipher.init(Cipher.ENCRYPT_MODE,key());
        byte[] encrypted=cipher.doFinal(cookie.getBytes(java.nio.charset.StandardCharsets.UTF_8));
        String value=Base64.encodeToString(cipher.getIV(),Base64.NO_WRAP)+":"+Base64.encodeToString(encrypted,Base64.NO_WRAP);
        if(!prefs.edit().putString("url",origin).putString("lanReceiver",receiver).putString("lanSecret",value).putString("lanOrigins",String.join("\n",origins)).commit())throw new IllegalStateException("无法保存配对");
    }
    public static boolean paired(SharedPreferences prefs){
        return prefs.getString("lanReceiver","").matches("[a-f0-9]{32}")&&!prefs.getString("lanSecret","").isEmpty()&&prefs.getString("url","").startsWith("http://");
    }
    public static java.util.List<String> origins(SharedPreferences prefs)throws Exception{
        java.util.LinkedHashSet<String> result=new java.util.LinkedHashSet<>();result.add(prefs.getString("url",""));
        String saved=prefs.getString("lanOrigins","");
        if(!saved.isEmpty())java.util.Collections.addAll(result,saved.split("\n"));
        if(result.size()>5)throw new IllegalStateException("保存的Mac地址无效，请重扫二维码");
        for(String origin:result)LanConnection.checkedOrigin(origin);
        return new java.util.ArrayList<>(result);
    }
    public static String cookie(SharedPreferences prefs)throws Exception{
        String[] value=prefs.getString("lanSecret","").split(":",-1);if(value.length!=2)throw new IllegalStateException("请先扫码配对");
        Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding");cipher.init(Cipher.DECRYPT_MODE,key(),new GCMParameterSpec(128,Base64.decode(value[0],Base64.NO_WRAP)));
        return new String(cipher.doFinal(Base64.decode(value[1],Base64.NO_WRAP)),java.nio.charset.StandardCharsets.UTF_8);
    }
}
