package cc.trackpad.tablet;

import java.util.ArrayList;
import java.util.List;

/** Pure-Java Bluetooth gesture recognizer. Wi-Fi still uses the existing Mac recognizer. */
public final class GestureEngine {
    public interface Output {
        void mouse(int buttons, int dx, int dy, int wheel, int pan);
        void key(int modifiers, int usage);
    }
    private final Output out;
    private final RelativeMotion motion = new RelativeMotion();
    private double pointerGain = 720, pointerXScale=1,pointerYScale=1;
    public void setSurface(double width,double height){
        if(Double.isFinite(width)&&Double.isFinite(height)&&width>=16&&height>=16&&width<=10000&&height<=10000){
            double base=Math.min(width,height);pointerXScale=width/base;pointerYScale=height/base;
        }
    }
    public void setPointerGain(double gain) { pointerGain=Math.max(250,Math.min(1400,gain)); }
    private int maxN, count, frames, buttons,scrollAxis;
    private double axisX,axisY;
    private boolean dragLock,dragLatched,resumeDrag,directDrag,directDragActive;
    public void setDirectDrag(boolean enabled){directDrag=enabled;}
    private long latchedAt,directDragDeadline;
    public void setFeel(double speed,double inertia,boolean lock){motion.settings(speed,inertia);dragLock=lock;if(!lock&&dragLatched)cancel();}
    private long started, lastTime, lastTap = -10000, zoomTime,twoStarted,twoEnded;
    private double pointerId;
    private double startX, startY, endX, endY, lastX, lastY, initialSpread, spread;
    private double moveX, moveY, wheelX, wheelY, maxMove;
    private boolean dragArmed, longFired, suppressTap, cleanTwo, pinching, scrolling, zoomed;
    private double zoomBase;

    public GestureEngine(Output output) { out = output; }

    public void cancel() {
        if (buttons != 0) out.mouse(0, 0, 0, 0, 0);
        buttons = 0; maxN = 0; count = 0; frames = 0;
        lastTap = -10000;dragLatched=resumeDrag=directDrag=directDragActive=false;
        moveX = moveY = wheelX = wheelY = 0;
        motion.clear();
    }

    /** Points are [id, normalized x, normalized y, optional CSS width, CSS height]. */
    public void frame(double[][] raw, long now) {
        List<double[]> valid = new ArrayList<>();
        for (double[] p : raw) {
            if (p.length < 3 || !Double.isFinite(p[1]) || !Double.isFinite(p[2])) continue;
            if (p[1] < 0 || p[1] > 1 || p[2] < 0 || p[2] > 1) continue;
            if (p.length > 4 && Math.max(p[3], p[4]) > 110) continue;
            boolean duplicate = false;
            for (double[] q : valid) if (Math.hypot(q[1]-p[1], q[2]-p[2]) < .015) duplicate = true;
            if (!duplicate) valid.add(p);
            if (valid.size() == 5) break;
        }
        if(raw.length>0&&valid.isEmpty()){cancel();return;}
        int n = valid.size();
        if (n == 0) {
            if (count != 0) finish(now);
            count = maxN = 0;
            return;
        }
        double x = 0, y = 0, s = 0;
        for (double[] p : valid) { x += p[1]; y += p[2]; }
        x /= n; y /= n;
        for (double[] p : valid) s += Math.hypot(p[1]-x, p[2]-y);
        s /= n;

        boolean contactRebased=count==1&&n==1&&valid.get(0)[0]!=pointerId;
        if(contactRebased)cancel();
        if(count==1&&n==1&&now-lastTime<=25&&Math.hypot(x-lastX,y-lastY)>.28){
            suppressTap=true;lastX=x;lastY=y;lastTime=now;return;
        }
        if (count == 0) {
            if(n==1)pointerId=valid.get(0)[0];
            if(n==2){twoStarted=now;twoEnded=-1;}
            resumeDrag=dragLatched&&n==1;
            if(dragLatched&&n!=1){buttons=0;out.mouse(0,0,0,0,0);}
            dragLatched=false;scrollAxis=0;axisX=axisY=0;
            motion.beginScroll(now);
            maxN = n; frames = 0; started = now;
            dragArmed = !directDrag && n == 1 && now - lastTap <= 420;
            suppressTap = contactRebased;longFired = pinching = scrolling = zoomed = false;
            // Second contact is a real held left button before any browser drag movement.
            if(dragArmed){buttons=1;out.mouse(1,0,0,0,0);}
            if(resumeDrag){buttons=1;suppressTap=true;}
            directDragActive=directDrag&&n==1;
            if(directDragActive){directDragDeadline=now+15000;dragArmed=false;suppressTap=true;buttons=1;out.mouse(1,0,0,0,0);}
            cleanTwo = n == 2;
            maxMove = 0;
            startX = endX = lastX = x; startY = endY = lastY = y;
            initialSpread = spread = zoomBase = s;
            moveX = moveY = wheelX = wheelY = 0;
            lastTime = now;
        } else if (n > maxN) {
            if(n==2){twoStarted=now;twoEnded=-1;}
            cleanTwo = n == 2 && now-started <= 70 && maxMove < .008;
            if (buttons != 0) { buttons = 0; out.mouse(0,0,0,0,0); }
            maxN = n; frames = 0; dragArmed = false;resumeDrag=false;scrollAxis=0;axisX=axisY=0;
            motion.clear();
            motion.beginScroll(now);
            startX = endX = lastX = x; startY = endY = lastY = y;
            initialSpread = spread = zoomBase = s;
            pinching = scrolling = zoomed = false;
            wheelX = wheelY = 0;
        }
        // Preserve a multi-finger gesture across staggered lift-off. Never turn it into a click.
        if (n < maxN) {
            if(maxN==2&&twoEnded<0)twoEnded=now;
            count = n; return;
        }
        frames++;
        endX = x; endY = y; spread = s;
        double displacement = Math.hypot(x-startX, y-startY);
        maxMove = Math.max(maxMove, displacement);
        double dx = x-lastX, dy = y-lastY;
        if (n == 1 && !longFired) {
            boolean startedDrag=false;
            if (dragArmed && displacement > .014 && !suppressTap) {
                suppressTap = true;
                motion.add((x-startX)*pointerGain*pointerXScale,(y-startY)*pointerGain*pointerYScale);startedDrag=true;
            }
            // Mac applies its own acceleration. Stable gain avoids amplifying batched events twice.
            // The second tap must not move the cursor away from the first click's target.
            if(!startedDrag&&(!dragArmed||suppressTap))motion.add(dx*pointerGain*pointerXScale,dy*pointerGain*pointerYScale);
        } else if (n == 2) {
            double delta = Math.abs(s-initialSpread);
            if (!pinching && !scrolling && initialSpread > .015 && delta > .0125
                    && delta/initialSpread > .10 && delta > displacement*1.5) pinching = true;
            if (pinching) {
                if (zoomBase > 0 && s > 0 && now-zoomTime >= 100) {
                    double ratio = s/zoomBase;
                    if (ratio >= 1.55 || ratio <= 1/1.55) {
                        out.key(8, ratio >= 1.55 ? 46 : 45);
                        zoomBase *= ratio >= 1.55 ? 1.55 : 1/1.55;
                        zoomTime = now; zoomed = true;
                    }
                }
            } else {
                if (displacement > .008) scrolling = true;
                if (scrolling) {
                    // Standard wheel ticks; Mac's own natural-scroll preference applies.
                    axisX+=dx;axisY+=dy;
                    if(scrollAxis==0&&Math.hypot(axisX,axisY)>.006){
                        if(Math.abs(axisY)>Math.abs(axisX)*1.4)scrollAxis=1;
                        else if(Math.abs(axisX)>Math.abs(axisY)*1.4)scrollAxis=2;
                    }
                    motion.lockAxis(scrollAxis);
                    motion.scroll(scrollAxis==2?0:-dy*34,scrollAxis==1?0:dx*34,now);
                }
            }
        }
        count = n; lastX = x; lastY = y; lastTime = now;
    }

    public void tick(long now) {
        if(directDragActive&&buttons!=0&&now>=directDragDeadline){cancel();return;}
        if(dragLatched&&now-latchedAt>=5000){dragLatched=false;buttons=0;out.mouse(0,0,0,0,0);}
        int[] delta = motion.step(now);
        if (delta[0]!=0 || delta[1]!=0 || delta[2]!=0 || delta[3]!=0)
            out.mouse(buttons,delta[0],delta[1],delta[2],delta[3]);

    }

    private void finish(long now) {
        long duration = now-started;
        long overlap=(twoEnded>=0?twoEnded:now)-twoStarted;
        if(maxN==2&&scrolling&&!pinching)motion.releaseScroll(now);
        if (buttons != 0) {
            int[] tail=motion.drainPointer();
            if (tail[0]!=0 || tail[1]!=0) out.mouse(buttons,tail[0],tail[1],0,0);
            if(dragLock&&maxMove>.014&&!directDragActive){dragLatched=true;latchedAt=now;lastTap=-10000;return;}
            buttons = 0; out.mouse(0,0,0,0,0); lastTap = -10000;
            return;
        }
        if (maxN == 1 && !suppressTap && !longFired && maxMove < .022 && duration <= 350) {
            int[] tail=motion.drainPointer();
            if(tail[0]!=0||tail[1]!=0)out.mouse(0,tail[0],tail[1],0,0);
            click(1); lastTap = now;
        } else if (maxN == 2 && cleanTwo && !scrolling && !pinching && !zoomed
                && overlap >= 50 && overlap <= 320 && duration <= 350 && maxMove < .022
                && initialSpread >= .045) {
            click(2); lastTap = -10000;
        } else if (maxN >= 3) {
            double dx = endX-startX, dy = endY-startY;
            double pinch = initialSpread > 0 ? spread/initialSpread : 1;
            if (maxN >= 4 && (pinch < .78 || pinch > 1.22)) {
                if (pinch < .78) out.key(8,44); else out.key(0,68); // Cmd+Space / F11
            } else if (Math.hypot(dx,dy) >= .06) {
                if (Math.abs(dx) > Math.abs(dy)) out.key(1, dx < 0 ? 79 : 80);
                else out.key(1, dy < 0 ? 82 : 81);
            } // Three/four-finger taps are silent; keep actual swipes/pinches above.
            lastTap = -10000;
        } else lastTap = -10000;
    }

    private void click(int button) {
        out.mouse(button,0,0,0,0); out.mouse(0,0,0,0,0);
    }
}
