package cc.trackpad.tablet;

/** Two-finger right-edge inward swipe. Coordinates normalized to the whole app. */
public final class EdgeSwipe {
    private long began;
    private boolean active,armed,fired,cancelled;
    private double startX,startY;
    public boolean frame(double[][] points,long now,double boundary){
        int n=points.length;
        if(n==0){active=armed=fired=cancelled=false;return false;}
        if(!active){active=true;began=now;}
        if(n>2){cancelled=true;return false;}
        if(cancelled||fired||n!=2)return false;
        double x=(points[0][0]+points[1][0])/2,y=(points[0][1]+points[1][1])/2;
        if(!armed){
            if(now-began>180||points[0][0]<boundary-.02||points[1][0]<boundary-.02){cancelled=true;return false;}
            armed=true;startX=x;startY=y;return false;
        }
        if(now-began>1000||Math.abs(y-startY)>.08){cancelled=true;return false;}
        if(startX-x>=.055){fired=true;return true;}
        return false;
    }
}
