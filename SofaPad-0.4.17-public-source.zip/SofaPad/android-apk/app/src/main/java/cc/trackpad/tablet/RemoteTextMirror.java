package cc.trackpad.tablet;

/** Forward differences from a real editor buffer; never writes back into that editor. */
public final class RemoteTextMirror {
    private final RemoteComposer.Sink sink;
    private String sent="";
    public RemoteTextMirror(RemoteComposer.Sink sink){this.sink=sink;}
    public void forget(){sent="";}
    public boolean update(CharSequence value){
        if(!sink.ready()){forget();return false;}
        String next=value.toString();
        if(!sink.unicode())for(int i=0;i<next.length();i++)if(HidReports.ascii(next.charAt(i))==null){sink.unsupported();return false;}
        int common=0;
        while(common<sent.length()&&common<next.length()&&sent.charAt(common)==next.charAt(common))common++;
        if(common>0&&common<sent.length()&&Character.isHighSurrogate(sent.charAt(common-1)))common--;
        int remove=sent.codePointCount(common,sent.length());
        if(remove>0)sink.backspace(remove);
        if(common<next.length())sink.text(next.substring(common));
        sent=next;return true;
    }
}
