package cc.trackpad.tablet;

import java.net.URI;
import java.net.URISyntaxException;

/** Address entry policy shared by settings and saved-address migration. */
public final class ServerAddress {
    private ServerAddress() {}
    public static String normalize(String entered) {
        String value = entered == null ? "" : entered.trim().replace('：', ':');
        if (value.isEmpty()) throw new IllegalArgumentException("请填写 Mac 的局域网 IP 或地址");
        if (!value.contains("://")) value = "http://" + value;
        try {
            URI uri = new URI(value);
            String scheme = uri.getScheme().toLowerCase(java.util.Locale.ROOT);
            if (!scheme.equals("http") || uri.getHost() == null
                    || uri.getUserInfo() != null || uri.getQuery() != null || uri.getFragment() != null
                    || !(uri.getPath() == null || uri.getPath().isEmpty() || uri.getPath().equals("/")))
                throw new IllegalArgumentException("请填写 IP 或根地址，不要附加路径、密码或参数");
            String host=uri.getHost();
            String[] octets=host.split("\\.");
            if(octets.length!=4)throw new IllegalArgumentException("请填写Mac的局域网IP");
            int[] ip=new int[4];
            for(int i=0;i<4;i++){
                if(!octets[i].matches("0|[1-9][0-9]{0,2}"))throw new IllegalArgumentException("IP格式不正确");
                ip[i]=Integer.parseInt(octets[i]);
                if(ip[i]>255)throw new IllegalArgumentException("IP格式不正确");
            }
            if(!(ip[0]==10 || ip[0]==172 && ip[1]>=16 && ip[1]<=31 || ip[0]==192 && ip[1]==168 || host.equals("127.0.0.1")))
                throw new IllegalArgumentException("请填写Mac的局域网IP");
            int port = uri.getPort();
            if (port == -1) port = 8765;
            if (port < 1 || port > 65535) throw new IllegalArgumentException("端口应在 1 到 65535 之间");
            return new URI(scheme, null, uri.getHost(), port, "/", null, null).toASCIIString();
        } catch (URISyntaxException e) { throw new IllegalArgumentException("地址格式不正确，请填写 Mac 的 IP 或完整地址"); }
    }
}
