(function () {
  'use strict';
  if (window.trackpadUiVersion === '0.4.17') return;
  window.trackpadUiVersion = '0.4.17';
  var nativeMode = !!window.TrackpadNative;
  var style = document.createElement('style');
  style.textContent = `
  html,body{background:#080a0d!important;color:#b2bdcc}
  #stage{display:flex;align-items:center;justify-content:center;inset:var(--touchbar-top,28px) 56px calc(28px + var(--app-ime-overlap,0px)) 96px;padding:0 0 var(--kbh,0px)!important;transition:none!important}
  #pad{width:var(--pad-width,100%)!important;height:var(--pad-height,100%)!important;aspect-ratio:1.4!important;border-radius:24px;
    background-color:rgba(253,252,249,.995)!important;
    background-image:linear-gradient(180deg,rgba(255,255,255,.66),rgba(253,252,249,.34) 60%,rgba(248,247,243,.44))!important;
    -webkit-backdrop-filter:blur(24px);backdrop-filter:blur(24px);
    box-shadow:0 14px 28px rgba(0,0,0,.18),0 4px 0 rgba(215,213,207,.80),0 5px 0 rgba(255,255,255,.30),inset 0 1px 1px #fff,inset 1px 0 1px rgba(255,255,255,.85),inset -1px 0 1px rgba(255,255,255,.65),inset 0 -2px 4px rgba(133,130,120,.045)!important;
    transition:box-shadow .16s ease!important}
  #pad::before{background:linear-gradient(180deg,rgba(255,255,255,.20),transparent 65%),repeating-linear-gradient(105deg,rgba(255,255,255,.018) 0 1px,transparent 1px 3px)!important}
  #pad::after{box-shadow:inset 0 0 0 1px rgba(255,255,255,.84),inset 0 0 0 3px rgba(255,255,255,.18)!important;background:linear-gradient(180deg,rgba(255,255,255,.32),transparent 9%,transparent 90%,rgba(127,124,116,.025))}
  #pad.touching{box-shadow:0 14px 28px rgba(0,0,0,.18),0 4px 0 rgba(215,213,207,.80),0 5px 0 rgba(255,255,255,.30),inset 0 1px 1px #fff,inset 1px 0 1px rgba(255,255,255,.85),inset -1px 0 1px rgba(255,255,255,.65),inset 0 -2px 4px rgba(133,130,120,.045)!important}
  #touchbar{position:fixed;left:96px;right:56px;top:14px;height:40px;display:flex;gap:12px;align-items:center;z-index:45;background:linear-gradient(180deg,#191a1c,#050506 30%,#000 78%,#0d0e10);border:1px solid #34363a;border-radius:10px;padding:0 10px;box-sizing:border-box;box-shadow:0 1px 0 rgba(255,255,255,.07),0 5px 14px rgba(0,0,0,.65),inset 0 1px 0 rgba(255,255,255,.10),inset 0 -1px 0 rgba(255,255,255,.04)}
  #touchbar button{height:28px;min-width:42px;padding:0 13px;border:0;border-radius:4px;color:#f5f5f5;background:#252525;box-shadow:none;font:12px system-ui;touch-action:manipulation;flex-shrink:0}
  #touchbar button{display:inline-flex;align-items:center;justify-content:center;gap:6px;background:#1b1c20;color:#d1d4da}
  #touchbar button svg{flex-shrink:0}
  #touchbar button:active{background:#34363d}
  #touchbar .bar-label{color:#d1d4da}
  #touchbar button.bar-lock{background:#252021}
  body.iphone #touchbar .bar-label{display:none}
  #touchbar .touchbar-keys{display:flex;flex:1;gap:6px;align-items:center;overflow-x:auto;padding:0;scrollbar-width:none}
  #touchbar .touchbar-system{display:flex;gap:4px;margin-left:auto;padding-left:18px}
  #touchbar .touchbar-system{scrollbar-width:none}
  #touchbar .touchbar-system::-webkit-scrollbar,#touchbar .touchbar-keys::-webkit-scrollbar{display:none}
  #touchbar .touchbar-system button{background:#181818;min-width:36px;padding:0 8px}
  #touchbar .bar-slider{display:none;align-items:center;gap:12px;flex:1;padding:0 16px;color:#ddd;font:12px system-ui}
  #touchbar .bar-slider input{width:100%;accent-color:#eaeaea;height:28px}
  #touchbar.volume-open .touchbar-keys{display:none}
  #touchbar.volume-open .bar-slider{display:flex}
  #touchbar.collapsed{justify-content:flex-end;height:22px;background:transparent;padding:0;border:0;box-shadow:none}
  #touchbar.collapsed .touchbar-keys,#touchbar.collapsed .bar-slider,#touchbar.collapsed .touchbar-system{display:none}
  #touchbar.collapsed button{height:22px;font-size:10px}
  body.tablet-bar #touchbar:not(.collapsed){height:68px}
  body.tablet-bar #touchbar:not(.collapsed) button{height:52px;font-size:14px}
  body.tablet-bar #touchbar:not(.collapsed) button svg{width:26px;height:26px}
  @media(max-width:650px){#touchbar{left:88px;gap:6px;padding:0 6px}#touchbar button{padding:0 9px;min-width:34px}#touchbar .touchbar-system{padding-left:6px}}
  body{position:relative;height:100%;height:100dvh}
  #stage{top:calc(var(--touchbar-top,28px) + env(safe-area-inset-top,0px));left:calc(96px + env(safe-area-inset-left,0px));right:calc(56px + env(safe-area-inset-right,0px));bottom:calc(28px + var(--app-ime-overlap,0px) + env(safe-area-inset-bottom,0px))}
  #touchbar{top:calc(14px + env(safe-area-inset-top,0px));left:calc(96px + env(safe-area-inset-left,0px));right:calc(56px + env(safe-area-inset-right,0px))}
  #touchbar .touchbar-keys{min-width:0}
  #touchbar .bar-slider{min-width:0;padding:0 8px}
  #touchbar .bar-slider input{min-width:0}
  #browserRail{top:calc(18px + env(safe-area-inset-top,0px))!important;left:calc(12px + env(safe-area-inset-left,0px))!important}
  @media(max-width:650px){#stage,#touchbar{left:calc(88px + env(safe-area-inset-left,0px));right:calc(56px + env(safe-area-inset-right,0px))}}
  body.iphone #stage,body.iphone #touchbar{left:calc(68px + env(safe-area-inset-left,0px));right:calc(16px + env(safe-area-inset-right,0px))}
  body.iphone #browserRail{width:44px!important;left:calc(8px + env(safe-area-inset-left,0px))!important}
  body.iphone #kb{left:calc(68px + env(safe-area-inset-left,0px));right:calc(16px + env(safe-area-inset-right,0px))}
  body.iphone #touchbar{gap:4px;padding:0 5px}
  body.iphone #touchbar button{min-width:30px;padding:0 7px}
  body.iphone #touchbar .touchbar-system{padding-left:4px;gap:3px}
  #iphoneInstallHint{position:fixed;bottom:calc(8px + env(safe-area-inset-bottom,0px));left:68px;right:16px;text-align:center;color:#8b8b8b;font:11px system-ui;pointer-events:none;z-index:44}
  #pad.matrix-feedback .dot i{display:none!important}
  .dot{transition:none!important}
  .dot i{left:-13px;top:-13px;width:26px;height:26px;
    background:radial-gradient(circle,rgba(91,125,165,.10),rgba(91,125,165,.025) 65%,transparent)!important;
    box-shadow:0 0 0 1px rgba(91,125,165,.24) inset!important;
    transform:scale(.78);transition:transform .09s ease,opacity .09s ease}
  .dot i::after{content:'';position:absolute;left:11px;top:11px;width:4px;height:4px;border-radius:50%;background:rgba(78,113,154,.42)}
  .dot.on i{transform:scale(1);opacity:1}
  .dot.out i{transform:scale(1.65);opacity:0;transition:transform .24s ease-out,opacity .24s ease-out}
  #hud{display:none!important}
  #hint{display:none!important}
  #kbToggle{display:none!important;left:18px;top:78px;bottom:auto!important;
    width:48px;height:44px;border-radius:16px;background:#171b22!important;color:#afb8c6!important;
    border:1px solid #2b323f!important;box-shadow:none!important;
    font-size:14px;transition:background .12s ease!important;touch-action:manipulation}
  body.kb #kbToggle{background:#dde5ee!important;color:#39577c!important}
  #kb{left:96px;right:56px;bottom:var(--app-ime-overlap,0px)!important;visibility:hidden;pointer-events:none;
    background:#101318!important;border-radius:20px 20px 0 0;
    border-top:1px solid #252c36;box-shadow:0 -5px 24px rgba(0,0,0,.2)!important;
    transition:transform .16s ease,visibility 0s .16s!important}
  body.kb #kb{visibility:visible;pointer-events:auto;transition:transform .16s ease,visibility 0s!important}
  #kbInput{background:#171c24!important;color:#d9e0e9!important;border:1px solid #2c3542!important;box-shadow:none!important}
  #kbInput::placeholder{color:#9ba5b2}
  #kb #kbEssential{flex-wrap:nowrap;align-items:center;gap:6px;margin-bottom:0}
  #kb #kbEssential button{font-size:12px;min-width:36px;padding:0 10px}
  #kb button{background:#1c222c!important;color:#bdc9da!important;border:1px solid #303b4a!important;touch-action:manipulation;transition:background .08s ease!important}
  #kb button.on{background:#294261!important;border-color:#52739b!important;color:#e1ebf8!important}
  body.layout-changing #pad{pointer-events:none}
  @media(max-width:650px){#stage{left:calc(88px + env(safe-area-inset-left,0px));right:calc(56px + env(safe-area-inset-right,0px))}#pad{border-radius:19px}#kb{left:88px;right:56px}}
  html,body{touch-action:auto!important}
  .trackpad-backdrop{position:absolute;inset:0;background:rgba(0,0,0,.48);z-index:70;display:none;touch-action:manipulation}
  .trackpad-sheet{z-index:80!important;box-sizing:border-box;overflow-y:auto!important;overscroll-behavior:contain;touch-action:pan-y;max-height:calc(var(--screen-h,100dvh) - 32px)!important}
  .trackpad-sheet-head{position:sticky;top:-18px;margin:-18px -18px 14px;padding:12px 14px;background:#101318;display:flex;align-items:center;justify-content:space-between;gap:10px;z-index:2;border-bottom:1px solid #303b4a}
  .trackpad-sheet-head button{min-width:52px;min-height:40px;border:1px solid #404c5b;border-radius:9px;background:#202936;color:#e7edf4;font:14px system-ui}
  body.sheet-open #pad{pointer-events:none}
  #browserRail{z-index:90!important}
  body.iphone{position:relative;width:var(--screen-w,100vw);height:var(--screen-h,100dvh);max-width:100%;overflow:hidden}
  body.iphone #pad{aspect-ratio:auto!important}
  body.iphone #stage{left:calc(60px + env(safe-area-inset-left,0px));right:calc(10px + env(safe-area-inset-right,0px));bottom:calc(12px + env(safe-area-inset-bottom,0px));top:calc(var(--touchbar-top,76px) + env(safe-area-inset-top,0px))}
  body.iphone #touchbar{position:absolute;left:calc(60px + env(safe-area-inset-left,0px));right:calc(10px + env(safe-area-inset-right,0px));max-width:calc(100% - 70px - env(safe-area-inset-left,0px) - env(safe-area-inset-right,0px));height:44px;overflow:hidden}
  body.iphone #touchbar button{height:32px;min-width:30px;padding:0 6px;touch-action:manipulation}
  body.iphone #touchbar .touchbar-keys{flex:1 1 0;min-width:0;touch-action:pan-x}
  body.iphone #touchbar .touchbar-system{flex:0 1 auto;max-width:62%;min-width:0;overflow-x:auto;touch-action:pan-x;margin-left:0}
  body.iphone #touchbar.collapsed{height:26px;max-width:none}
  body.iphone #touchbar .bar-slider{padding:0;gap:4px}
  body.iphone #touchbar.volume-open .touchbar-system{display:none}
  body.iphone #touchbar.volume-open .bar-slider{flex:1;min-width:0}
  body.iphone #kb{position:absolute;left:calc(60px + env(safe-area-inset-left,0px));right:calc(10px + env(safe-area-inset-right,0px));bottom:0!important;padding-bottom:max(8px,env(safe-area-inset-bottom,0px));max-width:calc(100% - 70px);overflow:hidden}
  body.iphone #kbInput{font-size:16px!important;min-width:0;width:100%}
  body.iphone #browserRail{position:absolute!important;top:calc(12px + env(safe-area-inset-top,0px))!important;left:calc(6px + env(safe-area-inset-left,0px))!important;width:44px!important;gap:8px!important}
  body.iphone #trackpadEdge{width:10px!important}
  body.iphone .trackpad-sheet{position:absolute!important;left:calc(60px + env(safe-area-inset-left,0px))!important;right:calc(8px + env(safe-area-inset-right,0px))!important;top:calc(8px + env(safe-area-inset-top,0px))!important;bottom:calc(8px + env(safe-area-inset-bottom,0px))!important;max-width:none!important;max-height:none!important;width:auto!important;padding:18px!important;border-radius:14px!important;font-size:13px}
  body.iphone .trackpad-sheet input[type=range]{width:100%;max-width:100%;min-height:38px}
  body.iphone #iphoneInstallHint{left:60px;right:10px;font-size:10px}
  /* All action keys share one footprint; left volume / right arrows keep their slots. */
  #touchbar:not(.collapsed) button{width:44px;min-width:44px;height:28px;padding:0;flex:0 0 44px;box-sizing:border-box}
  #touchbar .touchbar-system{min-width:0;max-width:60%;flex:0 1 auto;overflow-x:auto;touch-action:pan-x;padding-left:6px}
  #touchbar .touchbar-keys{touch-action:pan-x}
  body:not(.tablet-bar) #touchbar .bar-label{display:none}
  body.tablet-bar #touchbar:not(.collapsed) button{width:52px;min-width:52px;height:52px;flex-basis:52px;padding:0;flex-direction:column;gap:2px;font-size:12px;line-height:14px}
  body.tablet-bar #touchbar:not(.collapsed) button.bar-arrow{font-size:24px}
  body.tablet-bar #touchbar:not(.collapsed) button svg{width:26px;height:26px}
  body.iphone #touchbar:not(.collapsed) button{width:32px;min-width:32px;height:32px;flex-basis:32px;padding:0}
  #touchbar.volume-open .touchbar-system{max-width:52%}
  /* One glass surface: a quiet command strip, with a separate gesture region. */
  #pad .pad-command-strip{position:absolute;top:0;left:0;right:0;z-index:6;box-sizing:border-box;min-height:80px;padding:14px 24px;display:flex;align-items:center;justify-content:flex-end;background:linear-gradient(180deg,rgba(255,255,255,.62),rgba(238,245,238,.10));border-bottom:1px solid rgba(132,164,152,.10);touch-action:manipulation}
  #pad .pad-directions{display:flex;align-items:center;justify-content:flex-end;gap:28px;min-width:0}
  #pad .pad-direction-pair{display:flex;align-items:center;gap:14px}
  #pad .glass-arrow{--key-ink:#319eff;--key-rgb:49,158,255;position:relative;isolation:isolate;box-sizing:border-box;width:52px;height:52px;min-width:52px;padding:0;flex:0 0 52px;display:flex;align-items:center;justify-content:center;border:1px solid transparent;border-radius:13px;background:linear-gradient(155deg,rgba(255,255,255,.52),rgba(255,255,255,.07));color:var(--key-ink);font:26px -apple-system,BlinkMacSystemFont,sans-serif;touch-action:manipulation;-webkit-tap-highlight-color:transparent;transition:background .16s ease,transform .12s ease;text-shadow:0 -1px 1px rgba(255,255,255,.95),0 1px 1px rgba(255,255,255,.5),0 0 10px rgba(var(--key-rgb),.20);box-shadow:inset 0 1px 0 rgba(255,255,255,.6),inset 0 -1px 0 rgba(184,200,203,.08)}
  #pad .glass-arrow::before{content:'';position:absolute;inset:6px 2px 2px;z-index:-1;border-radius:50%;background:radial-gradient(ellipse,rgba(var(--key-rgb),.25),transparent 72%);filter:blur(8px);pointer-events:none;transform:translateY(3px);transition:background .18s ease,transform .18s ease}
  #pad .pad-seek-pair .glass-arrow{--key-ink:#03bba9;--key-rgb:3,187,169}
  #pad .glass-arrow::after{content:'';position:absolute;inset:17px 12px 7px;z-index:-1;border-radius:50%;background:rgba(var(--key-rgb),.07);filter:blur(5px);pointer-events:none}
  #pad .glass-arrow:active{transform:translateY(1px);background:linear-gradient(155deg,rgba(255,255,255,.60),rgba(255,255,255,.13));box-shadow:inset 0 1px 3px rgba(182,198,195,.14)}
  #pad .glass-arrow:active::before{background:radial-gradient(ellipse,rgba(var(--key-rgb),.41),transparent 72%);transform:translateY(1px) scale(1.18)}
  #pad .glass-arrow:active::after{background:rgba(var(--key-rgb),.18)}
  #pad.pad-compact .pad-command-strip{min-height:64px;padding:10px 12px}
  #pad.pad-compact .glass-arrow{width:44px;min-width:44px;height:44px;flex-basis:44px;font-size:24px}
  #pad.pad-compact .pad-direction-pair{gap:10px}
  #pad.pad-compact .pad-directions{gap:18px}
  #pad.pad-narrow .pad-directions{flex-wrap:wrap;row-gap:10px}
  #touchbar .touchbar-system{overflow:visible!important;flex:0 0 auto;max-width:none!important;padding-left:28px!important;border-left:1px solid rgba(255,255,255,.07);margin-left:auto!important}
  #touchbar .bar-lock{flex-shrink:0}
  #touchbar .bar-drag[aria-pressed=true]{background:#263e35;color:#a8d8c2}
  .dot i{background:radial-gradient(circle,rgba(19,185,178,.10),rgba(19,185,178,.025) 65%,transparent)!important;box-shadow:0 0 0 1px rgba(19,185,178,.24) inset!important}
  .dot i::after{background:rgba(19,185,178,.42)}
  @media(max-width:650px){#touchbar .touchbar-system{padding-left:20px!important}}
  @media(prefers-reduced-motion:reduce){.dot i,.dot.out i,#kb,#pad,#pad .glass-arrow,#pad .glass-arrow::before{transition:none!important}}
  `;
  document.head.appendChild(style);

  var layoutBusy = false, settleTimer = 0, keyboardOpen = false;
  var directDragControl=null,directDragTimer=0,padToolbar=null;
  function paintDragControl(active){
    if(!directDragControl)return;
    directDragControl.innerHTML='<svg aria-hidden="true" width="21" height="21" viewBox="0 0 26 26" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M13 3v20M3 13h20m-13-7 3-3 3 3m-6 14 3 3 3-3M6 10l-3 3 3 3m14-6 3 3-3 3"/></svg><span class="bar-label">拖移'+(active?' ●':'')+'</span>';
    directDragControl.style.color=active?'#9ad5b6':'#b5c8bc';
    directDragControl.setAttribute('aria-pressed',String(active));
  }
  window.trackpadEndDirectDrag=function(){
    window.trackpadDirectDrag=false;clearTimeout(directDragTimer);
    paintDragControl(false);
  };
  window.trackpadToggleDirectDrag=function(){
    var next=!window.trackpadDirectDrag;cancelContacts();if(raf){cancelAnimationFrame(raf);raf=0;}window.trackpadDirectDrag=next;
    paintDragControl(next);
    if(next)directDragTimer=setTimeout(function(){cancelContacts();},15000);
    return next;
  };
  function cancelContacts() {
    if(window.trackpadEndDirectDrag)trackpadEndDirectDrag();
    if (nativeMode) TrackpadNative.send('{"cancel":true}');
    else if (ws && ws.readyState === 1) ws.send('{"cancel":true,"p":[]}');
    clearAll();
  }
  function finishLayout() {
    measure();
    layoutBusy = false;
    document.body.classList.remove('layout-changing');
  }
  function beginLayout() {
    layoutBusy = true;
    document.body.classList.add('layout-changing');
    cancelContacts();
    clearTimeout(settleTimer);
    settleTimer = setTimeout(function () {
      requestAnimationFrame(function () { requestAnimationFrame(finishLayout); });
    }, 200);
  }
  function updateKeyboardBounds() {
    var vv = window.visualViewport;
    var phone=/iPhone|iPod/.test(navigator.userAgent||'')&&!nativeMode;
    if(phone){
      document.documentElement.style.setProperty('--screen-w',(vv?vv.width:innerWidth)+'px');
      document.documentElement.style.setProperty('--screen-h',(vv?vv.height:innerHeight)+'px');
    }
    var overlap = !phone&&vv ? Math.max(0, innerHeight-vv.height-vv.offsetTop) : 0;
    document.documentElement.style.setProperty('--app-ime-overlap',overlap+'px');
    document.body.style.setProperty('--kbh',keyboardOpen ? (kbEl.offsetHeight+12)+'px' : '0px');
  }
  var baseFlush = flush, baseInside = inside;
  flush = function () {
    if (layoutBusy) { raf = 0; return; }
    measure(); baseFlush();
  };
  function inCommandStrip(x,y){
    if(!padToolbar)return false;
    var box=padToolbar.getBoundingClientRect();
    return x>=box.left&&x<=box.right&&y>=box.top&&y<=box.bottom;
  }
  inside = function (x,y) { if (layoutBusy) return false; measure(); return !inCommandStrip(x,y)&&baseInside(x,y); };
  // Bounds jump atomically; only the keyboard surface animates. No stale coordinate frame.
  setKb = function (open) {
    beginLayout(); keyboardOpen = !!open;
    document.body.classList.toggle('kb',keyboardOpen);
    updateKeyboardBounds();
    if(!keyboardOpen&&window.resetRemoteEditor)resetRemoteEditor();
    if (keyboardOpen&&!nativeMode&&!(navigator.userAgent||'').includes('TrackpadAPK')) kbInput.focus(); else kbInput.blur();
  };
  window.trackpadLayoutChanged = function () {
    beginLayout(); updateKeyboardBounds();
    if (ws && ws.readyState === 1) {
      measure();
      wsSend({meta:{vw:Math.round(innerWidth),vh:Math.round(innerHeight),pw:Math.round(rect.width),ph:Math.round(rect.height)}});
    }
  };
  window.addEventListener('blur',cancelContacts);
  document.addEventListener('visibilitychange',function(){if(document.hidden)cancelContacts();});
  padEl.addEventListener('pointercancel',cancelContacts,true);
  padEl.addEventListener('touchcancel',cancelContacts,true);
  window.addEventListener('resize',window.trackpadLayoutChanged);
  window.addEventListener('orientationchange',window.trackpadLayoutChanged);
  if (window.visualViewport) {
    visualViewport.addEventListener('resize',window.trackpadLayoutChanged);
    visualViewport.addEventListener('scroll',function(){updateKeyboardBounds();measure();});
  }
  if (window.ResizeObserver) new ResizeObserver(function () { measure(); }).observe(padEl);

  // Non-empty real browser edits reach the input listener; never clear composing text here.
  var deleteFromKeydown=false,deleteFromPointer=false;
  kbInput.addEventListener('keydown',function(e){
    if(e.key!=='Backspace'||kbInput.value)return;
    e.preventDefault();e.stopImmediatePropagation();deleteFromKeydown=true;sendKey(51,curFlags());
    setTimeout(function(){deleteFromKeydown=false;},0);
  },true);
  kbInput.addEventListener('beforeinput',function(e){
    if(e.inputType!=='deleteContentBackward'||kbInput.value)return;
    e.preventDefault();if(!deleteFromKeydown)sendKey(51,curFlags());
  });
  Array.prototype.forEach.call(document.querySelectorAll('#kb [data-key="51"]'),function (button) {
    button.addEventListener('pointerdown',function (e) {
      e.preventDefault(); e.stopImmediatePropagation();
      deleteFromPointer = true;if(window.trackpadDeleteRemote)trackpadDeleteRemote();else sendKey(51,curFlags());
      setTimeout(function () { deleteFromPointer = false; },350);
    },true);
    button.addEventListener('click',function (e) {
      if (deleteFromPointer) {
        e.preventDefault(); e.stopImmediatePropagation(); deleteFromPointer = false;
      }
    },true);
    button.addEventListener('pointercancel',function () { deleteFromPointer = false; });
  });

  if (nativeMode) kbInput.placeholder = '英文直接输入到 Mac；平板不保留文字';
  document.getElementById('hint').textContent = '轻点 · 滚动 · 手势';
  // Fullscreen is best-effort and never blocks the input connection.
  var iphone=/iPhone|iPod/.test(navigator.userAgent||'');
  var standalone=!!navigator.standalone||!!(window.matchMedia&&window.matchMedia('(display-mode: standalone)').matches);
  if(iphone)document.body.classList.add('iphone');
  var ua=navigator.userAgent||'',screenSize=window.screen||{};
  var tabletBar=nativeMode&&TrackpadNative.isTablet?TrackpadNative.isTablet():!iphone&&(/iPad/.test(ua)||(/Macintosh/.test(ua)&&navigator.maxTouchPoints>1)||Math.min(screenSize.width||innerWidth,screenSize.height||innerHeight)>=600);
  if(tabletBar)document.body.classList.add('tablet-bar');
  window.trackpadStart = function (userGesture) {
    gate.style.display = 'none';
    updateKeyboardBounds(); measure();
    on = true; connect();
    if(userGesture&&!nativeMode&&!standalone){
      var el=document.documentElement,request=el.requestFullscreen||el.webkitRequestFullscreen;
      if(request&&!document.fullscreenElement&&!document.webkitFullscreenElement){try{Promise.resolve(request.call(el)).catch(function(){});}catch(e){}}
    }
    if(userGesture&&navigator.wakeLock){try{navigator.wakeLock.request('screen').catch(function(){});}catch(e){}}
  };
  if(iphone&&!standalone&&!nativeMode){
    var installHint=document.createElement('div');installHint.id='iphoneInstallHint';installHint.textContent='分享 → 添加到主屏幕，即可默认全屏打开';document.body.appendChild(installHint);
  }

  // The same settings contract is used by APK LAN and standalone browser frames.
  window.trackpadFeel={pointerGain:720,scrollSpeed:1,inertia:1,dragLock:false};
  try {
    var savedFeel=JSON.parse(localStorage.getItem('trackpadFeel')||'null');
    if(savedFeel&&typeof savedFeel==='object')Object.assign(trackpadFeel,savedFeel);
    else trackpadFeel.pointerGain=Number(localStorage.getItem('trackpadGain'))||720;
  } catch(_){}
  function cleanFeel(value,low,high,fallback){var n=Number(value);return Number.isFinite(n)?Math.max(low,Math.min(high,n)):fallback;}
  window.trackpadSetSettings=function(next){
    next=next||{};
    ['pointerGain','scrollSpeed','inertia','dragLock'].forEach(function(key){if(Object.prototype.hasOwnProperty.call(next,key))trackpadFeel[key]=next[key];});
    trackpadFeel.pointerGain=cleanFeel(trackpadFeel.pointerGain,250,1400,720);
    trackpadFeel.scrollSpeed=cleanFeel(trackpadFeel.scrollSpeed,.5,2,1);
    trackpadFeel.inertia=cleanFeel(trackpadFeel.inertia,0,1.5,1);trackpadFeel.dragLock=trackpadFeel.dragLock===true;
    window.trackpadPointerGain=trackpadFeel.pointerGain;
    try{localStorage.setItem('trackpadFeel',JSON.stringify(trackpadFeel));}catch(_){}
    cancelContacts();
    if(!nativeMode)wsSend({settings:trackpadFeel});
  };
  window.trackpadPointerGain=trackpadFeel.pointerGain;
  window.trackpadSetGain=function(value){trackpadSetSettings({pointerGain:value});};
  var browserConnectionControl=null;
  var inputAllowed=true;
  window.trackpadHandleServerStatus=function(status){
    if(!status)return;var wasAllowed=inputAllowed;inputAllowed=status.inputReady!==false;window.trackpadInputAllowed=inputAllowed;if(wasAllowed&&!inputAllowed)cancelContacts();
    var text=(status.machine||'Mac')+' · '+(status.inputReady===false?'已连接，但Mac未授权辅助功能；请在Mac系统设置允许运行接收端的终端/应用':status.inputReady===true?'已连接，可控制':'已连接，控制权限状态待确认')+' · 已收到触摸帧 '+(status.inputFrames||0);
    if(!wasAllowed&&inputAllowed)wsSend({settings:trackpadFeel});if(window.trackpadConnectionStatus)trackpadConnectionStatus(text);connectionIndicator(inputAllowed);if(browserConnectionControl)browserConnectionControl.setAttribute('aria-label','连接：'+text);
  };
  function connectionIndicator(ready){if(browserConnectionControl){browserConnectionControl.textContent='连接\n'+(ready&&inputAllowed?'●':'○');browserConnectionControl.style.color=ready?'#95baae':'#afb8c6';browserConnectionControl.setAttribute('aria-label',ready?'连接：输入通道已建立':'连接：输入通道未建立');}}
  if(!nativeMode){
    var previousConnect=connect;
    connect=function(){
      var oldSocket=ws;previousConnect();var socket=ws;if(!socket||socket===oldSocket)return;var opened=socket.onopen,closed=socket.onclose,failed=socket.onerror;
      socket.onopen=function(){if(socket!==ws)return;if(opened)opened.apply(socket,arguments);connectionIndicator(true);wsSend({settings:trackpadFeel});};
      socket.onclose=function(){if(socket!==ws)return;connectionIndicator(false);if(closed)closed.apply(socket,arguments);};
      socket.onerror=function(){if(socket!==ws)return;connectionIndicator(false);if(failed)failed.apply(socket,arguments);};
    };
    var boundaryCount=0,previousRefresh=refresh;
    refresh=function(){previousRefresh();if(touches.size!==boundaryCount){boundaryCount=touches.size;if(raf){cancelAnimationFrame(raf);raf=0;}flush();}};
  }
  // A real browser gets equivalent left controls; APK supplies its native controls.
  if (!nativeMode && !window.TrackpadApk && !(navigator.userAgent||'').includes('TrackpadAPK')) {
    var rail = document.createElement('div');rail.id='browserRail';
    rail.style.cssText='position:fixed;left:12px;top:18px;width:52px;display:flex;flex-direction:column;gap:12px;z-index:50';
    function control(title, action) {
      var b=document.createElement('button');b.textContent=title;
      b.style.cssText='height:48px;border-radius:16px;border:1px solid #2b323f;background:#171b22;color:#afb8c6;touch-action:manipulation';
      b.onclick=action;rail.appendChild(b);return b;
    }
    var backdrop=document.createElement('div');backdrop.className='trackpad-backdrop';document.body.appendChild(backdrop);
    var activeSheet=null;
    function closeSheets(){if(activeSheet)activeSheet.style.display='none';activeSheet=null;backdrop.style.display='none';document.body.classList.remove('sheet-open');}
    function showSheet(sheet){if(activeSheet===sheet){closeSheets();return;}cancelContacts();closeSheets();if(keyboardOpen)setKb(false);activeSheet=sheet;sheet.style.display='block';backdrop.style.display='block';document.body.classList.add('sheet-open');}
    function sheetHeader(sheet,title){sheet.classList.add('trackpad-sheet');var head=document.createElement('div');head.className='trackpad-sheet-head';var label=document.createElement('strong');label.textContent=title;var close=document.createElement('button');close.textContent='关闭';close.setAttribute('aria-label','关闭'+title+'面板');close.onclick=closeSheets;head.appendChild(label);head.appendChild(close);sheet.appendChild(head);}
    backdrop.onclick=closeSheets;window.trackpadClosePanels=closeSheets;
    document.addEventListener('keydown',function(e){if(e.key==='Escape')closeSheets();});
    var connectionPanel=document.createElement('div');connectionPanel.style.cssText='display:none;position:fixed;left:80px;top:18px;right:30px;max-width:350px;padding:20px;border-radius:18px;background:#101318;color:#c6cedb;border:1px solid #303b4a;z-index:65;font:14px system-ui;line-height:1.7';
    sheetHeader(connectionPanel,'连接');
    var connectionText=document.createElement('div');connectionText.textContent='已记住此设备，正在连接Mac…';connectionPanel.appendChild(connectionText);
    var connectionHelp=document.createElement('p');connectionHelp.textContent='同一时间仅一台设备控制。若权限撤销、浏览器记录清除或Mac地址变化，请在Mac打开触摸板图标并重新扫码。';connectionPanel.appendChild(connectionHelp);
    var closeConnection=document.createElement('button');closeConnection.textContent='返回触摸板';closeConnection.onclick=closeSheets;connectionPanel.appendChild(closeConnection);document.body.appendChild(connectionPanel);
    window.trackpadConnectionStatus=function(text){connectionText.textContent=text;if(browserConnectionControl)browserConnectionControl.setAttribute('aria-label','连接：'+text);};
    browserConnectionControl=control('连接\n○',function(){showSheet(connectionPanel);window.trackpadStart(true);});browserConnectionControl.style.whiteSpace='pre-line';
    control('键盘',function(){closeSheets();setKb(!document.body.classList.contains('kb'));});
    var panel=document.createElement('div');
    panel.style.cssText='display:none;position:fixed;left:80px;top:18px;max-width:280px;padding:18px;border-radius:18px;background:#101318;color:#c6cedb;border:1px solid #303b4a;z-index:60;max-height:80vh;overflow:auto';
    sheetHeader(panel,'手感');
    var presetRow=document.createElement('div');panel.appendChild(presetRow);var feelInputs={};
    function addFeel(title,key,min,max,step){
      var label=document.createElement('label');label.textContent=title;label.style.display='block';panel.appendChild(label);
      var input=document.createElement('input');input.type='range';input.min=String(min);input.max=String(max);input.step=String(step);input.value=String(trackpadFeel[key]);input.setAttribute('aria-label',title);input.oninput=function(){var change={};change[key]=Number(this.value);trackpadSetSettings(change);};panel.appendChild(input);feelInputs[key]=input;
    }
    addFeel('指针速度','pointerGain',250,1400,10);addFeel('滚动速度','scrollSpeed',.5,2,.05);addFeel('惯性强度（0为关闭）','inertia',0,1.5,.05);
    [{name:'精细',pointerGain:450,scrollSpeed:.75,inertia:.65},{name:'标准',pointerGain:720,scrollSpeed:1,inertia:1},{name:'快速',pointerGain:1000,scrollSpeed:1.4,inertia:1.2}].forEach(function(preset){
      var b=document.createElement('button');b.textContent=preset.name;b.style.cssText='background:#1c222c;color:#c6cedb;border:1px solid #303b4a;border-radius:8px;padding:6px 9px;margin:0 4px 10px 0';b.onclick=function(){trackpadSetSettings(preset);Object.keys(feelInputs).forEach(function(k){feelInputs[k].value=String(trackpadFeel[k]);});};presetRow.appendChild(b);
    });
    var dragLabel=document.createElement('label');dragLabel.style.cssText='display:block;font-size:13px;margin:8px 0 14px';var drag=document.createElement('input');drag.type='checkbox';drag.checked=trackpadFeel.dragLock;drag.setAttribute('aria-label','拖拽锁定');drag.onchange=function(){trackpadSetSettings({dragLock:this.checked});};dragLabel.appendChild(drag);var dragText=document.createElement('span');dragText.textContent='拖拽锁定（轻点结束，5秒无接触自动释放）';dragLabel.appendChild(dragText);panel.appendChild(dragLabel);
    var note=document.createElement('div');note.textContent='Mac 通知中心：先把系统“显示通知中心”快捷键设为 Control+Option+Command+N，再勾选启用右侧双指左滑。';note.style.fontSize='13px';panel.appendChild(note);
    var enabled=document.createElement('input');enabled.type='checkbox';
    try{enabled.checked=localStorage.getItem('trackpadNotification')==='true';}catch(_){}
    enabled.onchange=function(){try{localStorage.setItem('trackpadNotification',String(enabled.checked));}catch(_){}};var notifyLabel=document.createElement('label');notifyLabel.style.fontSize='13px';notifyLabel.appendChild(enabled);var notifyText=document.createElement('span');notifyText.textContent='启用通知中心手势';notifyLabel.appendChild(notifyText);panel.appendChild(notifyLabel);
    control('手感',function(){showSheet(panel);});
    document.body.appendChild(rail);document.body.appendChild(panel);
    var edge=document.createElement('div');edge.id='trackpadEdge';edge.style.cssText='position:fixed;top:0;right:0;bottom:0;width:56px;z-index:40;touch-action:none';
    var edgeStart=null,edgeFired=false;
    edge.addEventListener('touchstart',function(e){e.preventDefault();if(e.touches.length===2&&!edgeFired){edgeStart={x:(e.touches[0].clientX+e.touches[1].clientX)/2,y:(e.touches[0].clientY+e.touches[1].clientY)/2,t:Date.now()};}else if(e.touches.length>2){edgeStart=null;edgeFired=true;}},{passive:false});
    edge.addEventListener('touchmove',function(e){e.preventDefault();if(!edgeStart||edgeFired||e.touches.length!==2)return;var x=(e.touches[0].clientX+e.touches[1].clientX)/2,y=(e.touches[0].clientY+e.touches[1].clientY)/2;if(Math.abs(y-edgeStart.y)>innerHeight*.08||Date.now()-edgeStart.t>1000){edgeFired=true;return;}if(edgeStart.x-x>innerWidth*.055){edgeFired=true;if(enabled.checked)sendKey(45,1835008);else showSheet(panel);}},{passive:false});
    function edgeEnd(e){e.preventDefault();if(!e.touches.length){edgeStart=null;edgeFired=false;}}
    edge.addEventListener('touchend',edgeEnd,{passive:false});edge.addEventListener('touchcancel',edgeEnd,{passive:false});document.body.appendChild(edge);
  }
  // Fit a physical-trackpad-like 1.4:1 surface inside the available keyboard-safe area.
  function fitSurface() {
    if(typeof getComputedStyle!=='function')return;
    var stage=document.getElementById('stage');if(!stage)return;
    var box=stage.getBoundingClientRect(),css=getComputedStyle(stage);
    var width=Math.max(0,box.width-parseFloat(css.paddingLeft||0)-parseFloat(css.paddingRight||0));
    var height=Math.max(0,box.height-parseFloat(css.paddingTop||0)-parseFloat(css.paddingBottom||0));
    // Phone browsers use the available height; tablet/native surfaces keep 1.4:1.
    var phoneSurface=iphone&&!nativeMode;
    var w=phoneSurface?width:Math.min(width,height*1.4),h=phoneSurface?height:w/1.4;
    if(w>0&&h>0){padEl.style.setProperty('--pad-width',w+'px');padEl.style.setProperty('--pad-height',h+'px');padEl.classList.toggle('pad-compact',w<360);padEl.classList.toggle('pad-narrow',w<246);}
  }
  var originalMeasure=measure;
  measure=function(){fitSurface();originalMeasure();};
  // Discrete light points, never a continuous water ring; one bounded animation loop.
  var matrix=document.createElement('canvas');
  var ink=matrix.getContext?matrix.getContext('2d'):null;
  if(ink) {
    matrix.setAttribute('aria-hidden','true');
    matrix.style.cssText='position:absolute;inset:0;width:100%;height:100%;pointer-events:none;z-index:2;border-radius:inherit';
    padEl.appendChild(matrix);padEl.classList.add('matrix-feedback');
    var pulses=[],matrixRaf=0,lastPulse=0,canvasW=0,canvasH=0;
    var reduceMotion=window.matchMedia&&matchMedia('(prefers-reduced-motion: reduce)').matches;
    function drawMatrix(time) {
      matrixRaf=0;
      var box=padEl.getBoundingClientRect(),dpr=Math.min(window.devicePixelRatio||1,1.5);
      if(canvasW!==box.width||canvasH!==box.height){canvasW=box.width;canvasH=box.height;matrix.width=Math.round(canvasW*dpr);matrix.height=Math.round(canvasH*dpr);}
      ink.setTransform(dpr,0,0,dpr,0,0);ink.clearRect(0,0,canvasW,canvasH);
      pulses=pulses.filter(function(p){return time-p.t<760;});
      var stripBottom=padToolbar?Math.max(0,padToolbar.getBoundingClientRect().bottom-box.top):0;
      pulses.forEach(function(p){
        var age=Math.max(0,(time-p.t)/760),radius=5+68*(1-Math.pow(1-age,2)),fade=Math.pow(1-age,1.7);
        var halo=ink.createRadialGradient(p.x,p.y,0,p.x,p.y,100);
        halo.addColorStop(0,'rgba(36,210,193,'+(.065*fade)+')');halo.addColorStop(.55,'rgba(58,216,201,'+(.018*fade)+')');halo.addColorStop(1,'rgba(58,216,201,0)');
        ink.fillStyle=halo;ink.fillRect(p.x-100,Math.max(stripBottom,p.y-100),200,Math.max(0,p.y+100-Math.max(stripBottom,p.y-100)));
        var reach=radius+18,step=7;
        for(var y=Math.max(stripBottom+4,Math.ceil((p.y-reach)/step)*step);y<Math.min(canvasH,p.y+reach);y+=step){
          for(var x=Math.max(3,Math.ceil((p.x-reach)/step)*step);x<Math.min(canvasW,p.x+reach);x+=step){
            var dist=Math.hypot(x-p.x,y-p.y),band=Math.exp(-Math.pow((dist-radius)/10,2));
            var core=.42*Math.exp(-dist*dist/180),alpha=(band*.33+core)*fade;
            if(alpha<.014)continue;
            ink.fillStyle='rgba(19,185,178,'+alpha.toFixed(3)+')';ink.beginPath();ink.arc(x,y,.7+band*.45,0,Math.PI*2);ink.fill();
          }
        }
      });
      if(pulses.length)matrixRaf=requestAnimationFrame(drawMatrix);
    }
    function pulse(x,y,force){
      if(reduceMotion||inCommandStrip(x,y))return;
      var now=performance.now();if(!force&&now-lastPulse<110)return;lastPulse=now;
      var box=padEl.getBoundingClientRect();pulses.push({x:x-box.left,y:y-box.top,t:now});
      if(pulses.length>6)pulses.shift();if(!matrixRaf)matrixRaf=requestAnimationFrame(drawMatrix);
    }
    if(window.PointerEvent){
      padEl.addEventListener('pointerdown',function(e){if(e.pointerType!=='mouse')pulse(e.clientX,e.clientY,true);},{passive:true});
      padEl.addEventListener('pointermove',function(e){if(e.pointerType!=='mouse'&&e.buttons)pulse(e.clientX,e.clientY,false);},{passive:true});
    }else{
      padEl.addEventListener('touchstart',function(e){Array.prototype.forEach.call(e.changedTouches,function(t){pulse(t.clientX,t.clientY,true);});},{passive:true});
      padEl.addEventListener('touchmove',function(e){if(e.touches.length)pulse(e.touches[0].clientX,e.touches[0].clientY,false);},{passive:true});
    }
    document.addEventListener('visibilitychange',function(){if(document.hidden){pulses=[];if(matrixRaf)cancelAnimationFrame(matrixRaf);matrixRaf=0;ink.clearRect(0,0,canvasW,canvasH);}});
  }
  // Independent shortcut surface, shared by WebSocket and native HID transport.
  var touchbar=document.createElement('div');touchbar.id='touchbar';
  var shortcutKeys=document.createElement('div');shortcutKeys.className='touchbar-keys';
  var systemKeys=document.createElement('div');systemKeys.className='touchbar-system';
  function barKey(label,code,flags,parent){
    var key=document.createElement('button');key.textContent=label;key.setAttribute('aria-label','Touch Bar '+label);
    var speaker='<path d="M4 9h4l5-4v14l-5-4H4z"/>';
    var icons={'音量−':speaker+'<path d="M17 12h5"/>','音量+':speaker+'<path d="M17 12h5m-2.5-2.5v5"/>','静音':speaker+'<path d="m17 9 5 6m0-6-5 6"/>','音量':speaker+'<path d="M17 8q5 4 0 8M20 5q7 7 0 14"/>','锁屏':'<rect x="6" y="10" width="12" height="11" rx="2"/><path d="M9 10V6a3 3 0 0 1 6 0v4"/>'};
    icons['截图']='<path d="M8 4H4v4m14-4h4v4M4 18v4h4m14-4v4h-4"/><rect x="8" y="8" width="10" height="10" rx="2"/>';
    icons['复制']='<rect x="9" y="9" width="12" height="13" rx="2"/><path d="M17 5H5v13"/>';
    icons['粘贴']='<rect x="5" y="6" width="15" height="16" rx="2"/><rect x="9" y="3" width="7" height="5" rx="1"/>';
    icons['撤销']='<path d="m9 5-5 5 5 5M4 10h11a6 6 0 0 1 0 12"/>';
    icons['全选']='<rect x="4" y="4" width="18" height="18" rx="2" stroke-dasharray="3 3"/><path d="m8 13 3 3 7-7"/>';
    var accents={'截图':'#b8a1ff','复制':'#4d9dff','粘贴':'#38cfb3','撤销':'#bd8aff','全选':'#a6adb9','音量−':'#5cbbff','音量+':'#5cbbff','音量':'#5cbbff','静音':'#ffc658','锁屏':'#fa8f83'};
    if(accents[label])key.style.color=accents[label];
    if(label==='锁屏')key.classList.add('bar-lock');
    if(icons[label])key.innerHTML='<svg aria-hidden="true" width="21" height="21" viewBox="0 0 26 26" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" style="display:block;margin:auto">'+icons[label]+'</svg><span class="bar-label">'+label+'</span>';
    key.onclick=function(){cancelContacts();sendKey(code,flags);};parent.appendChild(key);return key;
  }
  [["esc",53,0],["复制",8,1048576],["粘贴",9,1048576],["撤销",6,1048576],["全选",0,1048576]].forEach(function(item){barKey(item[0],item[1],item[2],shortcutKeys);});
  var screenshotKey=barKey('截图',21,1179648,shortcutKeys);
  screenshotKey.setAttribute('aria-label','截图：进入Mac选区后单指划选，抬手完成');
  screenshotKey.onclick=function(){
    if(window.trackpadClosePanels)trackpadClosePanels();
    cancelContacts();sendKey(21,1179648);trackpadToggleDirectDrag();
  };
  directDragControl=barKey('拖移',0,0,shortcutKeys);directDragControl.classList.add('bar-drag');paintDragControl(false);
  directDragControl.onclick=function(){if(window.trackpadClosePanels)trackpadClosePanels();trackpadToggleDirectDrag();};
  directDragControl.setAttribute('aria-label','拖移：点一次后单指划选，抬手自动结束');
  directDragControl.setAttribute('aria-pressed','false');
  var volumePanel=document.createElement('div');volumePanel.className='bar-slider';
  var closeVolume=document.createElement('button');closeVolume.textContent='完成';closeVolume.onclick=function(){touchbar.classList.remove('volume-open');};
  var volumeLabel=document.createElement('span');volumeLabel.textContent='音量';
  var volumeSlider=document.createElement('input');volumeSlider.type='range';volumeSlider.min='0';volumeSlider.max='16';volumeSlider.step='1';volumeSlider.value='8';volumeSlider.setAttribute('aria-label','相对音量调节');
  window.trackpadVolumeStatus=function(value){
    var notice=document.getElementById('trackpadVolumeNotice');if(!notice){notice=document.createElement('div');notice.id='trackpadVolumeNotice';notice.setAttribute('role','status');notice.style.cssText='position:fixed;left:64px;right:12px;bottom:18px;z-index:100;border-radius:12px;padding:12px;background:#18212d;color:#e2e7ee;font:13px system-ui;pointer-events:none';document.body.appendChild(notice);}
    notice.textContent=value.ok?(value.muted?'Mac已静音':'Mac音量 '+value.level+'%'):value.message;notice.style.display='block';clearTimeout(window.trackpadVolumeNoticeTimer);window.trackpadVolumeNoticeTimer=setTimeout(function(){notice.style.display='none';},3500);
  };
  var lastVolume=8;
  // Relative control: the Mac does not report its current output level over HID.
  volumeSlider.addEventListener('input',function(){var next=Number(volumeSlider.value),diff=next-lastVolume;lastVolume=next;cancelContacts();for(var i=0;i<Math.abs(diff);i++)sendKey(diff>0?72:73,0);});
  volumePanel.appendChild(volumeLabel);volumePanel.appendChild(volumeSlider);volumePanel.appendChild(closeVolume);
  barKey('音量−',73,0,shortcutKeys);barKey('静音',74,0,shortcutKeys);
  barKey('音量+',72,0,shortcutKeys);var volumeOpen=barKey('音量',72,0,shortcutKeys);volumeOpen.onclick=function(){cancelContacts();touchbar.classList.add('volume-open');lastVolume=8;volumeSlider.value='8';};
  padToolbar=document.createElement('div');padToolbar.id='padCommandStrip';padToolbar.className='pad-command-strip';padToolbar.setAttribute('role','toolbar');padToolbar.setAttribute('aria-label','玻璃面板方向键');
  var directions=document.createElement('div');directions.className='pad-directions';
  var verticalPair=document.createElement('div');verticalPair.className='pad-direction-pair';
  var seekPair=document.createElement('div');seekPair.className='pad-direction-pair pad-seek-pair';
  [['↑',126,verticalPair,'向上'],['↓',125,verticalPair,'向下'],['←',123,seekPair,'向左，播放器快退'],['→',124,seekPair,'向右，播放器快进']].forEach(function(item){var key=barKey(item[0],item[1],0,item[2]);key.classList.add('glass-arrow');key.setAttribute('aria-label',item[3]);});
  directions.appendChild(verticalPair);directions.appendChild(seekPair);padToolbar.appendChild(directions);padEl.appendChild(padToolbar);
  ['pointerdown','pointermove','pointerup','pointercancel','touchstart','touchmove','touchend','touchcancel'].forEach(function(name){padToolbar.addEventListener(name,function(e){e.stopPropagation();if(name==='pointerdown'||name==='touchstart')cancelContacts();},{passive:true});});
  var lockKey=barKey('锁屏',12,1310720,systemKeys);lockKey.style.marginLeft='0';
  var barToggle=document.createElement('button');barToggle.textContent='收起';barToggle.setAttribute('aria-label','收起 Touch Bar');
  var barHidden=false;try{barHidden=localStorage.getItem('trackpadTouchBarHidden')==='1';}catch(e){}
  function layoutTouchbar(){touchbar.classList.toggle('collapsed',barHidden);barToggle.textContent=barHidden?'Touch Bar':'收起';barToggle.setAttribute('aria-label',barHidden?'展开 Touch Bar':'收起 Touch Bar');document.documentElement.style.setProperty('--touchbar-top',barHidden?'40px':tabletBar?'108px':'80px');}
  barToggle.onclick=function(){beginLayout();barHidden=!barHidden;try{localStorage.setItem('trackpadTouchBarHidden',barHidden?'1':'0');}catch(e){}layoutTouchbar();};
  touchbar.appendChild(shortcutKeys);touchbar.appendChild(volumePanel);touchbar.appendChild(systemKeys);touchbar.appendChild(barToggle);document.body.appendChild(touchbar);layoutTouchbar();
  var privateInput=false;
  var privateButton=document.createElement('button');privateButton.textContent='隐私输入：关';privateButton.setAttribute('aria-label','切换隐私输入');
  privateButton.style.cssText='margin:0 auto 0 0;order:-1;padding:7px 10px;border-radius:8px;font:12px system-ui;white-space:nowrap';
  privateButton.addEventListener('pointerdown',function(e){e.preventDefault();});
  privateButton.onclick=function(){
    cancelContacts();if(window.resetRemoteEditor)resetRemoteEditor();kbInput.value='';privateInput=!privateInput;
    kbInput.type=privateInput?'password':'text';kbInput.setAttribute('autocomplete','off');kbInput.setAttribute('autocorrect','off');kbInput.setAttribute('spellcheck','false');
    privateButton.textContent='隐私输入：'+(privateInput?'开':'关');privateButton.setAttribute('aria-pressed',String(privateInput));
    if(nativeMode&&TrackpadNative.privateInput)TrackpadNative.privateInput(privateInput);
    if(!nativeMode&&keyboardOpen)kbInput.focus();
  };
  (document.getElementById('kbEssential')||kbEl).appendChild(privateButton);
  var hideKeyboard=document.getElementById('kbHide');if(hideKeyboard)hideKeyboard.onclick=function(){if(nativeMode&&TrackpadNative.closeKeyboard)TrackpadNative.closeKeyboard();else setKb(false);};
  document.addEventListener('visibilitychange',function(){if(document.hidden){if(window.resetRemoteEditor)resetRemoteEditor();kbInput.value='';}});
  measure();
  if(standalone&&!nativeMode)window.trackpadStart();
})();
