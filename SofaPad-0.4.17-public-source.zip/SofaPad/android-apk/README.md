# SofaPad Android测试应用

0.4.17，versionCode25。Java17，compile/targetSDK35，minSDK28。应用内支持局域网HTTP/WS与标准蓝牙HID，本地WebView复用共享界面，ZXing离线二维码扫描。

[项目介绍](../README.md) · [安装](../docs/getting-started.md) · [全部手势](../docs/gestures.md) · [开发构建](../docs/development.md) · [网络隐私](../SECURITY.md)

蓝牙是否可注册/自动重连取决于ROM；没有任意中文Unicode注入。当前局域网为明文，仅可信私网，不需要证书。Android9/API28的API存在不等于每款设备都可用。

发行包位于../releases/0.4.17/。源仓库不含签名私钥、设备凭据和本地测试记录。GitHub Actions产物采用临时debug签名，不能当作与原测试包同签名的更新。构建工作流位于仓库根目录.github/workflows/android.yml。
