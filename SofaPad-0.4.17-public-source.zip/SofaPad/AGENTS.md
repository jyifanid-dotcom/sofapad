# SofaPad collaboration

- Keep the shared UI consistent across web, APK LAN and APK Bluetooth; document transport-specific limitations.
- Never claim standard HID is Apple's private trackpad protocol or arbitrary Unicode injection.
- Preserve established fast-scroll behavior; relevant changes cover slow/fast, direction and inertia interruption.
- Drag lock defaults off; all disconnect/background/timeout paths release held input.
- Record source, version, signature and test scope. Mocks and desktop previews are not hardware acceptance.
- No personal records, pairing secrets, private keys or real input in repository/test artifacts.
- Hardware concept drawings are not manufacturing-release data.
