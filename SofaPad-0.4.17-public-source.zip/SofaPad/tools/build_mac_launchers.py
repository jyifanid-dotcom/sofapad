from pathlib import Path
import math,struct,zlib,plistlib,subprocess,sys
ROOT=Path(__file__).resolve().parents[1];sys.dont_write_bytecode=True;sys.path.insert(0,str(ROOT));from vendor.qrcodegen import QrCode
ART=ROOT/'设计预览/启动图标';ART.mkdir(exist_ok=True)
def inside(x,y,rect,r):
    a,b,w,h=rect;dx=max(a+r-x,0,x-(a+w-r));dy=max(b+r-y,0,y-(b+h-r));return a<=x<a+w and b<=y<b+h and dx*dx+dy*dy<=r*r
qr=QrCode.encode_text('Tablet Trackpad',QrCode.Ecc.MEDIUM)
def png(path,pair=False):
    size=1024;rows=[]
    for y in range(size):
        row=bytearray(b'\0')
        for x in range(size):
            color=(0,0,0,0)
            if inside(x,y,(24,24,976,976),220):
                t=y/1024;color=(int(29-17*t),int(34-20*t),int(41-24*t),255)
                if inside(x,y,(142,173,740,90),24):color=(6,8,11,255)
                for i,c in enumerate([(78,157,255),(56,207,179),(189,138,255),(255,198,88),(250,143,131)]):
                    if inside(x,y,(171+i*137,198,112,38),9):color=(*c,255)
                if inside(x,y,(146,308,732,551),58):color=(154,154,149,255)
                if inside(x,y,(146,296,732,551),58):
                    t=(y-296)/551;color=(int(255-8*t),int(255-8*t),int(252-9*t),255)
                    if pair:
                        unit=13;side=qr.get_size();left=(1024-side*unit)//2;top=389
                        qx,qy=(x-left)//unit,(y-top)//unit
                        if 0<=qx<side and 0<=qy<side and qr.get_module(qx,qy):color=(30,33,37,255)
                    else:
                        for gy in range(7):
                            for gx in range(9):
                                px,py=392+gx*30,464+gy*30;d=(x-px)**2+(y-py)**2
                                if d<10:
                                    radial=((px-510)**2+(py-550)**2)**.5
                                    shade=int(164+min(70,radial*.43));color=(shade,shade+2,min(255,shade+5),255)
            row.extend(color)
        rows.append(bytes(row))
    def chunk(kind,data):return struct.pack('>I',len(data))+kind+data+struct.pack('>I',zlib.crc32(kind+data)&0xffffffff)
    path.write_bytes(b'\x89PNG\r\n\x1a\n'+chunk(b'IHDR',struct.pack('>IIBBBBB',size,size,8,6,0,0,0))+chunk(b'IDAT',zlib.compress(b''.join(rows),9))+chunk(b'IEND',b''))
for name,pair,target in [('触摸板',False,'tools/启动接收端.command')]:
    icon=ART/(name+'.png');png(icon,pair)
    app=ROOT/(name+'.app');resources=app/'Contents/Resources';macos=app/'Contents/MacOS';resources.mkdir(parents=True,exist_ok=True);macos.mkdir(exist_ok=True)
    iconset=Path('/private/tmp')/('trackpad-'+('pair' if pair else 'launch')+'.iconset');iconset.mkdir(exist_ok=True)
    for n in [16,32,128,256,512]:
        for scale in [1,2]:
            output=iconset/('icon_%dx%d%s.png'%(n,n,'@2x' if scale==2 else ''))
            subprocess.run(['/usr/bin/sips','-z',str(n*scale),str(n*scale),str(icon),'--out',str(output)],check=True,stdout=subprocess.DEVNULL)
    chunks=[]
    for kind,filename in [('icp4','icon_16x16.png'),('icp5','icon_32x32.png'),('icp6','icon_32x32@2x.png'),('ic07','icon_128x128.png'),('ic08','icon_256x256.png'),('ic09','icon_512x512.png'),('ic10','icon_512x512@2x.png')]:
        data=(iconset/filename).read_bytes();chunks.append(kind.encode()+struct.pack('>I',len(data)+8)+data)
    payload=b''.join(chunks);(resources/'Trackpad.icns').write_bytes(b'icns'+struct.pack('>I',len(payload)+8)+payload)
    subprocess.run(['/usr/bin/sips','-g','pixelWidth',str(resources/'Trackpad.icns')],check=True,stdout=subprocess.DEVNULL)
    plist={'CFBundleName':name,'CFBundleDisplayName':name,'CFBundleIdentifier':'cc.trackpad.mac.'+('pair' if pair else 'launch'),'CFBundleVersion':'0.4.17','CFBundleShortVersionString':'0.4.17','CFBundleExecutable':'Launch','CFBundleIconFile':'Trackpad.icns','CFBundlePackageType':'APPL','LSUIElement':True,'NSHighResolutionCapable':True}
    (app/'Contents/Info.plist').write_bytes(plistlib.dumps(plist))
    script='#!/bin/bash\nROOT="$(cd "$(dirname "$0")/../../.." && pwd)"\nif /usr/sbin/lsof -nP -iTCP:8765 -sTCP:LISTEN >/dev/null 2>&1; then\n    exec "$ROOT/tools/打开配对页.command"\nfi\nexec /usr/bin/open -a Terminal "$ROOT/tools/启动接收端.command"\n'
    (macos/'Launch').write_text(script);(macos/'Launch').chmod(0o755)
    import shutil;shutil.rmtree(iconset)
print('Local Mac launchers and icons created; not executed')
