#!/bin/bash
# 双击运行；不全局安装工具，不读取或打印配对凭据。
cd "$(dirname "$0")/.." || exit 1
if /usr/sbin/lsof -nP -iTCP:8765 -sTCP:LISTEN >/dev/null 2>&1; then
    echo '触摸板服务已在运行，正在打开配对设备。'
    ./tools/打开配对页.command
    exit 0
fi
(
    for attempt in {1..20}; do
        if /usr/sbin/lsof -nP -iTCP:8766 -sTCP:LISTEN >/dev/null 2>&1; then
            ./tools/打开配对页.command
            exit 0
        fi
        sleep 0.5
    done
) &
umask 077
trackpad_runtime_dir="$HOME/Library/Application Support/TabletTrackpad"
mkdir -p "$trackpad_runtime_dir" || exit 1
trackpad_runtime_log="$trackpad_runtime_dir/receiver.log"
chmod 700 "$trackpad_runtime_dir"
touch "$trackpad_runtime_log" || exit 1
chmod 600 "$trackpad_runtime_log"
echo "===== $(date '+%Y-%m-%d %H:%M:%S') 启动 =====" >> "$trackpad_runtime_log"
python3 -B trackpad.py 2>&1 | tee -a "$trackpad_runtime_log"
