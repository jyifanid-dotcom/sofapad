#!/usr/bin/env python3
"""Read-only public export audit: paths, local links, privacy markers and original release assets."""
from pathlib import Path
from urllib.parse import unquote,urlsplit
import ast,hashlib,json,re,zipfile
ROOT=Path(__file__).resolve().parents[1]
for p in ROOT.rglob('*'):
 if not p.is_file() or '.git' in p.parts:continue
 rel=p.relative_to(ROOT)
 assert not p.is_symlink(),rel
 assert not any(x in rel.parts for x in ['.local-signing','.workbuddy-ai','__pycache__','归档','dist']),rel
 assert p.suffix.lower() not in ['.keystore','.jks','.key','.pem','.log'],rel
 assert p.name not in ['接续任务.md','local-admin.json','devices.json','pairing-codes.json','TEST_STATUS.json','signature-check.txt','apk-info.txt','publication-checks.txt'],rel
 if p.suffix in ['.py','.md','.txt','.json','.js','.html','.yml','.gradle','.command']:
  text=p.read_text()
  assert ('/'+'Users/') not in text and ('/'+'tmp/codex-') not in text,rel
  assert not re.search(r'gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{30,}|-----BEGIN (?:RSA |EC )?PRIVATE KEY-----',text),rel
  if p.suffix=='.py':ast.parse(text)
 if p.suffix=='.md':
  for target in re.findall(r'\]\(([^)]+)\)',p.read_text()):
   target=target.strip('<>');url=urlsplit(target)
   if url.scheme or target.startswith('#'):continue
   local=(p.parent/unquote(url.path)).resolve()
   assert local.is_relative_to(ROOT) and local.exists(),(rel,target)
info=json.loads((ROOT/'android-apk/PAGE_SOURCE.json').read_text())
assert hashlib.sha256((ROOT/'trackpad.py').read_bytes()).hexdigest()==info['source_sha256']
assert hashlib.sha256((ROOT/'android-apk/app/src/main/assets/index.html').read_bytes()).hexdigest()==info['page_sha256']
apk=ROOT/'releases/0.4.17/SofaPad-0.4.17-test.apk'
assert hashlib.sha256(apk.read_bytes()).hexdigest()=='9d2041fcede96928b9d546bf705a0a8142920d9d88578e89e2732e7811cf3493'
with zipfile.ZipFile(apk) as z:
 for p in (ROOT/'android-apk/app/src/main/assets').rglob('*'):
  if p.is_file():assert z.read('assets/'+str(p.relative_to(ROOT/'android-apk/app/src/main/assets')))==p.read_bytes()
print('Public export audit passed: local links, source/page/APK identity, no private paths, key files, live credentials or runtime logs.')
