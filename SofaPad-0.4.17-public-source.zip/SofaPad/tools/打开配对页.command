#!/bin/bash
# Local-only admin capability is read directly into the browser, never printed to logs.
cd "$(dirname "$0")/.." || exit 1
python3 -B - <<'PY'
import json,subprocess
from pathlib import Path
file=Path.home()/'Library/Application Support/TabletTrackpad/local-admin.json'
if not file.exists():
    print('请先双击“触摸板”启动接收程序，再打开配对设备。')
else:
    value=json.loads(file.read_text())
    subprocess.run(['/usr/bin/open',value['url']],check=True)
PY
