"""Plaintext LAN, camera QR enrollment and revocable device sessions. No cloud service.
Private runtime material lives outside the synced project. Never logs credentials.
"""
import base64
import hashlib
import html
import http.server
import ipaddress
import json
import os
from pathlib import Path
import re
import secrets
import socket
import subprocess
import threading
import time
from urllib.parse import urlsplit, parse_qs
from http.cookies import SimpleCookie

STATE_DIR = Path.home() / 'Library/Application Support/TabletTrackpad'
COOKIE = 'trackpad-device'
MAX_BODY = 8192

def encoded(data):
    return base64.urlsafe_b64encode(json.dumps(data, separators=(',', ':')).encode()).decode().rstrip('=')

def digest(value):
    return hashlib.sha256(value.encode()).hexdigest()

def atomic_json(path, value):
    temp = path.with_suffix('.tmp')
    fd = os.open(str(temp), os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, 'w') as f:
        json.dump(value, f, ensure_ascii=False)
        f.flush()
        os.fsync(f.fileno())
    os.replace(str(temp), str(path))
    path.chmod(0o600)

def qr_svg(value):
    from vendor.qrcodegen import QrCode
    qr = QrCode.encode_text(value, QrCode.Ecc.MEDIUM)
    size = qr.get_size()
    parts = ['M%d,%dh1v1h-1z' % (x+4, y+4) for y in range(size) for x in range(size) if qr.get_module(x,y)]
    return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 %d %d" role="img" aria-label="配对二维码"><rect width="100%%" height="100%%" fill="white"/><path d="%s" fill="black"/></svg>' % (size+8, size+8, ''.join(parts))

class SecureReceiver:
    def __init__(self, directory=STATE_DIR, names=None, port=8765, bootstrap_port=8766):
        self.directory = Path(directory)
        self.directory.mkdir(mode=0o700, parents=True, exist_ok=True)
        self.directory.chmod(0o700)
        self.port, self.bootstrap_port = port, bootstrap_port
        self.lock = threading.RLock()
        self.active = None
        self.active_client = None
        self.input_lock = threading.RLock()
        self.power = None
        self.input_check = lambda: None
        self.input_frames = 0
        self.admin = secrets.token_urlsafe(32)
        # Keep the local-only capability valid when the receiver restarts.
        try:
            saved=urlsplit(json.loads((self.directory/'local-admin.json').read_text())['url'])
            if saved.hostname=='127.0.0.1' and saved.path=='/admin' and re.fullmatch(r'[A-Za-z0-9_-]{40,64}',saved.fragment):self.admin=saved.fragment
        except (OSError,ValueError,KeyError,TypeError):pass
        self.pending = {}
        self.code_registry=self.directory/'pair-codes.json'
        self.codes = {}
        try:
            saved_codes=json.loads(self.code_registry.read_text());now=time.time()
            if isinstance(saved_codes,dict):
                self.codes={key:expiry for key,expiry in saved_codes.items() if re.fullmatch(r'[a-f0-9]{64}',key) and isinstance(expiry,(int,float)) and now<expiry<=now+300}
        except (OSError,ValueError,TypeError):pass
        self.rate = {}
        self._discover_addresses = names is None
        self.names = names or self.discover_names()
        self.names = list(dict.fromkeys(n.lower() for n in ['127.0.0.1'] + self.names if self.private_ip(n) or n=='127.0.0.1'))
        self.registry = self.directory / 'devices.json'
        if self.registry.exists():
            self.devices = json.loads(self.registry.read_text())
            if not isinstance(self.devices, dict):
                raise ValueError('Invalid device registry; refusing to reset trust')
        else:
            self.devices = {}
        identity_path=self.directory/'receiver-id.json'
        if identity_path.exists():
            self.identity=json.loads(identity_path.read_text())['id']
            if not re.fullmatch(r'[a-f0-9]{32}',self.identity):raise ValueError('Invalid receiver identity')
        else:
            self.identity=secrets.token_hex(16);atomic_json(identity_path,{'id':self.identity})
        self.preferred = next((n for n in self.names if self.private_ip(n)), '127.0.0.1')
        self.origin = 'http://%s:%d' % (self.preferred, self.port)
        atomic_json(self.directory/'local-admin.json', {'url':'http://127.0.0.1:%d/admin#%s' % (bootstrap_port,self.admin)})

    @staticmethod
    def private_ip(value):
        try:
            address=ipaddress.ip_address(value)
            return address.version==4 and any(address in ipaddress.ip_network(net) for net in ('10.0.0.0/8','172.16.0.0/12','192.168.0.0/16'))
        except ValueError:return False

    @staticmethod
    def discover_names():
        primary=[];secondary=[];interface=''
        try:
            output=subprocess.check_output(['/sbin/ifconfig'],timeout=3).decode()
            for line in output.splitlines():
                match=re.match(r'^([a-zA-Z0-9]+):',line)
                if match:interface=match.group(1)
                match=re.search(r'\binet (\d+\.\d+\.\d+\.\d+)',line)
                if match and SecureReceiver.private_ip(match.group(1)):
                    (primary if interface.startswith('en') else secondary).append(match.group(1))
        except (OSError,subprocess.SubprocessError):pass
        return list(dict.fromkeys(primary+secondary))

    def refresh_addresses(self):
        if not self._discover_addresses:return
        current=self.discover_names()
        if current:
            self.names=['127.0.0.1']+current
            self.preferred=current[0];self.origin='http://%s:%d'%(self.preferred,self.port)

    def input_status(self):
        try:
            ready=self.input_check()
        except Exception:
            ready=False
        return {'machine':socket.gethostname(),'inputReady':ready,'inputFrames':self.input_frames,'receiverVersion':'0.4.17','sleepProtected':bool(self.power and self.power.active)}

    def capsule(self, host=None):
        with self.lock:
            now=time.time()
            self.codes={key:expiry for key,expiry in self.codes.items() if expiry>now}
            code=secrets.token_urlsafe(24)
            self.codes[digest(code)] = now+300
            # At most four displayed enrollment codes; refreshing invalidates older ones.
            while len(self.codes)>4:self.codes.pop(next(iter(self.codes)))
            atomic_json(self.code_registry,self.codes)
        origin='http://%s:%d' % (host or self.preferred,self.port)
        # IP-only endpoints. Receiver ID prevents accidental reconnection to a reused IP;
        # it is not cryptographic authentication on this plaintext transport.
        alternatives=[]
        for name in self.names:
            try:address=ipaddress.ip_address(name)
            except ValueError:continue
            private=any(address in ipaddress.ip_network(net) for net in ('10.0.0.0/8','172.16.0.0/12','192.168.0.0/16'))
            if private:
                candidate='http://%s:%d'%(name,self.port)
                if candidate!=origin:alternatives.append(candidate)
        return encoded({'origin':origin,'origins':alternatives[:3],'receiver':self.identity,'code':code})

    def issue(self, code, label, address):
        with self.lock:
            now=time.time()
            attempts=[t for t in self.rate.get(address,[]) if t>now-60]
            if len(attempts)>=10:raise PermissionError('配对尝试过多，请稍后重试')
            attempts.append(now);self.rate[address]=attempts
            if len(self.rate)>1024:self.rate={address:attempts}
            key=digest(code)
            expiry=self.codes.pop(key,0)
            atomic_json(self.code_registry,self.codes)
            if expiry<=now:raise PermissionError('二维码已失效或已使用，请在Mac刷新二维码')
            self.devices={i:r for i,r in self.devices.items() if r['expires']>now}
            if len(self.devices)>=100:raise PermissionError('设备已达上限，请先在Mac撤销旧设备')
            token=secrets.token_urlsafe(32);identifier=secrets.token_hex(8)
            # A bounded name is data, and is rendered with textContent in the local UI.
            self.devices[identifier]={'hash':digest(token),'name':str(label)[:64],'created':now,'expires':now+360*86400}
            atomic_json(self.registry,self.devices)
            return identifier,token

    def request_home(self, label, address, ticket=None):
        with self.lock:
            now=time.time()
            self.pending={k:v for k,v in self.pending.items() if v['expires']>now}
            if ticket is not None:
                if not isinstance(ticket,str) or not re.fullmatch(r'[A-Za-z0-9_-]{40,64}',ticket):raise PermissionError('原申请无效，请重新申请')
                previous=self.pending.get(digest(ticket))
                if not previous:raise PermissionError('原申请已过期，请重新申请')
                return {'ticket':ticket,'number':previous['number'],'expiresIn':max(1,int(previous['expires']-now))}
            attempts=[t for t in self.rate.get(address,[]) if t>now-60]
            if len(attempts)>=10 or len(self.pending)>=32:
                raise PermissionError('请求过多，请稍后重试')
            self.rate[address]=attempts+[now]
            if len(self.rate)>1024:self.rate={address:self.rate[address]}
            secret=secrets.token_urlsafe(32);key=digest(secret)
            number=str(secrets.randbelow(1000000)).zfill(6)
            while any(v['number']==number for v in self.pending.values()):
                number=str(secrets.randbelow(1000000)).zfill(6)
            self.pending[key]={'name':str(label)[:64],'number':number,'expires':now+300,'approved':False}
            return {'ticket':secret,'number':number,'expiresIn':300}

    def pending_devices(self):
        with self.lock:
            return [{'id':k,'name':v['name'],'number':v['number']} for k,v in self.pending.items() if v['expires']>time.time() and not v['approved']]

    def approve_home(self, key):
        with self.lock:
            request=self.pending.get(key)
            if not request or request['expires']<=time.time():raise ValueError('请求已过期')
            request['approved']=True

    def claim_home(self, ticket, address):
        if not isinstance(ticket,str) or not re.fullmatch(r'[A-Za-z0-9_-]{40,64}',ticket):
            raise PermissionError('连接请求无效，请重新申请')
        with self.lock:
            key=digest(ticket);request=self.pending.get(key)
            if not request or request['expires']<=time.time():raise PermissionError('请求已过期，请重新申请')
            if not request['approved']:return None
            # Reuse the same persisted, revocable credentials and one-use issuer.
            code=secrets.token_urlsafe(24);self.codes[digest(code)]=time.time()+10
            try:result=self.issue(code,request['name'],address)
            finally:self.codes.pop(digest(code),None)
            del self.pending[key]
            return result

    @staticmethod
    def legacy_cookie_compat(headers):
        ua=headers.get('user-agent','')
        return 'AppleWebKit/' in ua and bool(re.search(r'\b(?:CPU(?: iPhone)? OS|iPhone OS) 12[_.]\d',ua))

    @staticmethod
    def cookie_token(headers):
        try:
            cookie=SimpleCookie();cookie.load(headers.get('cookie',''))
            value=cookie.get(COOKIE)
            return value.value if value else None
        except Exception:return None

    @classmethod
    def session_cookie(cls, token, headers):
        # WebKit bug 228261: iOS 12 can omit SameSite cookies on local-domain fetch.
        value=COOKIE+'='+token+'; Path=/; HttpOnly'
        if not cls.legacy_cookie_compat(headers):value+='; SameSite=Strict'
        return value+'; Max-Age=31104000'

    def page_cookie_headers(self, headers):
        if self.legacy_cookie_compat(headers) and self.authenticated(headers):
            return {'Set-Cookie':self.session_cookie(self.cookie_token(headers),headers)}
        return {}

    @staticmethod
    def content_policy(websocket_source=''):
        return ("default-src 'self'; script-src 'self' 'unsafe-inline'; "
                "style-src 'self' 'unsafe-inline'; connect-src 'self'"+websocket_source+
                "; img-src 'self' data:; frame-ancestors 'none'; base-uri 'none'; object-src 'none'")

    def page_headers(self, headers):
        extra=self.page_cookie_headers(headers)
        host=headers.get('host','')
        # Older Safari does not reliably include WebSockets in CSP 'self' (WebKit bug 201591).
        # Only the validated request authority is allowed, never all WebSocket endpoints.
        if self.allowed_host(host) and re.fullmatch(r'(?:[A-Za-z0-9._-]+|\[[0-9A-Fa-f:]+\]):[0-9]+',host):
            extra['Content-Security-Policy']=self.content_policy(' ws://'+host)
        return extra

    def authenticated(self, headers):
        try:
            cookie=SimpleCookie();cookie.load(headers.get('cookie',''))
            value=cookie.get(COOKIE)
            if not value:return None
            candidate=digest(value.value)
        except Exception:return None
        with self.lock:
            for identifier,record in self.devices.items():
                if record['expires']>time.time() and secrets.compare_digest(record['hash'],candidate):return identifier
        return None

    def claim(self, identifier, conn, client=None):
        client=client if isinstance(client,str) and re.fullmatch(r'[a-f0-9]{32}',client) else None
        # A reconnecting instance may replace its own obsolete channel. A different
        # tab/device (or legacy client without an instance ID) cannot steal control.
        with self.input_lock, self.lock:
            if identifier not in self.devices:return False
            previous=self.active
            if previous is not None:
                if previous[0]!=identifier or not client or client!=self.active_client:return False
                try:previous[1].shutdown(socket.SHUT_RDWR)
                except OSError:pass
                try:previous[1].close()
                except OSError:pass
            self.devices[identifier]['lastSeen']=time.time()
            atomic_json(self.registry,self.devices)
            self.active=(identifier,conn);self.active_client=client
            if self.power and previous is None:self.power.acquire()
            return True

    def is_current(self, conn):
        with self.lock:return self.active is not None and self.active[1] is conn

    def release(self, conn):
        with self.input_lock, self.lock:
            if self.active is not None and self.active[1] is conn:
                self.active=None;self.active_client=None
                if self.power:self.power.release()

    def revoke(self, identifier):
        with self.lock:
            if identifier not in self.devices:return
            del self.devices[identifier];atomic_json(self.registry,self.devices)
            if self.active and self.active[0]==identifier:
                conn=self.active[1]
                try:conn.shutdown(socket.SHUT_RDWR)
                except OSError:pass
                try:conn.close()
                except OSError:pass
                # The receiver's finally block releases held controls before relinquishing lease.

    def allowed_host(self, host):
        try:
            value=urlsplit('http://'+host)
            return value.hostname in self.names and value.port==self.port and value.username is None
        except ValueError:return False

    def origin_ok(self, headers):
        return headers.get('origin')=='http://'+headers.get('host','') and self.allowed_host(headers.get('host',''))

    @staticmethod
    def response(conn,status,body=b'',content_type='text/html; charset=utf-8',extra=None):
        if isinstance(body,str):body=body.encode()
        reason={200:'OK',303:'See Other',400:'Bad Request',401:'Unauthorized',403:'Forbidden',404:'Not Found',409:'Conflict',413:'Too Large',429:'Too Many Requests'}.get(status,'Error')
        head={'Content-Type':content_type,'Content-Length':str(len(body)),'Cache-Control':'no-store','Connection':'close','Referrer-Policy':'no-referrer','X-Content-Type-Options':'nosniff','X-Frame-Options':'DENY','Content-Security-Policy':SecureReceiver.content_policy()}
        head.update(extra or {})
        conn.sendall(('HTTP/1.1 %d %s\r\n'%(status,reason)+''.join(k+': '+v+'\r\n' for k,v in head.items())+'\r\n').encode()+body)

    def route(self, conn, method, path, headers, body, address):
        """Return True when handled; only authorized /, /app-ui.js, /ws reach caller."""
        if not self.allowed_host(headers.get('host','')):
            self.response(conn,403,'Host不匹配');return True
        if path=='/api/identity' and method=='GET':
            self.response(conn,200,json.dumps({'name':socket.gethostname()}),'application/json',extra={'X-Trackpad-Receiver':self.identity});return True
        if path=='/session/continue' and method=='GET':
            if self.authenticated(headers):
                self.response(conn,303,b'',extra={'Location':'/','Set-Cookie':self.session_cookie(self.cookie_token(headers),headers)})
            else:self.response(conn,401,session_recovery_page(bool(self.cookie_token(headers))))
            return True
        if path=='/manifest.webmanifest' and method=='GET':
            self.response(conn,200,json.dumps({'id':'/','name':'触摸板','short_name':'触摸板','start_url':'/','scope':'/','display':'standalone','background_color':'#090b0e','theme_color':'#090b0e'}),'application/manifest+json');return True
        if path in ('/api/home/request','/api/home/claim') and method=='POST':
            if not self.origin_ok(headers) or headers.get('content-type','').split(';')[0]!='application/json':
                self.response(conn,403,'来源不匹配');return True
            try:
                data=json.loads(body)
                if not isinstance(data,dict):raise ValueError()
                if self.authenticated(headers):
                    self.response(conn,200,'{"ok":true,"paired":true}','application/json');return True
                if path.endswith('/request'):
                    result=self.request_home(data.get('name','主屏幕触摸板'),address,data.get('ticket'))
                    self.response(conn,200,json.dumps(result),'application/json')
                else:
                    result=self.claim_home(data.get('ticket'),address)
                    if result is None:self.response(conn,200,'{"pending":true}','application/json')
                    else:self.response(conn,200,'{"ok":true}','application/json',{'Set-Cookie':self.session_cookie(result[1],headers)})
            except (ValueError,TypeError,AttributeError):self.response(conn,400,'无效请求')
            except PermissionError as e:self.response(conn,403,str(e))
            return True
        if path=='/pair' and method=='GET':
            if self.authenticated(headers):
                self.response(conn,303,b'',extra={'Location':'/','Set-Cookie':self.session_cookie(self.cookie_token(headers),headers)});return True
            self.response(conn,200,pair_page());return True
        if path=='/api/pair' and method=='POST':
            if not self.origin_ok(headers) or headers.get('content-type','').split(';')[0]!='application/json':
                self.response(conn,403,'来源不匹配');return True
            try:
                data=json.loads(body);identifier,token=self.issue(data.get('code',''),data.get('name','手机/平板'),address)
            except (ValueError,AttributeError,TypeError):self.response(conn,400,'无效配对请求');return True
            except PermissionError as e:self.response(conn,403,str(e));return True
            self.response(conn,200,'{"ok":true}', 'application/json',{'Set-Cookie':self.session_cookie(token,headers)})
            return True
        identity=self.authenticated(headers)
        if path=='/api/session' and method=='GET':
            if identity:
                with self.lock:
                    active=self.active
                    state={'ok':True,'name':self.devices[identity]['name'],'busy':active is not None,'controllerName':self.devices.get(active[0],{}).get('name','其他设备') if active else '', 'ownsControl':bool(active and active[0]==identity),'inputStatus':self.input_status()}
                self.response(conn,200,json.dumps(state),'application/json')
            else:self.response(conn,401,'{"ok":false}','application/json')
            return True
        if method!='GET' or path not in ('/','/app-ui.js','/ws'):
            self.response(conn,404,'未找到');return True
        if not identity:
            self.response(conn,401,home_pair_page());return True
        if path=='/ws' and not self.origin_ok(headers):
            self.response(conn,403,'来源不匹配');return True
        return False

    def bootstrap(self, bind='0.0.0.0'):
        owner=self
        class Handler(http.server.BaseHTTPRequestHandler):
            def log_message(self,*args):pass
            def send(self,status,body,kind='text/html; charset=utf-8'):
                if isinstance(body,str):body=body.encode()
                self.send_response(status);self.send_header('Content-Type',kind);self.send_header('Content-Length',str(len(body)))
                self.send_header('Cache-Control','no-store');self.send_header('Referrer-Policy','no-referrer');self.send_header('X-Content-Type-Options','nosniff');self.send_header('X-Frame-Options','DENY');self.end_headers();self.wfile.write(body)
            def is_admin(self):
                return self.client_address[0] in ('127.0.0.1','::1') and secrets.compare_digest(self.headers.get('X-Trackpad-Admin',''),owner.admin)
            def do_GET(self):
                if self.path=='/':return self.send(200,document('连接触摸板','<h1>连接触摸板</h1><p>在Mac双击触摸板图标，显示二维码；平板在APK点扫码连接即可。新版使用IP局域网直连，不需要安装证书。</p>'))
                if self.path=='/admin' and self.client_address[0] in ('127.0.0.1','::1'):
                    return self.send(200,admin_page())
                if self.path=='/api/admin/devices' and self.is_admin():
                    with owner.lock:
                        data={'pending':owner.pending_devices(),'inputStatus':owner.input_status(),'devices':[{'id':i,'name':v['name'],'active':bool(owner.active and owner.active[0]==i)} for i,v in owner.devices.items()]}
                    return self.send(200,json.dumps(data),'application/json')
                if self.path.split('?',1)[0]=='/api/admin' and self.is_admin():
                    with owner.lock:
                        owner.refresh_addresses()
                        requested=parse_qs(urlsplit(self.path).query).get('host',[owner.preferred])[0]
                        if requested not in owner.names:requested=owner.preferred
                        cap=owner.capsule(requested)
                        data={'qr':qr_svg('http://%s:%d/pair#%s'%(requested,owner.port,cap)),'origin':'http://%s:%d'%(requested,owner.port),'hosts':([h for h in owner.names if h not in ('localhost','127.0.0.1')] or owner.names),'selectedHost':requested,'pending':owner.pending_devices(),'inputStatus':owner.input_status(),'expiresSeconds':300,'devices':[{'id':i,'name':v['name'],'active':bool(owner.active and owner.active[0]==i)} for i,v in owner.devices.items()]}
                    return self.send(200,json.dumps(data),'application/json')
                self.send(403,'不可访问')
            def do_POST(self):
                if self.path not in ('/api/admin/revoke','/api/admin/approve') or not self.is_admin():return self.send(403,'不可访问')
                try:
                    length=int(self.headers.get('Content-Length','0'))
                    if length<0 or length>MAX_BODY:return self.send(413,'请求过大')
                    value=json.loads(self.rfile.read(length))
                    if self.path=='/api/admin/approve':owner.approve_home(value['id'])
                    else:owner.revoke(value['id'])
                    self.send(200,'{"ok":true}','application/json')
                except (ValueError,KeyError,TypeError):self.send(400,'无效请求')
        server=http.server.ThreadingHTTPServer((bind,self.bootstrap_port),Handler)
        threading.Thread(target=server.serve_forever,daemon=True,name='trackpad-enrollment').start()
        return server


def document(title,body,script=''):
    return '<!doctype html><html lang="zh"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"><meta name="referrer" content="no-referrer"><meta name="apple-mobile-web-app-capable" content="yes"><meta name="apple-mobile-web-app-title" content="触摸板"><link rel="manifest" href="/manifest.webmanifest"><title>'+title+'</title><style>body{margin:0;background:#090b0e;color:#e1e5eb;font:16px -apple-system,system-ui,sans-serif;padding:32px 22px}main{max-width:780px;margin:auto}h1{font-size:26px;font-weight:550}p{line-height:1.8;color:#aab2be}button,a.button{border:1px solid #384251;border-radius:12px;background:#1b2531;color:#dce9f8;padding:12px 18px;display:inline-block;text-decoration:none;margin:6px 8px 6px 0;font:inherit}a{color:#9ac4f5}select{color:#dce9f8;background:#1b2531;border:1px solid #384251;border-radius:8px;padding:8px 12px;font:inherit}code{word-break:break-all;font-size:12px}#qr{width:min(320px,90%);background:white;padding:12px;border-radius:18px;margin:20px 0}#qr svg{display:block;width:100%}.device{border-top:1px solid #252c35;padding:14px 0;display:flex;align-items:center;justify-content:space-between}#status{white-space:pre-wrap}</style><main>'+body+'</main><script>'+script+'</script></html>'

CAPSULE_JS="""function capsule(){var raw=location.hash.slice(1);if(!/^[A-Za-z0-9_-]{20,2048}$/.test(raw))throw Error('二维码无效，请重新扫描');var c=JSON.parse(atob(raw.replace(/-/g,'+').replace(/_/g,'/')));var u=new URL(c.origin);if(u.protocol!=='http:'||u.username||u.password||u.pathname!=='/'&&u.pathname!==''||u.search||u.hash||!/^([a-f0-9]{32})$/.test(c.receiver)||!/^([A-Za-z0-9_-]{20,80})$/.test(c.code))throw Error('二维码格式无效');return {value:c,raw:raw};}"""

def session_recovery_page(cookie_seen):
    detail='设备记录已回传，但已过期、被撤销或不属于当前Mac。' if cookie_seen else '浏览器整页请求也没有回传设备记录；尚不能复用之前的授权。'
    return document('恢复连接','<h1>连接记录未被识别</h1><p>'+detail+'</p><p>请保持使用当前Mac的IP地址。此页不会自动生成新的授权申请。</p><a class="button" href="/session/continue">重新检测连接</a><button id="newPair">重新申请授权</button>',"document.getElementById('newPair').onclick=function(){try{sessionStorage.removeItem('trackpad-home-request');}catch(e){}location.replace('/');};")


def home_pair_page():
    return document('连接触摸板','<h1>连接这台 Mac</h1><p>首次在Mac确认一次，此后会记住。已有设备控制时可以先配对，再等待切换，无需反复授权。</p><button id="request">连接这台 Mac</button><button id="openPad" style="display:none">进入触摸板</button><button id="retryPair" style="display:none">重新申请授权</button><p id="status" role="status"></p><p>请在Mac双击“触摸板”图标确认相同编号；申请5分钟有效。Safari、主屏幕或其他浏览器可能使用各自的连接记录。</p><details><summary>已有配对链接？</summary><p>也可粘贴相机二维码中的完整链接，在当前窗口完成配对。</p><input id="link" type="url" autocomplete="off" placeholder="粘贴Mac配对链接" style="box-sizing:border-box;width:100%;font-size:16px;padding:12px"><button id="useLink">使用配对链接</button></details>',r'''(function(){
var legacySafari=/AppleWebKit\//.test(navigator.userAgent||'')&&/\b(?:CPU(?: iPhone)? OS|iPhone OS) 12[_.]\d/.test(navigator.userAgent||'');
var busy=false,pending=null,cookieFailure=false,requestKey='trackpad-home-request';
var button=document.getElementById('request'),status=document.getElementById('status'),openButton=document.getElementById('openPad'),againButton=document.getElementById('retryPair');
function saveRequest(){try{sessionStorage.setItem(requestKey,JSON.stringify({pending:pending,cookieFailure:cookieFailure}));}catch(e){}}
try{var saved=JSON.parse(sessionStorage.getItem(requestKey)||'null');if(saved){pending=saved.pending;cookieFailure=saved.cookieFailure===true;if(pending&&(!/^[A-Za-z0-9_-]{40,64}$/.test(pending.ticket)||pending.expires<=Date.now()))pending=null;}}catch(e){}
async function api(path,value){
 var controller=typeof AbortController==='function'?new AbortController():null,timer=0;
 try{return await Promise.race([
  fetch(path,{method:value===undefined?'GET':'POST',headers:{'Content-Type':'application/json'},credentials:'same-origin',cache:'no-store',signal:controller?controller.signal:undefined,body:value===undefined?undefined:JSON.stringify(value)}).then(async function(r){if(r.status===401&&value===undefined)return null;if(!r.ok)throw Error(await r.text());return r.json();}),
  new Promise(function(resolve,reject){timer=setTimeout(function(){if(controller)controller.abort();reject(Error('连接暂时没有回应；已有申请会保留，请点“继续连接”重试'));},8000);})
 ]);}finally{clearTimeout(timer);}
}
function deviceName(){var ua=navigator.userAgent||'';return /iPad/.test(ua)||/Macintosh/.test(ua)&&navigator.maxTouchPoints>1?'iPad 主屏幕':/iPhone/.test(ua)?'iPhone 主屏幕':'网页触摸板';}
async function paired(session){
 if(!session||!session.ok){cookieFailure=true;saveRequest();button.textContent='重新检测连接';againButton.style.display='inline-block';throw Error('Mac 已授权，但浏览器未保存连接记录，请用 Safari 直接打开并允许保存网站数据，再重新检测');}
 pending=null;cookieFailure=false;saveRequest();button.style.display='none';againButton.style.display='none';openButton.style.display='inline-block';
 while(session&&session.busy){
  status.textContent='已配对并记住。'+(session.controllerName||'其他窗口或设备')+'正在控制 Mac；关闭那边的触摸板后，这里会自动连接。无需再次授权。';
  await new Promise(function(resolve){setTimeout(resolve,2000);});session=await api('/api/session');
 }
 if(!session)throw Error('连接记录未被识别，请重新检测；不会自动发送新授权申请');
 status.textContent='已记住，正在进入触摸板…';location.replace('/');
}
async function connectHome(){
 if(busy)return;busy=true;button.disabled=true;
 try{
  var current=await api('/api/session');
  if(current&&current.ok){await paired(current);return;}
  if(cookieFailure&&legacySafari){location.replace('/session/continue');return;}
  if(cookieFailure){status.textContent='Mac 已授权，但此浏览器没有保存连接记录。请用 Safari 直接打开同一地址，并允许保存网站数据，再点“重新检测连接”。尚未发送新的授权申请。';return;}
  var data=await api('/api/home/request',{name:deviceName(),ticket:pending?pending.ticket:undefined});
  if(data.paired){await paired(await api('/api/session'));return;}
  pending={ticket:data.ticket,number:data.number,expires:Date.now()+Math.min(300,data.expiresIn||300)*1000};saveRequest();
  status.textContent='请在 Mac 确认编号：'+pending.number;button.textContent='继续连接';
  while(Date.now()<pending.expires){
   await new Promise(function(resolve){setTimeout(resolve,2000);});
   var result=await api('/api/home/claim',{ticket:pending.ticket});
   if(result.ok){
    status.textContent='Mac 已授权，正在确认连接记录…';
    var verified=await api('/api/session');
    if(!verified||!verified.ok){if(legacySafari){location.replace('/session/continue');return;}cookieFailure=true;saveRequest();button.textContent='重新检测连接';againButton.style.display='inline-block';throw Error('Mac 已授权，但浏览器没有保存连接记录。请用 Safari 直接打开同一地址并允许保存网站数据，再重新检测；不会自动重复申请授权。');}
    await paired(verified);return;
   }
  }
  pending=null;saveRequest();throw Error('申请已过期，请重新连接');
 }catch(e){status.textContent=e.message;if(/过期|失效|原申请无效/.test(e.message)){pending=null;saveRequest();}if(!cookieFailure)button.textContent='继续连接';button.style.display='inline-block';}
 finally{busy=false;button.disabled=false;}
}
button.onclick=connectHome;
openButton.onclick=function(){location.replace('/');};
againButton.onclick=function(){pending=null;cookieFailure=false;saveRequest();againButton.style.display='none';button.textContent='连接这台 Mac';connectHome();};
document.getElementById('useLink').onclick=function(){try{var u=new URL(document.getElementById('link').value.trim());if(u.origin!==location.origin||u.pathname!=='/pair'||!u.hash)throw Error('请使用这台Mac、相同IP的HTTP配对链接');location.replace(u.pathname+u.hash);}catch(e){status.textContent=e.message;}};
// Restore an existing request/session, never silently create a new authorization request.
(async function(){try{var existing=await api('/api/session');if(existing&&existing.ok){if(busy)return;busy=true;await paired(existing);busy=false;}else if(pending||cookieFailure)connectHome();}catch(e){status.textContent=e.message;busy=false;}})();

})();
''')


def pair_page():
    return document('安全配对','<h1>安全配对</h1><p id="status">正在验证并记住这台设备…</p>',CAPSULE_JS+"""(async function(){try{var c=capsule();if(c.value.origin!==location.origin)throw Error('Mac地址不匹配，请重新扫码');history.replaceState(null,'',location.pathname);var current=await fetch('/api/session',{credentials:'same-origin'});if(!current.ok){var response=await fetch('/api/pair',{method:'POST',headers:{'Content-Type':'application/json'},credentials:'same-origin',body:JSON.stringify({code:c.value.code,name:(/iPhone/.test(navigator.userAgent)?'iPhone':/iPad/.test(navigator.userAgent)?'iPad':'手机/平板')})});if(!response.ok)throw Error(await response.text());}var verified=await fetch('/api/session',{credentials:'same-origin',cache:'no-store'});if(!verified.ok&&/AppleWebKit\//.test(navigator.userAgent||'')&&/\b(?:CPU(?: iPhone)? OS|iPhone OS) 12[_.]\d/.test(navigator.userAgent||'')){location.replace('/session/continue');return;}if(!verified.ok)throw Error('Mac 已接受配对，但浏览器没有保存连接记录；请用 Safari 直接打开同一地址，并允许保存网站数据后重新扫码。');document.getElementById('status').textContent='配对成功，正在打开触摸板…';location.replace('/');}catch(e){document.getElementById('status').textContent=e.message;}})();""")

def admin_page():
    return document('触摸板设备配对','<h1>扫码连接Mac</h1><p>APK：点“扫码连接Mac”，对准下面二维码即可。手机网页：直接用相机扫码。以后打开自动连接。</p><div id="qr"></div><p id="status">正在读取二维码…</p><button id="refresh">刷新二维码</button><details><summary>其他IP与连接诊断</summary><label>局域网IP <select id="host"></select></label><p id="inputStatus"></p></details><h2>连接申请</h2><p>仅确认你自己设备上显示的编号。</p><div id="pending"></div><h2>已记住的设备</h2><div id="devices"></div><p>同一时间仅一台设备控制。新版为局域网明文传输，无需安装证书。</p>',"""function renderPending(items){var list=document.getElementById('pending');list.textContent=items.length?'':'暂无申请';items.forEach(function(v){var row=document.createElement('div');row.className='device';var label=document.createElement('span');label.textContent=v.name+' · 核对编号 '+v.number;var b=document.createElement('button');b.textContent='允许连接';b.onclick=async function(){b.disabled=true;try{var r=await fetch('/api/admin/approve',{method:'POST',headers:{'Content-Type':'application/json','X-Trackpad-Admin':token},body:JSON.stringify({id:v.id})});if(!r.ok)throw Error(await r.text());await refresh();}catch(e){b.disabled=false;document.getElementById('status').textContent=e.message;}};row.appendChild(label);row.appendChild(b);list.appendChild(row);});}function renderInput(s){if(!s)return;document.getElementById('inputStatus').textContent=s.machine+'：'+(s.inputReady===false?'辅助功能未授权；请到系统设置 → 隐私与安全性 → 辅助功能，允许运行接收端的终端或应用，再重新启动接收端':s.inputReady===true?'辅助功能已授权':'控制权限需在Mac确认')+'；接收端 '+(s.receiverVersion||'旧版')+'；空闲休眠保护 '+(s.sleepProtected?'已启用':'未启用')+'；收到触摸帧 '+s.inputFrames;}function renderDevices(devices){var list=document.getElementById('devices');list.textContent='';devices.forEach(function(v){var row=document.createElement('div');row.className='device';var label=document.createElement('span');label.textContent=v.name+(v.active?' · 正在控制':' · 已记住');var b=document.createElement('button');b.textContent='撤销权限';b.onclick=async function(){await fetch('/api/admin/revoke',{method:'POST',headers:{'Content-Type':'application/json','X-Trackpad-Admin':token},body:JSON.stringify({id:v.id})});await refresh();};row.appendChild(label);row.appendChild(b);list.appendChild(row);});}var chosenHost='',token=location.hash.slice(1),adminKey='trackpad-admin-capability';try{if(token)sessionStorage.setItem(adminKey,token);else token=sessionStorage.getItem(adminKey)||'';}catch(e){}history.replaceState(null,'',location.pathname);async function refresh(){document.getElementById('status').textContent='正在获取新的配对二维码…';['qr'].forEach(function(id){document.getElementById(id).innerHTML='';});try{var r=await fetch('/api/admin'+(chosenHost?'?host='+encodeURIComponent(chosenHost):''),{headers:{'X-Trackpad-Admin':token}});if(!r.ok)throw Error('当前配对页未获授权，请关闭此页，在Mac双击“触摸板”图标重新打开');var d=await r.json();var choices=document.getElementById('host');choices.textContent='';d.hosts.forEach(function(h){var o=document.createElement('option');o.value=h;o.textContent=h;o.selected=h===d.selectedHost;choices.appendChild(o);});chosenHost=d.selectedHost;choices.onchange=function(){chosenHost=choices.value;refresh();};document.getElementById('qr').innerHTML=d.qr;document.getElementById('status').textContent='扫码后记住设备，下次直接打开即可。二维码5分钟有效。';renderDevices(d.devices);renderPending(d.pending||[]);renderInput(d.inputStatus);}catch(e){document.getElementById('status').textContent=e.message;}}document.getElementById('refresh').onclick=refresh;refresh();setInterval(async function(){try{var r=await fetch('/api/admin/devices',{headers:{'X-Trackpad-Admin':token}});if(r.ok){var d=await r.json();renderDevices(d.devices);renderPending(d.pending||[]);renderInput(d.inputStatus);}}catch(e){}},2000);""")
