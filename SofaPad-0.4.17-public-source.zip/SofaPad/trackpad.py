#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
trackpad.py — 把平板/手机变成 Mac 触摸板（0.4.17：冰蓝薄荷配色与玻璃底光）

依赖：Python 3 标准库 + 系统自带 CoreGraphics。不需要 pip install 任何东西。

用法：
    python3 trackpad.py
    平板浏览器打开 http://<本机IP>:8765

首次运行需要在「系统设置 → 隐私与安全性 → 辅助功能」里勾选运行本脚本的终端 App，
然后重启终端。

边界说明（重要）：
    指针移动 / 单指点击 / 双指滚动 / 三指拖拽  —— 完全跟手
    三指、四指的系统手势                        —— 只能发快捷键，动画是瞬切，不跟手
    力度触控（Force Touch）                     —— 平板无压感层，做不到
    触觉反馈                                    —— 只能靠平板马达粗震，做不到 Taptic 级别
"""

import base64
import ctypes
import hashlib
import json
import math
import os
import socket
import struct
import subprocess
import sys
import threading
import time
from trackpad_security import SecureReceiver, MAX_BODY
from trackpad_power import IdleSleepGuard

# ----------------------------------------------------------------------------
# 可调参数
# ----------------------------------------------------------------------------

HOST = "0.0.0.0"
PORT = 8765
SECURITY = None

# 改完代码不用再手动关终端重开：进程每秒检查一次自身文件，
# 发现变化就原地 exec 重载。同一个进程、同一个父终端，辅助功能授权不会丢。
AUTO_RELOAD = True
SELF_PATH = os.path.abspath(__file__)
RELOAD_FLAG = os.path.join(os.path.dirname(SELF_PATH), ".reload")

# 可选的触摸板底图：把一张俯视、铺满画面的触摸板照片命名为 pad.png 放到本目录，
# 平板页面会自动用它当触摸板表面；没有这个文件就用内置的白色面板。
PAD_IMAGE = os.path.join(os.path.dirname(SELF_PATH), "pad.png")

SENS = 1.2           # 总灵敏度倍数
ACCEL_BASE = 0.85    # 慢速时的基础增益（调小更精细）
ACCEL_REF = 2200.0   # 加速度参考速度 px/s
ACCEL_MAX = 1.9      # 快速时的最大额外增益
DEADZONE = 2.7       # 死区（屏幕像素）。触摸板区域约占屏宽 0.8，手指抖动被放大
                     # 约 1.2~1.4 倍，所以比全屏时的 2.2 略高，手感阈值不变。
PEND_DECAY = 0.35    # 亚像素累积的每帧保留比例，用来压掉静止时的偏置漂移

SCROLL_GAIN = 2.4    # 滚动增益，觉得滚太快就调小
SCROLL_NATURAL = True  # 自然滚动。方向反了就改成 False

TAP_MAX_MS = 350     # 按下到抬起超过这个时间就不算点击
TAP_MAX_MOVE = 0.022  # 起点到终点的净位移超过这个值就不算点击

SWIPE_MIN = 0.06     # 手势最小归一化位移
SWIPE_3_H = 0.022    # 保留（三指拖拽已停用）
PINCH_MIN = 0.22     # 四指捏合阈值（相对值）。收拢到 78% 或张开到 122% 才算，
                     # 太松的话四指滑动时手指自然聚拢会误触启动台。

# 双指缩放：两指间距变化 → Cmd 加号 / 减号。
# 判定依据是「间距变了」而不是「中心动了」：滚动时两指间距几乎恒定
# （实测 0.057~0.070 稳定），捏合时中心几乎不动、间距明显变化。
PINCH2_MIN = 0.025      # 间距变化超过此归一化值才可能是捏合
PINCH2_RATIO = 1.55     # 间距每变化多少比例缩放一档。太小会一次手势连发好几档，
                        # 浏览器缩放是阶梯式的（100→110→125→150…），档位太密
                        # 就等于「手指刚张开就放到最大」，观感是跳而不是顺滑。
ZOOM_MIN_GAP = 0.07     # 两次发缩放键的最小间隔（秒）。缩放键是同步阻塞的，
                        # 一帧内连发多档会吃掉帧预算，反而更卡。宁可丢几档。
PINCH2_DOMINANCE = 1.5  # 间距变化须大于中心位移这么多倍，才算捏合而非滚动
PINCH2_REL = 0.10       # 相对变化下限，防止基准过小时误判

MIN_POINT_GAP = 0.015  # 两点间距小于此值视为误报，合并为一个点
MIN_TWO_FINGER_GAP = 0.06  # 双指轻点触发右键所需的最小间距

# 右键触发方式：
#   "both"             —— 单指长按 0.5 秒 **或** 双指轻点（默认）。
#   "long_press"       —— 只认单指长按。最保守，假点只存在一两帧、活不到 0.5 秒。
#   "two_finger_tap"   —— 只认双指轻点。实测这块屏单指按压会同一帧冒出相距约 2cm 的
#                         第二个点，长得和真实双指轻点很像，所以默认不单用。
#   "three_finger_tap" —— 三指轻点。实测三指滑动收尾时面板在 3/2/1 指间闪跳，
#                         闪跳会被判成三指轻点，导致滑动后莫名弹出右键菜单。
RIGHT_CLICK_BY = "two_finger_tap"
TWO_FINGER_LEAD_MS = 70    # 双指模式：第二指必须在第一指落下后这么久内到达
TWO_FINGER_MIN_MS = 50     # 太快（一两帧就结束）不算，避免接触抖动被当成轻点
TWO_FINGER_MAX_MS = 320    # 超过这个时长就是在按住，不算轻点
LONG_PRESS_MS = 500        # 长按模式的触发时长
LONG_PRESS_MAX_MOVE = 0.02  # 长按期间允许的最大净位移
PALM_WIDTH = 110     # 接触宽度超过此值（CSS px）视为手掌，丢弃

# 双击拖移（macOS 的「轻点拖移」）：第一次轻点后，第二下按住不放再滑动，
# 就能拖动窗口、选中文字。第二下按下时立刻发 mouse_down，所以「双击但不移动」
# 仍然是一次正常点击；只有移动超过 DRAG_START_MOVE 才转成拖拽。
DRAG_DOUBLE_MS = 320      # 两次按下间隔小于此值算双击，第二下才允许拖移
DRAG_START_MOVE = 0.014   # 第二下按住后移动超过这个归一化距离才真正开始拖
                     # 实测该平板手指宽度 43~60，旧值 55 会误杀真实手指

# macOS 虚拟键码
KEY_UP = 126
KEY_DOWN = 125
KEY_LEFT = 123
KEY_RIGHT = 124
KEY_F11 = 103     # F11：系统里「显示桌面」和「启动台」都绑在这个键上，靠修饰位区分
KEY_EQUAL = 24    # = 加号（放大）
KEY_MINUS = 27    # - 减号（缩小）
KEY_SPACE = 49    # 空格：Cmd+Space 唤起 Spotlight
KEY_ESC = 53      # Esc
KEY_RETURN = 36   # 回车
KEY_TAB = 48      # Tab
KEY_DELETE = 51   # Backspace（macOS 上 Delete 键就是退格）
KEY_A = 0         # 字母键从 0 开始，A=0 B=11 C=8 …（ANSI 布局）
KEY_C = 8
KEY_V = 9
KEY_X = 7
KEY_Z = 6
KEY_S = 1
KEY_Q = 12
KEY_W = 13

# 四指收拢「打开应用列表」的方式。macOS 26 移除了 Launchpad：
# /System/Applications/Launchpad.app 不存在，symbolic 37 的配置项还留着、
# 也还是 enabled，但按下去没有任何接收方 —— 这就是「四指收拢没反应」的原因。
# macOS 26 把 Launchpad 并进了 Spotlight（/System/Applications/Apps.app，
# bundle id com.apple.apps.launcher），而这个 App 用 open 唤不起来（open 返回 0
# 但面板不出现），只能走它的快捷键 symbolic 64：Cmd+Space（实测 enabled）。
#   "spotlight" —— Cmd+Space，macOS 26 的官方入口（默认）
#   "finder"    —— 打开 /Applications 文件夹，任何版本都稳，但没有全屏图标网格
#   "launchpad" —— 老系统的 F11+Shift+Function，macOS 26 上无效
APP_LAUNCHER = "spotlight"

# 修饰位。这些值都来自本机 com.apple.symbolichotkeys 的实际注册值，
# 必须完全一致才能命中系统快捷键。
FLAG_CMD = 0x100000        # Command
FLAG_CTRL = 0x840000       # Function(0x800000) + Control(0x40000) —— 三指方向键
FLAG_SHOW_DESK = 0x800000  # Function —— 显示桌面（symbolic 36）
FLAG_LAUNCHPAD = 0x820000  # Shift + Function —— 启动台（symbolic 37）

# 鼠标事件上要剔除的修饰位：这些是我们合成出来的，一旦残留在 HID 里，
# 后续单击就会变成 Control+单击(右键) / Shift+单击(连选)，必须清掉。
# Command 不在其中，以免影响用户真按住 Cmd 单击开新标签。
FLAG_STRIP = 0x860000      # Function + Control + Shift

# 所有修饰位。用于「只清理我自己发出去、并且确实残留了的那部分」，
# 不去动用户真按着的键。Command 也纳入：双指缩放后若 Cmd 残留，
# 之后的单击会变成 Cmd+单击（链接在新标签打开），同样是污染。
MOD_MASK = 0x1E0000 | 0x800000   # Shift|Control|Option|Command|Function

# CGEventType
EV_LEFT_DOWN = 1
EV_LEFT_UP = 2
EV_RIGHT_DOWN = 3
EV_RIGHT_UP = 4
EV_MOUSE_MOVED = 5
EV_LEFT_DRAGGED = 6
EV_SCROLL = 22
EV_OTHER_DOWN = 25
EV_OTHER_UP = 26
EV_OTHER_DRAGGED = 27

# CGEventField
F_CLICK_STATE = 1
F_SCROLL_CONTINUOUS = 88

TAP_HID = 0  # kCGHIDEventTap


# ----------------------------------------------------------------------------
# CoreGraphics 绑定
# ----------------------------------------------------------------------------

class CGPoint(ctypes.Structure):
    _fields_ = [("x", ctypes.c_double), ("y", ctypes.c_double)]


class CGSize(ctypes.Structure):
    _fields_ = [("width", ctypes.c_double), ("height", ctypes.c_double)]


class CGRect(ctypes.Structure):
    _fields_ = [("origin", CGPoint), ("size", CGSize)]


cg = ctypes.CDLL("/System/Library/Frameworks/CoreGraphics.framework/CoreGraphics")
cf = ctypes.CDLL("/System/Library/Frameworks/CoreFoundation.framework/CoreFoundation")

cg.CGEventCreate.restype = ctypes.c_void_p
cg.CGEventCreate.argtypes = [ctypes.c_void_p]

cg.CGEventGetLocation.restype = CGPoint
cg.CGEventGetLocation.argtypes = [ctypes.c_void_p]

cg.CGEventCreateMouseEvent.restype = ctypes.c_void_p
cg.CGEventCreateMouseEvent.argtypes = [ctypes.c_void_p, ctypes.c_uint32, CGPoint, ctypes.c_uint32]

cg.CGEventCreateScrollWheelEvent2.restype = ctypes.c_void_p
cg.CGEventCreateScrollWheelEvent2.argtypes = [
    ctypes.c_void_p, ctypes.c_uint32, ctypes.c_uint32,
    ctypes.c_int32, ctypes.c_int32, ctypes.c_int32,
]

cg.CGEventCreateKeyboardEvent.restype = ctypes.c_void_p
cg.CGEventCreateKeyboardEvent.argtypes = [ctypes.c_void_p, ctypes.c_uint16, ctypes.c_bool]

# 直接往事件里塞 Unicode 字符串，不经过键码映射 —— 中文、emoji、任意符号都靠它。
cg.CGEventKeyboardSetUnicodeString.restype = None
cg.CGEventKeyboardSetUnicodeString.argtypes = [
    ctypes.c_void_p, ctypes.c_ulong, ctypes.c_void_p]

cg.CGEventPost.argtypes = [ctypes.c_uint32, ctypes.c_void_p]
cg.CGEventGetFlags.restype = ctypes.c_uint64
cg.CGEventGetFlags.argtypes = [ctypes.c_void_p]
cg.CGEventSourceFlagsState.restype = ctypes.c_uint64
cg.CGEventSourceFlagsState.argtypes = [ctypes.c_int32]
cg.CGEventSetType.argtypes = [ctypes.c_void_p, ctypes.c_uint32]
cg.CGEventSetIntegerValueField.argtypes = [ctypes.c_void_p, ctypes.c_uint32, ctypes.c_int64]
cg.CGEventSetFlags.argtypes = [ctypes.c_void_p, ctypes.c_uint64]
cg.CGEventSetDoubleValueField.argtypes = [ctypes.c_void_p, ctypes.c_uint32, ctypes.c_double]
cg.CGEventSetLocation.argtypes = [ctypes.c_void_p, CGPoint]
cg.CGDisplayBounds.restype = CGRect
cg.CGDisplayBounds.argtypes = [ctypes.c_uint32]
cg.CGGetActiveDisplayList.restype = ctypes.c_int32
cg.CGGetActiveDisplayList.argtypes = [ctypes.c_uint32, ctypes.POINTER(ctypes.c_uint32), ctypes.POINTER(ctypes.c_uint32)]
cg.CGMainDisplayID.restype = ctypes.c_uint32
cg.CGDisplayPixelsWide.restype = ctypes.c_size_t
cg.CGDisplayPixelsWide.argtypes = [ctypes.c_uint32]
cg.CGDisplayPixelsHigh.restype = ctypes.c_size_t
cg.CGDisplayPixelsHigh.argtypes = [ctypes.c_uint32]

cf.CFRelease.argtypes = [ctypes.c_void_p]

try:
    cg.CGPreflightPostEventAccess.restype = ctypes.c_bool
    cg.CGRequestPostEventAccess.restype = ctypes.c_bool
    HAS_ACCESS_API = True
except AttributeError:
    HAS_ACCESS_API = False


def screen_size():
    did = cg.CGMainDisplayID()
    return int(cg.CGDisplayPixelsWide(did)), int(cg.CGDisplayPixelsHigh(did))


_DISPLAY_LAYOUT = (0, [])


def display_rects():
    """Quartz global coordinates, including displays left/above the primary."""
    global _DISPLAY_LAYOUT
    now=time.monotonic()
    if now-_DISPLAY_LAYOUT[0]<.5 and _DISPLAY_LAYOUT[1]:return _DISPLAY_LAYOUT[1]
    ids=(ctypes.c_uint32*64)();count=ctypes.c_uint32()
    if cg.CGGetActiveDisplayList(64,ids,ctypes.byref(count))!=0:
        return _DISPLAY_LAYOUT[1] or None
    rects=[]
    for identifier in list(ids)[:count.value]:
        bounds=cg.CGDisplayBounds(identifier)
        x,y,w,h=bounds.origin.x,bounds.origin.y,bounds.size.width,bounds.size.height
        if w>0 and h>0:rects.append((x,y,x+w-1,y+h-1))
    _DISPLAY_LAYOUT=(now,rects)
    return rects or None


def constrain_pointer(x,y,rects=None):
    rects=display_rects() if rects is None else rects
    if not rects:return x,y  # Let macOS constrain input if display enumeration failed.
    candidates=[(min(max(x,left),right),min(max(y,top),bottom)) for left,top,right,bottom in rects]
    return min(candidates,key=lambda p:(p[0]-x)**2+(p[1]-y)**2)


def cursor_pos():
    ev = cg.CGEventCreate(None)
    pt = cg.CGEventGetLocation(ev)
    cf.CFRelease(ev)
    return pt.x, pt.y


def _post(ev):
    if ev:
        cg.CGEventPost(TAP_HID, ev)
        cf.CFRelease(ev)


def _sanitize(ev):
    """剔除鼠标事件上继承来的 Function/Control 修饰位。

    用 NULL 源创建的鼠标事件会继承 HID 系统的当前修饰键状态。而 key_combo
    用 CGEventSetFlags 给方向键硬塞 0x840000（Function+Control），有概率把这个
    修饰状态留在 HID 里。一旦留下，之后每个鼠标事件都带着 Control，
    macOS 就会把单击解释成「Control+单击」= 右键，表现就是单击弹右键菜单。

    这里只剔 Function / Control / Shift 三位（FLAG_STRIP），用户真实按住的
    Command 仍然保留（Cmd+单击开新标签这类操作不受影响）。
    """
    if ev:
        cg.CGEventSetFlags(ev, cg.CGEventGetFlags(ev) & ~FLAG_STRIP)


def hid_flags():
    try:
        return cg.CGEventSourceFlagsState(1)
    except Exception:
        return 0


def clear_hid_flags():
    """发一个 flagsChanged(0) 事件，尝试把 HID 的修饰键状态归零。"""
    try:
        ev = cg.CGEventCreate(None)
        cg.CGEventSetType(ev, 12)   # kCGEventFlagsChanged
        cg.CGEventSetFlags(ev, 0)
        _post(ev)
    except Exception:
        pass


def mouse_move(x, y, dragged=False):
    ev = cg.CGEventCreateMouseEvent(
        None, EV_LEFT_DRAGGED if dragged else EV_MOUSE_MOVED, CGPoint(x, y), 0
    )
    _sanitize(ev)
    _post(ev)


def mouse_click(button="left", count=1):
    x, y = cursor_pos()
    pt = CGPoint(x, y)
    if button == "left":
        down_t, up_t, btn = EV_LEFT_DOWN, EV_LEFT_UP, 0
    elif button == "right":
        down_t, up_t, btn = EV_RIGHT_DOWN, EV_RIGHT_UP, 1
    else:
        down_t, up_t, btn = EV_OTHER_DOWN, EV_OTHER_UP, 2
    for i in range(1, count + 1):
        d = cg.CGEventCreateMouseEvent(None, down_t, pt, btn)
        cg.CGEventSetIntegerValueField(d, F_CLICK_STATE, i)
        _sanitize(d)
        _post(d)
        u = cg.CGEventCreateMouseEvent(None, up_t, pt, btn)
        cg.CGEventSetIntegerValueField(u, F_CLICK_STATE, i)
        _sanitize(u)
        _post(u)
        if i < count:
            time.sleep(0.04)


def mouse_down(button="left", count=1):
    x, y = cursor_pos()
    t, btn = {
        "left": (EV_LEFT_DOWN, 0),
        "right": (EV_RIGHT_DOWN, 1),
    }.get(button, (EV_OTHER_DOWN, 2))
    ev = cg.CGEventCreateMouseEvent(None, t, CGPoint(x, y), btn)
    cg.CGEventSetIntegerValueField(ev, F_CLICK_STATE, count)
    _sanitize(ev)
    _post(ev)


def mouse_up(button="left", count=1):
    x, y = cursor_pos()
    t, btn = {
        "left": (EV_LEFT_UP, 0),
        "right": (EV_RIGHT_UP, 1),
    }.get(button, (EV_OTHER_UP, 2))
    ev = cg.CGEventCreateMouseEvent(None, t, CGPoint(x, y), btn)
    cg.CGEventSetIntegerValueField(ev, F_CLICK_STATE, count)
    _sanitize(ev)
    _post(ev)


def scroll(dy, dx):
    if not SCROLL_NATURAL:
        dy, dx = -dy, -dx
    ev = cg.CGEventCreateScrollWheelEvent2(None, 0, 2, int(dy), int(dx), 0)
    if ev:
        cg.CGEventSetIntegerValueField(ev, F_SCROLL_CONTINUOUS, 1)
    _post(ev)


def media_volume(code):
    # Fixed scripts only. Raising volume also clears mute, as a physical key does.
    scripts = {
        72: 'set n to output volume of (get volume settings)\nset volume output volume (n + 6) without output muted',
        73: 'set n to output volume of (get volume settings)\nset volume output volume (n - 6)',
        74: 'set m to output muted of (get volume settings)\nset volume output muted (not m)',
    }
    script=scripts.get(code)
    if script is None:return None
    try:
        result=subprocess.run(['/usr/bin/osascript','-e',script+'\nget {output volume, output muted} of (get volume settings)'],
            check=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,timeout=3)
        fields=result.stdout.strip().split(', ')
        if len(fields)!=2:raise ValueError('invalid volume response')
        level=int(fields[0]);muted=fields[1].lower()=='true'
        return {'ok':True,'level':max(0,min(100,level)),'muted':muted}
    except (subprocess.SubprocessError,OSError,ValueError):
        return {'ok':False,'message':'Mac未能调节音量；请检查声音输出设备。HDMI、显示器或部分外置设备可能需要在设备上调节。'}


def native_magnify(amount, phase):
    """Emit a Quartz gesture recognized by AppKit as NSEventTypeMagnify.

    Quartz gesture fields are undocumented: compatibility is validated with the
    no-post AppKit conversion/preview handler test, not assumed to be Apple HID.
    Phase bits here are IOHID began=1/changed=2/ended=4/cancelled=8, not NSEvent bits.
    See tools/check_native_magnify.py and its primary-source references.
    """
    if phase not in (1,2,4,8) or not math.isfinite(amount):return False
    event=cg.CGEventCreate(None)
    if not event:return False
    try:
        cg.CGEventSetType(event,29)
        cg.CGEventSetFlags(event,0)
        cg.CGEventSetIntegerValueField(event,110,8)
        cg.CGEventSetIntegerValueField(event,132,phase)
        cg.CGEventSetDoubleValueField(event,113,amount)
        x,y=cursor_pos();cg.CGEventSetLocation(event,CGPoint(x,y))
        cg.CGEventPost(TAP_HID,event)
        return True
    finally:
        cf.CFRelease(event)


def key_combo(keycode, flags=0):
    d = cg.CGEventCreateKeyboardEvent(None, keycode, True)
    cg.CGEventSetFlags(d, flags)
    _post(d)
    time.sleep(0.008)
    u = cg.CGEventCreateKeyboardEvent(None, keycode, False)
    cg.CGEventSetFlags(u, flags)
    _post(u)
    # 组合键发完检查 HID 修饰键状态：若被留下，后续每个鼠标事件都会继承，
    # 单击就会被 macOS 当成右键（Control）或连选（Shift）。发现残留立刻清理。
    # 只清「本次发出去的位」，避免误清用户真按着的修饰键。
    #
    # 这里**不 sleep 等清理生效**：清理是异步的，下一帧的 SetFlags 会覆盖掉旧状态，
    # 而每档 20ms 的等待会在连续缩放时把帧率拖下来，那才是「不顺滑」的来源。
    # 日志也就不再读回值了 —— 读回必然读到旧值，只会误导。
    residual = hid_flags()
    if residual & flags & MOD_MASK:
        clear_hid_flags()


def type_text(s):
    """把一段文本注入到当前焦点。走 Unicode 字符串，不查键码表。

    这样中文、emoji、带音标的字母都能进，也不需要维护一张「字符→键码」的映射表
    （那张表在非美式键盘布局下必然出错）。逐字符发是因为部分 App 对
    一次塞整串的处理不一致，逐字最稳，观感也像真的在打字。
    """
    if not s:
        return
    for ch in s:
        if ch == "\n":
            key_combo(KEY_RETURN, 0)
            continue
        if ch == "\t":
            key_combo(KEY_TAB, 0)
            continue
        buf = ch.encode("utf-16-le")   # UniChar 就是 UTF-16 code unit
        n = len(buf) // 2              # emoji 是代理对，n 会是 2
        d = cg.CGEventCreateKeyboardEvent(None, 0, True)
        if d:
            cg.CGEventKeyboardSetUnicodeString(d, n, ctypes.c_char_p(buf))
            _post(d)
        u = cg.CGEventCreateKeyboardEvent(None, 0, False)
        if u:
            cg.CGEventKeyboardSetUnicodeString(u, n, ctypes.c_char_p(buf))
            _post(u)
        time.sleep(0.004)   # 连发太快个别 App 会丢字


def open_launcher():
    """四指收拢时打开应用列表。按 APP_LAUNCHER 选择实现方式。"""
    if APP_LAUNCHER == "finder":
        print("  [手势] 打开 /Applications", flush=True)
        try:
            subprocess.Popen(["/usr/bin/open", "/Applications"])
        except Exception as e:
            print("  [手势] 打开失败: %s" % e, flush=True)
    elif APP_LAUNCHER == "launchpad":
        # 老系统才有；macOS 26 上按了没有任何反应
        print("  [手势] 发 F11+Shift+Function（老系统 Launchpad）", flush=True)
        key_combo(KEY_F11, FLAG_LAUNCHPAD)
    else:
        # macOS 26 的官方入口。Spotlight 是覆盖层，不会改变前台 App。
        print("  [手势] 发 Cmd+Space（Spotlight / 应用列表）", flush=True)
        key_combo(KEY_SPACE, FLAG_CMD)


# ----------------------------------------------------------------------------
# 手势状态机
# ----------------------------------------------------------------------------

class ScrollMotion:
    """Normalized two-finger scroll: speed gain, bounded queue, short cancellable momentum."""
    def __init__(self):
        self.speed = self.inertia = 1.0
        self.stop()

    def stop(self):
        self.x = self.y = self.vx = self.vy = 0.0
        self.last = self.tick = self.released = 0.0
        self.momentum = False

    def begin(self, now):
        self.stop()
        self.last = self.tick = now

    def add(self, dx, dy, now):
        dt = max(.008, min(.08, now - self.last))
        speed = math.hypot(dx, dy) / dt
        gain = 1 + min(3, max(0, speed - .25) * 1.6)
        dx, dy = dx * gain * self.speed, dy * gain * self.speed
        self.x = max(-1, min(1, self.x + dx))
        self.y = max(-1, min(1, self.y + dy))
        vx, vy = dx / dt, dy / dt
        length = math.hypot(vx, vy)
        if length > 3*self.speed:
            vx, vy = vx * 3*self.speed / length, vy * 3*self.speed / length
        alpha = 1 - math.exp(-dt / .035)
        if vx*self.vx + vy*self.vy < 0:
            self.vx = self.vy = 0
            self.x, self.y = max(-1,min(1,dx)), max(-1,min(1,dy))
        self.vx += (vx - self.vx) * alpha
        self.vy += (vy - self.vy) * alpha
        self.last = now
        self.momentum = False

    def release(self, now):
        self.momentum = self.inertia > 0 and now - self.last <= .09 and math.hypot(self.vx, self.vy) > .35
        self.released = now

    def step(self, now):
        dt = max(.001, min(.04, now - self.tick))
        self.tick = now
        if self.momentum:
            tau = .18*max(.05,self.inertia)
            decay = math.exp(-dt / tau)
            self.x += self.vx * tau * (1 - decay)
            self.y += self.vy * tau * (1 - decay)
            self.vx *= decay
            self.vy *= decay
            if now - self.released >= .7*self.inertia or math.hypot(self.vx, self.vy) < .05:
                self.momentum = False
        alpha = 1 - math.exp(-dt / .018)
        dx, dy = max(-.12, min(.12, self.x * alpha)), max(-.12, min(.12, self.y * alpha))
        self.x -= dx
        self.y -= dy
        return dx, dy


class Trackpad(object):
    def __init__(self):
        self.lock = threading.Lock()
        self.scroll_motion = ScrollMotion()
        self.drag_lock_enabled = self.drag_latched = False
        self.drag_deadline = 0
        self.sw, self.sh = screen_size()
        self.last_click = 0.0
        self.pointer_gain = 720
        # 上一次单指点击的时间。跨手势保留，所以不放进 reset()
        self.last_tap_t = 0.0
        self.max_n = 0
        self._prev_n = 0
        self.cur_n = 0
        self.reset()

    def _end_magnify(self, cancelled=False):
        if getattr(self,'magnify_started',False):
            # Settle only a tiny tail; never drain a large queued zoom on release.
            tail=self.magnify_target-self.magnify_emitted
            if not cancelled and abs(tail)<=.015 and abs(tail)>1e-9:
                native_magnify(math.expm1(tail),2)
            native_magnify(0.0,8 if cancelled else 4)
        self.magnify_started=False
        self.magnify_last=None
        self.magnify_target=self.magnify_emitted=0.0
        self.magnify_tick=0.0
        self.magnify_direction=0

    def _tick_magnify(self, now):
        if not self.magnify_started:return
        dt=now-self.magnify_tick
        if dt<.007:return
        self.magnify_tick=now
        remaining=self.magnify_target-self.magnify_emitted
        if abs(remaining)<1e-9:return
        # An 8ms time constant removes sample jitter without a long smoothing lag.
        delta=remaining if abs(remaining)<1e-7 else remaining*(1-math.exp(-min(dt,.04)/.008))
        delta=max(-.1,min(.1,delta))
        native_magnify(math.expm1(delta),2)
        self.magnify_emitted+=delta

    def reset(self):
        self._end_magnify(cancelled=True)
        self.mode = "idle"
        self.n = 0
        self.gesture_n = 0
        self.t0 = 0.0
        self.last_t = 0.0
        self.acc_dx = 0.0
        self.acc_dy = 0.0
        self.last = {}
        self.direct_drag_active=False
        self.direct_drag_deadline=0.0
        self.drag_click_count=2
        self.dragging = False
        self.drag_armed = False   # 本次按下是双击的第二下
        self.drag_down = False    # 已经为拖移发过 mouse_down
        self.pinch0 = None
        self.pinch_last = None
        self.moved = 0.0
        self.start_pt = None
        self.last_pt = None
        self.vx = None
        self.vy = None
        self.pend_x = 0.0
        self.pend_y = 0.0
        self.dbg_t = 0.0
        self.prev_mode = "idle"
        self.prev_dur = 0.0
        self.frames = 0
        self.t_first = 0.0
        self.long_fired = False
        self.zoom_steps = 0
        self.zoom_t = 0.0
        self.no_tap = False

    def on_frame(self, pts, pointer_gain=720, scroll_speed=1, inertia=1, drag_lock=False, surface=None, direct_drag=False):
        """pts: [[id, nx, ny], ...] 归一化坐标"""
        with self.lock:
            self.direct_drag_requested=bool(direct_drag)
            self.pointer_gain = pointer_gain
            self.pointer_x_scale=self.pointer_y_scale=1.0
            if (isinstance(surface,list) and len(surface)==2 and
                    all(isinstance(v,(int,float)) and not isinstance(v,bool) and math.isfinite(v) and 16<=v<=10000 for v in surface)):
                base=min(surface)
                self.pointer_x_scale=surface[0]/base
                self.pointer_y_scale=surface[1]/base
            self.scroll_motion.speed, self.scroll_motion.inertia = scroll_speed, inertia
            self.drag_lock_enabled = drag_lock
            if not drag_lock and self.drag_latched:
                mouse_up("left");self.drag_latched=False
            raw_points = pts

            pts = [p for p in pts if isinstance(p,(list,tuple)) and len(p)>=3
                   and all(isinstance(v,(int,float)) and math.isfinite(v) and 0<=v<=1 for v in p[1:3])
                   and (len(p)<5 or max(p[3] or 0,p[4] or 0)<=110)][:5]
            if raw_points and not pts:
                if self.drag_down or self.drag_latched:mouse_up("left")
                self.drag_latched=False;self.reset();self.scroll_motion.stop();return

            # 手掌过滤：接触面积明显大于手指的触点直接丢弃
            if len(pts) >= 2:
                kept = [p for p in pts if len(p) < 5 or (p[3] or 0) < PALM_WIDTH]
                if kept and len(kept) < len(pts):
                    pts = kept

            # 触摸屏轻点时常误报两个几乎重合的点，会误判成双指（右键）
            if len(pts) >= 2:
                xs = [p[1] for p in pts]
                ys = [p[2] for p in pts]
                gap = ((max(xs) - min(xs)) ** 2 + (max(ys) - min(ys)) ** 2) ** 0.5
                if gap < MIN_POINT_GAP:
                    pts = [[pts[0][0], sum(xs) / len(pts), sum(ys) / len(pts)]]

            n = len(pts)
            self.cur_n = n

            if n >= 2 and n != self._prev_n:
                xs2 = [p[1] for p in pts]
                ys2 = [p[2] for p in pts]
                g2 = ((max(xs2) - min(xs2)) ** 2 + (max(ys2) - min(ys2)) ** 2) ** 0.5
                print("  [多点] n=%d gap=%.3f %s" % (n, g2, pts), flush=True)
            self._prev_n = n

            if n > self.max_n:
                self.max_n = n
                print("  [触点] 收到 %d 个触点" % n, flush=True)

            if n == 0:
                self._finish(final=True)
                return

            # Preserve two-finger scrolling until all fingers lift; staggered lift must not cancel a flick.
            if self.mode == "scroll" and n == 1:
                if self.two_ended is None:self.two_ended=time.monotonic()
                if self.scroll_intent=="pinch":
                    self._end_magnify();self.mode="residual";self.no_tap=True
                return

            # A stationary staggered lift changes the centroid. It is not a swipe.
            # Freeze the last full-contact sample until every finger is lifted.
            if self.mode == "gesture" and n < self.gesture_n:
                return

            # 多指模式只剩一根手指：立即结算并转入单指模式。
            # 否则三指抬起后残留的 gesture 状态会吞掉接下来的单指点击。
            if self.mode in ("gesture", "scroll") and n == 1:
                t_first = self.t_first
                self._finish(final=True)
                self._begin(1, pts, no_tap=True, t_first=t_first)
                # 残留手指不参与光标移动，等它完全离开屏幕
                self.mode = "residual"

            # 只在「手指数量增加」时重新开始；减少不打断。
            # 三指操作时手指不可能同时抬起，若每次减少都重置，
            # 手势会在 n=3→2→1 的过程中被截断，最后退化成一次点击。
            if self.mode == "idle" or (n > self.gesture_n and n >= 2):
                # 记下上一段状态的类型与时长：用来区分「两指同时落下」和
                # 「单指先按住、稍后才冒出来的第二个假点」。
                prev_mode = self.mode
                prev_dur = (time.time() - self.t0) * 1000.0 if self.mode != "idle" else 0.0
                t_first = self.t_first
                self._finish(final=False)
                self._begin(n, pts, t_first=t_first)
                self.prev_mode = prev_mode
                self.prev_dur = prev_dur

            cur = {p[0]: (p[1], p[2]) for p in pts}

            if self.mode == "pointer":
                if n == 1:
                    if self.last and set(cur) != set(self.last):
                        # Lost end/start frames must never become a cross-contact delta.
                        if self.drag_down:mouse_up("left",count=self.drag_click_count)
                        self.drag_latched=False;self.last_tap_t=0
                        self.reset();self._begin(1,pts,no_tap=True)
                    self._pointer(cur)
                else:
                    self.last_pt = list(cur.values())[0]
            elif self.mode == "scroll":
                self._scroll(cur)
            elif self.mode == "gesture":
                self._gesture(cur)

            self.last = cur

    def _begin(self, n, pts, no_tap=False, t_first=None):
        self._end_magnify()
        self.scroll_motion.begin(time.monotonic())
        self.scrolled = False
        self.scroll_axis = 0
        self.scroll_intent = None
        self.resuming_drag = self.drag_latched and n==1
        if self.drag_latched and n!=1:mouse_up("left")
        self.drag_latched=False
        self.n = n
        self.gesture_n = n
        self.no_tap = no_tap
        # t_first 是「这一串接触」真正的起始时刻，只有手指全部离开才重置。
        # 手指数量闪跳导致重新 _begin 时必须继承它，否则一次三指滑动收尾时的
        # 闪跳会被算成一次持续几十毫秒的「轻点」。
        self.t_first = t_first or time.time()
        self.t0 = time.time()
        self.last_t = time.time()
        self.acc_dx = 0.0
        self.acc_dy = 0.0
        self.moved = 0.0
        self.dragging = False
        self.frames = 0
        self.pinch0 = None
        self.zoom_steps = 0
        self.zoom_t = 0.0
        self.last = {p[0]: (p[1], p[2]) for p in pts}
        self.start_pt = self._avg(self.last)
        self.last_pt = self.start_pt
        if n == 1:
            self.mode = "pointer"
            self.vx, self.vy = cursor_pos()
            # 上一次点击刚结束就又按下来 = 双击的第二下，允许拖移。
            # no_tap 的情况（多指收尾残留的那根手指）不算，否则手势一结束
            # 残留手指会被当成拖移起点。
            self.drag_armed = (not getattr(self,'direct_drag_requested',False) and not no_tap
                               and (time.time() - self.last_tap_t) * 1000.0 < DRAG_DOUBLE_MS)
            if self.resuming_drag:
                self.drag_down=True;self.no_tap=True;self.drag_armed=False
            if self.drag_armed:
                self.drag_down = True
                self.no_tap = True
                mouse_down("left", count=2)
            if getattr(self,'direct_drag_requested',False):
                self.direct_drag_active=True;self.direct_drag_deadline=time.monotonic()+15;self.drag_click_count=1
                self.drag_armed=False;self.drag_down=True;self.no_tap=True
                mouse_down("left",count=1)
        elif n == 2:
            self.two_started=time.monotonic();self.two_ended=None
            self.mode = "scroll"
            self.pinch0 = self._spread_cur(self.last)
        else:
            self.mode = "gesture"
            self.pinch0 = self._spread_cur(self.last)

    @staticmethod
    def _spread_cur(cur):
        xs = [v[0] for v in cur.values()]
        ys = [v[1] for v in cur.values()]
        return ((max(xs) - min(xs)) ** 2 + (max(ys) - min(ys)) ** 2) ** 0.5

    def _avg(self, cur):
        xs = [v[0] for v in cur.values()]
        ys = [v[1] for v in cur.values()]
        return sum(xs) / len(xs), sum(ys) / len(ys)

    def _pointer(self, cur):
        if not self.last:
            return
        now = time.time()
        dt = max(now - self.last_t, 0.001)
        self.last_t = now
        self.frames += 1

        a = list(self.last.values())[0]
        b = list(cur.values())[0]
        if dt<.025 and math.hypot(b[0]-a[0],b[1]-a[1])>.28:
            self.no_tap=True;return
        self.last_pt = b
        # Pointer sensitivity must not depend on Retina pixels or monitor count.
        # Preserve fractional displacements; scroll keeps its confirmed scale below.
        raw_dx = (b[0] - a[0]) * 720.0 * self.pointer_x_scale
        raw_dy = (b[1] - a[1]) * 720.0 * self.pointer_y_scale

        # 长按右键（备选方案，最不容易误触）。
        # 放在死区判断之前，否则手指完全静止时本函数会提前 return，永远等不到触发。
        # 双击的第二下不参与长按：macOS 上「双击按住」是拖移，不是右键。
        if (RIGHT_CLICK_BY in ("long_press", "both") and not self.long_fired
                and not self.drag_armed and self.start_pt):
            held = (now - (self.t_first or self.t0)) * 1000.0
            ddx = b[0] - self.start_pt[0]
            ddy = b[1] - self.start_pt[1]
            if held >= LONG_PRESS_MS and (ddx * ddx + ddy * ddy) ** 0.5 < LONG_PRESS_MAX_MOVE:
                self.long_fired = True
                self.no_tap = True   # 抬起时不要再发左键
                print("  [右键判定] 长按 %.0fms 位移=%.3f -> 触发" % (held, (ddx * ddx + ddy * ddy) ** 0.5),
                      flush=True)
                self._click_once("right")

        self.acc_dx += b[0] - a[0]
        self.acc_dy += b[1] - a[1]
        self.moved += abs(b[0] - a[0]) + abs(b[1] - a[1])

        # 双击的第二下：按下就立刻发 mouse_down。
        # 这样「双击但不移动」抬起时还是一对完整的按下/抬起，双击照样成立；
        # 移动超过阈值再转成拖拽。发 down 必须在死区判断之前，
        # 否则手指按着不动时本函数提前 return，down 永远发不出去。
        if self.drag_armed and not self.drag_down:
            self.drag_down = True
            self.no_tap = True          # 抬起时不要再补一次左键
            print("  [拖移] 双击第二下按住 -> 按下", flush=True)
            mouse_down("left", count=2)

        # No leaky accumulation/dead-zone: slow motion must produce a continuous
        # sequence of fractional positions instead of disappearing then jumping.
        mvx, mv_y = raw_dx, raw_dy
        if mvx == 0 and mv_y == 0:return

        speed = ((mvx ** 2 + mv_y ** 2) ** 0.5) / dt
        gain = SENS * self.pointer_gain / 720.0

        if self.vx is None:
            self.vx, self.vy = cursor_pos()
        self.vx, self.vy = constrain_pointer(self.vx + mvx * gain, self.vy + mv_y * gain)

        # 双击第二下按住后，手指真的移动了才转成拖拽。
        # 用起点到当前点的净位移判断，不受抖动累积影响。
        if self.drag_down and not self.dragging and self.start_pt:
            ddx = b[0] - self.start_pt[0]
            ddy = b[1] - self.start_pt[1]
            if (ddx * ddx + ddy * ddy) ** 0.5 > DRAG_START_MOVE:
                self.dragging = True
                print("  [拖移] 开始拖拽", flush=True)

        # Browsers must receive dragged events for every movement while left is held.
        mouse_move(self.vx, self.vy, dragged=self.drag_down)
        self._dbg(raw_dx, raw_dy, speed, gain, mvx, mv_y)

    def _dbg(self, raw_dx, raw_dy, speed, gain, pend_x, pend_y):
        """指针诊断日志，最多 4 行/秒，避免刷屏。"""
        now = time.time()
        if now - self.dbg_t < 0.25:
            return
        self.dbg_t = now
        print("  [指针] raw=(%+.2f,%+.2f) pend=(%+.2f,%+.2f) v=%.0f gain=%.2f cur=(%.0f,%.0f)"
              % (raw_dx, raw_dy, pend_x, pend_y, speed, gain,
                 self.vx or 0.0, self.vy or 0.0), flush=True)

    def _scroll(self, cur):
        if not self.last:
            return
        self.frames += 1
        ax, ay = self._avg(self.last)
        bx, by = self._avg(cur)
        self.last_pt = (bx, by)
        dx = (bx - ax) * self.sw
        dy = (by - ay) * self.sh
        self.acc_dx += bx - ax
        self.acc_dy += by - ay
        self.moved += abs(bx - ax) + abs(by - ay)

        # 先判断是「捏合缩放」还是「滚动」。
        # 依据：滚动时两指间距几乎恒定（实测 0.057~0.070 很稳），中心在动；
        # 捏合时中心几乎不动，间距明显变化。所以比较「间距变化量」和「中心位移量」，
        # 前者明显占优才判定为捏合，避免滚动时误触缩放。
        spread = self._spread_cur(cur)
        if self.pinch0 and spread > 1e-6:
            d_spread = abs(spread - self.pinch0)
            if self.start_pt:
                sx, sy = self.start_pt
                d_move = ((bx - sx) ** 2 + (by - sy) ** 2) ** 0.5
            else:
                d_move = 0.0
            ratio = spread / self.pinch0
            # 双条件：绝对变化够大，且相对变化也够大。
            # 只看绝对值的话，两指刚落下时若几乎重合（基准很小），
            # 一点点位移就能凑够 PINCH2_MIN，会被误判成缩放。
            if self.scroll_intent=="pinch" or (self.scroll_intent!="scroll" and d_spread > PINCH2_MIN
                    and abs(ratio - 1.0) > PINCH2_REL
                    and d_spread > d_move * PINCH2_DOMINANCE):
                self.scroll_intent="pinch"
                # Native magnification is an incremental fraction, not +/- keys.
                # Use the initial spread for the first delta so intent detection
                # does not discard the beginning of a slow, genuine pinch.
                previous=self.magnify_last or self.pinch0
                if not self.magnify_started:
                    self.magnify_started=native_magnify(0.0,1)
                    self.magnify_tick=time.monotonic()-.016
                if self.magnify_started and previous>0:
                    change=math.log(spread/previous)
                    direction=1 if change>0 else -1 if change<0 else 0
                    if direction and self.magnify_direction and direction!=self.magnify_direction:
                        self.magnify_target=self.magnify_emitted
                    if direction:self.magnify_direction=direction
                    self.magnify_target+=change
                    self.magnify_last=spread
                    self.no_tap=True
                    self.zoom_steps=1
                    self._tick_magnify(time.monotonic())
                self.scroll_motion.stop()
                return   # 捏合期间不发滚动

        if abs(dx) > 0.5 or abs(dy) > 0.5:
            if self.start_pt and math.hypot(bx-self.start_pt[0],by-self.start_pt[1])>.008:self.scroll_intent="scroll"
            self.scrolled = True
            if not self.scroll_axis and math.hypot(self.acc_dx,self.acc_dy)>.006:
                if abs(self.acc_dy)>abs(self.acc_dx)*1.4:self.scroll_axis=1
                elif abs(self.acc_dx)>abs(self.acc_dy)*1.4:self.scroll_axis=2
            if self.scroll_axis==1:self.scroll_motion.x=self.scroll_motion.vx=0
            if self.scroll_axis==2:self.scroll_motion.y=self.scroll_motion.vy=0
            self.scroll_motion.add(0 if self.scroll_axis==1 else bx-ax,0 if self.scroll_axis==2 else by-ay,time.monotonic())

    def tick_scroll(self, now):
        with self.lock:
            self._tick_magnify(now)
            if self.direct_drag_active and now>=self.direct_drag_deadline:
                mouse_up("left",count=1);self.reset();self.last_tap_t=0
                self.scroll_motion.stop()
            if self.drag_latched and now>=self.drag_deadline:
                mouse_up("left");self.drag_latched=False
            dx, dy = self.scroll_motion.step(now)
            if abs(dx*self.sw*SCROLL_GAIN)>=1 or abs(dy*self.sh*SCROLL_GAIN)>=1:
                scroll(dy*self.sh*SCROLL_GAIN, dx*self.sw*SCROLL_GAIN)

    def _gesture(self, cur):
        if not self.last:
            return
        self.frames += 1
        ax, ay = self._avg(self.last)
        bx, by = self._avg(cur)
        self.last_pt = (bx, by)
        dx = bx - ax
        dy = by - ay
        self.acc_dx += dx
        self.acc_dy += dy
        self.moved += abs(dx) + abs(dy)
        # 只在「这一帧确实是四指」时更新间距。手指逐个抬起会让间距变小，
        # 若不过滤就会把「抬手指」误判成捏合。这样 pinch_last 始终是最后一次
        # 四指齐全时的真实间距。
        if len(cur) == 4:
            self.pinch_last = self._spread_cur(cur)

    def _click_once(self, button):
        """防抖：55ms 内重复的点击直接丢弃。

        保留正常双击间隔；触点边界由客户端立即发送。
        """
        now = time.time()
        if now - self.last_click < 0.055:
            return
        self.last_click = now
        print("  [点击] %s t=%.3f hid=0x%X" % (button, now, hid_flags()), flush=True)
        mouse_click(button)

    def _finish(self, final=True):
        self._end_magnify()
        n = self.gesture_n or self.n
        mode = self.mode
        if mode == "scroll" and getattr(self,"scrolled",False):
            self.scroll_motion.release(time.monotonic())
        # 用整串接触的真实起点计时，而不是最近一次 _begin。
        # 否则三指滑动收尾时 3 指/2 指闪跳会重启计时器，让整段滑动被误判成轻点。
        dt = (time.time() - (self.t_first or self.t0)) * 1000.0

        # 拖拽中，或者双击第二下已经按下（还没拖起来），都要补一次抬起。
        # 后者不能走下面的点击分支 —— 否则第二次按下会被再发一对 down/up。
        if self.dragging or self.drag_down:
            print("  [拖移] 结束%s" % ("（拖动过）" if self.dragging else "（未移动，算普通点击）"),
                  flush=True)
            if self.drag_lock_enabled and self.dragging and not self.direct_drag_active:
                self.reset();self.last_tap_t=0;self.drag_latched=True;self.drag_deadline=time.monotonic()+5;return
            mouse_up("left", count=self.drag_click_count)
            self.last_tap_t=0
            self.reset()
            return

        # 点数中途变化（手指陆续抬起）不判手势，只清状态
        if not final:
            self.reset()
            return

        # 净位移：起点到终点，不受抖动累积影响
        disp = 0.0
        gdx, gdy = self.acc_dx, self.acc_dy
        if self.start_pt and self.last_pt:
            gdx = self.last_pt[0] - self.start_pt[0]
            gdy = self.last_pt[1] - self.start_pt[1]
            disp = (gdx ** 2 + gdy ** 2) ** 0.5

        if mode == "gesture" and n >= 3:
            pinch = 0.0
            # 四指捏合：pinch_last 只在四指齐全的帧更新（见 _gesture），
            # 所以这里不需要再要求 cur_n == 4 —— 收尾时手指已经抬起，
            # cur_n 必然是 0 或 1，旧条件导致捏合永远算不出来。
            if n == 4 and self.pinch0 and self.pinch_last:
                pinch = self.pinch_last / self.pinch0
            print("  [手势] n=%d dx=%.3f dy=%.3f disp=%.3f pinch=%.2f dt=%.0fms"
                  % (n, gdx, gdy, disp, pinch, dt), flush=True)

            if pinch and abs(pinch - 1.0) > PINCH_MIN:
                # 四指收拢 -> 应用列表（macOS 26 没有 Launchpad，走 Spotlight）
                # 四指张开 -> 显示桌面（symbolic 36：F11 + Function，实测仍有效）
                if pinch < 1.0:
                    print("  [手势] 四指收拢 %.2f" % pinch, flush=True)
                    open_launcher()
                else:
                    print("  [手势] 四指张开 %.2f -> 显示桌面" % pinch, flush=True)
                    key_combo(KEY_F11, FLAG_SHOW_DESK)
            elif abs(gdy) > SWIPE_MIN and abs(gdy) > abs(gdx):
                key_combo(KEY_UP if gdy < 0 else KEY_DOWN, FLAG_CTRL)
            elif abs(gdx) > SWIPE_MIN:
                # 手指左滑 = 去左侧桌面（实测系统 79/80 的行为与名称相反，此处交换）
                key_combo(KEY_RIGHT if gdx < 0 else KEY_LEFT, FLAG_CTRL)
            elif dt < TAP_MAX_MS and disp < TAP_MAX_MOVE:
                # 三指轻点要求「整段接触始终是三指」：三指滑动收尾时手指逐个
                # 抬起会让 cur_n 掉到 2 或 1，那种情况绝不能算轻点。
                if n == 3 and self.cur_n == 3 and self.frames >= 3:
                    if RIGHT_CLICK_BY == "three_finger_tap":
                        print("  [右键判定] 三指轻点 dt=%.0fms disp=%.3f -> 触发"
                              % (dt, disp), flush=True)
                        self._click_once("right")
                    else:
                        print("  [中键判定] 三指轻点 dt=%.0fms -> 触发" % dt, flush=True)
                        self._click_once("middle")
                elif n == 3:
                    print("  [轻点] 三指但中途掉指(cur_n=%d) -> 忽略" % self.cur_n,
                          flush=True)
                else:
                    print("  [轻点] 四指轻点 -> 忽略", flush=True)

        elif (mode == "pointer" and dt < TAP_MAX_MS and disp < TAP_MAX_MOVE
              and not self.no_tap):
            self._click_once("left")
            # 记下这次点击的时间：下一次按下若在 DRAG_DOUBLE_MS 内，
            # 就当作双击的第二下，允许按住拖移。
            self.last_tap_t = time.time()

        elif (mode == "scroll" and dt < TAP_MAX_MS and disp < TAP_MAX_MOVE
              and (self.pinch0 or 0) >= MIN_TWO_FINGER_GAP):
            # 双指轻点 = 右键。必须满足：
            #   1) 这段双指接触是从空闲或单指状态直接开始的（不是三指滑动收尾的残影）
            #   2) 第二指在第一指落下后 70ms 内到达（排除单指按住后冒出的假点）
            #   3) 两指真实重叠 50~320ms；静止轻点不依赖浏览器 move 帧数
            #   4) 净位移小于 TAP_MAX_MOVE（滚动会有明显位移，轻点没有）
            lead = self.prev_dur if self.prev_mode == "pointer" else 0.0
            clean_start = self.prev_mode in ("idle", "pointer")
            overlap_ms=((self.two_ended if self.two_ended is not None else time.monotonic())-self.two_started)*1000
            ok = (RIGHT_CLICK_BY in ("two_finger_tap", "both") and clean_start
                  and lead <= TWO_FINGER_LEAD_MS
                  and TWO_FINGER_MIN_MS <= overlap_ms <= TWO_FINGER_MAX_MS
                  and not self.scrolled and self.scroll_intent != "pinch"
                  # 缩放过程中发过档位就绝不是轻点。否则双指缩放一收手就会
                  # 弹右键，还会把之后 350ms 内的单击全吞掉（防抖窗口）。
                  and self.zoom_steps == 0)
            print("  [右键判定] 双指轻点 gap=%.3f dt=%.0fms lead=%.0fms frames=%d prev=%s -> %s"
                  % (self.pinch0 or 0, dt, lead, self.frames, self.prev_mode,
                     "触发" if ok else "忽略"), flush=True)
            if ok:
                self._click_once("right")

        self.reset()


# ----------------------------------------------------------------------------
# WebSocket（最小实现，仅文本帧）
# ----------------------------------------------------------------------------

WS_GUID = "258EAFA5-E914-47DA-95CA-C5AB0DC85B11"


def recv_exact(conn, n):
    buf = b""
    while len(buf) < n:
        chunk = conn.recv(n - len(buf))
        if not chunk:
            return None
        buf += chunk
    return buf


def ws_handshake(conn, headers):
    values={line.split(':',1)[0].strip().lower():line.split(':',1)[1].strip() for line in headers if ':' in line}
    key=values.get('sec-websocket-key','')
    try:
        if len(base64.b64decode(key,validate=True))!=16:return False
    except Exception:return False
    if values.get('sec-websocket-version')!='13' or values.get('upgrade','').lower()!='websocket' or 'upgrade' not in [v.strip() for v in values.get('connection','').lower().split(',')]:
        return False
    accept = base64.b64encode(hashlib.sha1((key + WS_GUID).encode()).digest()).decode()
    resp = (
        "HTTP/1.1 101 Switching Protocols\r\n"
        "Upgrade: websocket\r\n"
        "Connection: Upgrade\r\n"
        "Sec-WebSocket-Accept: " + accept + "\r\n\r\n"
    )
    conn.sendall(resp.encode())
    return True


def ws_recv(conn):
    hdr = recv_exact(conn, 2)
    if not hdr:
        return None, None
    b1, b2 = hdr[0], hdr[1]
    opcode = b1 & 0x0F
    if b1 & 0x70 or not b1 & 0x80 or opcode not in (1, 8, 9, 10):
        return None, None
    masked = b2 & 0x80
    if not masked:
        return None, None
    ln = b2 & 0x7F
    if ln == 126:
        ext = recv_exact(conn, 2)
        if not ext:
            return None, None
        ln = struct.unpack(">H", ext)[0]
    elif ln == 127:
        ext = recv_exact(conn, 8)
        if not ext:
            return None, None
        ln = struct.unpack(">Q", ext)[0]
    if ln > 32768 or opcode >= 8 and ln > 125:
        return None, None
    mask = recv_exact(conn, 4)
    if mask is None:
        return None, None
    data = recv_exact(conn, ln) if ln else b""
    if data is None:
        return None, None
    if masked:
        data = bytes(d ^ mask[i % 4] for i, d in enumerate(data))
    return opcode, data


def ws_send_text(conn, text):
    data = text.encode()
    n = len(data)
    if n < 126:
        hdr = bytes([0x81, n])
    elif n < 65536:
        hdr = bytes([0x81, 126]) + struct.pack(">H", n)
    else:
        hdr = bytes([0x81, 127]) + struct.pack(">Q", n)
    conn.sendall(hdr + data)


# ----------------------------------------------------------------------------
# HTTP + 页面
# ----------------------------------------------------------------------------

PAGE = r"""<!doctype html>
<html lang="zh">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no,viewport-fit=cover">
<meta name="theme-color" content="#080a0d">
<meta name="apple-mobile-web-app-capable" content="yes">
<link rel="manifest" href="/manifest.webmanifest">
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
<meta name="apple-mobile-web-app-title" content="Trackpad">
<meta name="mobile-web-app-capable" content="yes">
<title>Trackpad</title>
<style>
*{box-sizing:border-box}
html,body{margin:0;height:100%;background:#0b0b0d;overflow:hidden;touch-action:none;
  -webkit-user-select:none;user-select:none;-webkit-touch-callout:none;
  font-family:-apple-system,system-ui,sans-serif;overscroll-behavior:none}

#stage{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;
  padding-bottom:var(--kbh,0px);transition:padding-bottom .28s cubic-bezier(.2,.8,.2,1)}

/* 触摸板本体：触摸范围就是这个元素的矩形 */
#pad{
  position:relative;
  /* 126vh 换算成高度约 90.6vh（原值）；键盘展开时再减掉抽屉占的高度 */
  width:min(92vw, calc(126vh - 1.39 * var(--kbh,0px)));
  aspect-ratio:1.39;
  border-radius:28px;
  overflow:hidden;
  touch-action:none;
  -webkit-tap-highlight-color:transparent;
  /* 有 pad.png 就用照片，没有就用下面的白色面板 */
  background-image:
    url('/pad.png'),
    radial-gradient(130% 100% at 50% -12%, #ffffff 0%, #f7f8fa 34%, #eceef1 62%, #dfe2e7 100%),
    linear-gradient(160deg,#ffffff 0%,#f4f5f7 45%,#e4e6ea 100%);
  background-size:cover,auto,auto;
  background-position:center,center,center;
  box-shadow:
    0 28px 64px rgba(0,0,0,.58),
    0 0 0 1px rgba(0,0,0,.10) inset,
    0 1px 0 rgba(255,255,255,.95) inset,
    0 -18px 40px rgba(0,0,0,.09) inset;
  transition:box-shadow .18s ease, width .28s cubic-bezier(.2,.8,.2,1);
}
/* 细纹理 + 边缘暗角，让它有实体感 */
#pad::before{
  content:'';position:absolute;inset:0;pointer-events:none;border-radius:inherit;
  background:
    repeating-linear-gradient(90deg,rgba(0,0,0,.006) 0 1px,rgba(0,0,0,0) 1px 4px),
    radial-gradient(105% 65% at 50% 120%, rgba(0,0,0,.07), rgba(0,0,0,0) 64%);
}
#pad::after{
  content:'';position:absolute;inset:0;pointer-events:none;border-radius:inherit;
  box-shadow:0 0 0 1px rgba(0,0,0,.06) inset, 0 2px 6px rgba(0,0,0,.05) inset;
}
#pad.touching{
  box-shadow:
    0 28px 64px rgba(0,0,0,.58),
    0 0 0 1px rgba(0,122,255,.42) inset,
    0 0 38px rgba(0,122,255,.22),
    0 1px 0 rgba(255,255,255,.95) inset,
    0 -18px 40px rgba(0,0,0,.09) inset;
}

/* 手指指示点：白底上用蓝色才看得清 */
#dots{position:absolute;inset:0;pointer-events:none;border-radius:inherit}
.dot{position:absolute;left:0;top:0;width:0;height:0;
  transition:transform .07s linear;will-change:transform}
.dot i{position:absolute;left:-38px;top:-38px;width:76px;height:76px;border-radius:50%;
  background:radial-gradient(circle at 50% 50%,
    rgba(0,122,255,.40) 0%,
    rgba(0,122,255,.16) 46%,
    rgba(0,122,255,0) 72%);
  box-shadow:0 0 0 1.5px rgba(0,122,255,.34) inset;
  transform:scale(.32);opacity:0;
  transition:transform .14s cubic-bezier(.2,.9,.2,1),opacity .14s ease}
.dot.on i{transform:scale(1);opacity:1}
.dot.out i{transform:scale(1.75);opacity:0;transition:transform .19s ease-out,opacity .19s ease-out}

#hud{position:absolute;right:22px;top:16px;color:#3c3c44;font-size:46px;
  font-weight:200;line-height:1;pointer-events:none;font-variant-numeric:tabular-nums}
#hint{position:absolute;left:0;right:0;bottom:16px;text-align:center;color:#6e6e78;
  font-size:12px;letter-spacing:.02em;pointer-events:none}

#gate{position:absolute;inset:0;display:flex;flex-direction:column;
  align-items:center;justify-content:center;gap:18px;background:#0b0b0d;color:#e8e8ea;z-index:9}
#gate h1{font-size:19px;font-weight:500;margin:0;letter-spacing:.04em}
#gate p{margin:0;font-size:13px;color:#6a6a72;line-height:1.7;text-align:center}
#go{padding:14px 40px;font-size:16px;border-radius:12px;border:1px solid #2e2e34;
  background:#1a1a1f;color:#e8e8ea;font-family:inherit}
#go:active{background:#24242a}

/* ============ 底部键盘抽屉 ============ */
:root{--kbh:0px;--vvh:0px}
body.kb{--kbh:196px}

#kbToggle{
  position:fixed;left:14px;bottom:calc(14px + env(safe-area-inset-bottom));
  width:52px;height:52px;border-radius:16px;z-index:30;
  border:1px solid rgba(255,255,255,.14);
  background:rgba(28,28,33,.88);color:#e8e8ee;font-size:17px;line-height:1;
  -webkit-backdrop-filter:blur(18px);backdrop-filter:blur(18px);
  box-shadow:0 8px 26px rgba(0,0,0,.5);
  transition:transform .16s ease, background .16s ease,
             border-color .16s ease, bottom .28s cubic-bezier(.2,.8,.2,1);
}
#kbToggle:active{transform:scale(.93)}
body.kb #kbToggle{
  background:#4a8cff;border-color:#4a8cff;color:#fff;
  /* 键盘展开时浮到抽屉上方，否则会压住左下角的修饰键 */
  bottom:calc(var(--kbh,0px) + 14px + env(safe-area-inset-bottom));
}

#kb{
  position:fixed;left:0;right:0;bottom:var(--vvh,0px);z-index:25;
  padding:10px 12px calc(10px + env(safe-area-inset-bottom));
  background:rgba(16,16,19,.97);
  -webkit-backdrop-filter:blur(24px);backdrop-filter:blur(24px);
  border-top:1px solid rgba(255,255,255,.09);
  box-shadow:0 -18px 44px rgba(0,0,0,.55);
  transform:translateY(100%);
  transition:transform .28s cubic-bezier(.2,.8,.2,1), bottom .2s ease;
  touch-action:auto;
  -webkit-user-select:text;user-select:text;
}
body.kb #kb{transform:translateY(0)}

#kbInput{
  display:block;width:100%;height:46px;margin:0 0 9px;
  border-radius:12px;border:1px solid rgba(255,255,255,.12);
  background:rgba(255,255,255,.06);color:#f2f2f5;
  font-size:16px;font-family:inherit;padding:0 14px;outline:none;
  -webkit-user-select:text;user-select:text;
}
#kbInput::placeholder{color:#5a5a64}
#kbInput:focus{border-color:#4a8cff;box-shadow:0 0 0 3px rgba(74,140,255,.16)}

#kb .kbrow{display:flex;flex-wrap:wrap;gap:6px;margin-bottom:7px}
#kb .kbrow:last-child{margin-bottom:0}
#kb button{
  flex:0 0 auto;height:38px;min-width:42px;padding:0 11px;
  border-radius:10px;border:1px solid rgba(255,255,255,.10);
  background:rgba(255,255,255,.07);color:#e8e8ee;
  font-size:13px;font-family:inherit;line-height:1;
  transition:transform .1s ease, background .12s ease;
}
#kb button:active{transform:scale(.94);background:rgba(255,255,255,.16)}
#kb button.on{background:#4a8cff;border-color:#4a8cff;color:#fff}
#kb .gap{flex:1 0 6px}
</style>
</head>
<body>
<div id="stage">
  <div id="pad"><div id="dots"></div></div>
  <div id="hint">单指移动 · 双指滚动 · 三指切桌面 · 按住不动 0.5 秒右键</div>
</div>
<div id="hud">0</div>
<div id="gate">
  <h1>Trackpad</h1>
  <p>点开始连接 Mac<br>iPhone：分享 → 添加到主屏幕，从图标打开可隐藏浏览器栏</p>
  <button id="go">开始</button>
</div>
<button id="kbToggle" aria-label="键盘">键</button>
<div id="kb">
  <input id="kbInput" type="text" autocomplete="off" autocorrect="off"
         autocapitalize="off" spellcheck="false"
         placeholder="在这里打字，字会直接进 Mac…">
  <div id="kbEssential" class="kbrow">
    <button data-key="51" aria-label="删除">删除</button>
    <button data-key="36" aria-label="回车">回车</button>
    <button id="kbHide" aria-label="收起键盘">收起</button>
  </div>
</div>

<script>
var padEl = document.getElementById('pad');
var dotsEl = document.getElementById('dots');
var hud = document.getElementById('hud');
var gate = document.getElementById('gate');
var ws = null, raf = 0, on = false;
var touches = new Map();
var maxSeen = 0;
var rect = null, contactRect = null;

/* ---------- 触摸板矩形 ---------- */
function measure() { rect = padEl.getBoundingClientRect(); }
function inside(x, y) {
  if (!rect) measure();
  return x >= rect.left && x <= rect.right && y >= rect.top && y <= rect.bottom;
}
window.addEventListener('resize', measure);
window.addEventListener('orientationchange', function () { setTimeout(measure, 250); });

/* ---------- 连接 ---------- */
var reconnectDelay=800,heartbeatTimer=0,reconnectTimer=0,handshakeTimer=0;
var connectionClientId=Array.from({length:32},function(){return Math.floor(Math.random()*16).toString(16);}).join('');
function stopConnectionTimers() {
  if(heartbeatTimer&&window.clearInterval)clearInterval(heartbeatTimer);
  clearTimeout(reconnectTimer);clearTimeout(handshakeTimer);heartbeatTimer=reconnectTimer=handshakeTimer=0;
}
function resetInputSession() {
  if(window.trackpadEndDirectDrag)trackpadEndDirectDrag();
  clearAll();
  if(raf){cancelAnimationFrame(raf);raf=0;}
  contactRect=null;
  if(window.resetRemoteEditor)resetRemoteEditor();
}
function inputTimestamp(){return performance.now();}
function handleInputReset(message){
  if(ws&&ws.readyState===1)ws.send('{"cancel":true,"p":[]}');
  resetInputSession();
  if(window.trackpadConnectionStatus)trackpadConnectionStatus(message);
}
function connect() {
  if(!on || document.hidden)return;
  if(ws && (ws.readyState===0 || ws.readyState===1))return;
  stopConnectionTimers();
  var proto = location.protocol === 'https:' ? 'wss://' : 'ws://';
  if(!window.TrackpadNative&&window.trackpadConnectionStatus)trackpadConnectionStatus('正在连接Mac…');
  try{ws = new WebSocket(proto + location.host + '/ws?client='+connectionClientId);}
  catch(e){
    if(window.trackpadConnectionStatus)trackpadConnectionStatus('浏览器未能创建控制连接，正在重试；请刷新页面加载最新兼容修正');
    reconnectTimer=setTimeout(connect,Math.min(15000,reconnectDelay));reconnectDelay=Math.min(15000,reconnectDelay*1.8);return;
  }
  var socket=ws,lastReply=0,closedOnce=false,connectionFailure='';
  if(!window.TrackpadNative)handshakeTimer=setTimeout(function(){
    if(socket!==ws||socket.readyState!==0)return;
    connectionFailure='控制连接超时，正在重试；请确认Mac在线且另一设备已退出控制';
    try{socket.close();}catch(e){}
    // Some older WebKit failures never deliver close; the guard handles both paths.
    socket.onclose();
  },8000);
  socket.onopen = function () {
    if(socket!==ws){try{socket.close();}catch(e){}return;}
    stopConnectionTimers();reconnectDelay=800;lastReply=inputTimestamp();
    socket.send('{"cancel":true,"p":[]}');resetInputSession();
    hud.style.color = '#3c3c44';hud.textContent = '0';measure();
    socket.send(JSON.stringify({sentAt:inputTimestamp(),meta:{vw:Math.round(innerWidth),vh:Math.round(innerHeight),pw:Math.round(rect.width),ph:Math.round(rect.height)}}));
    // Native LAN owns its heartbeat; Bluetooth has no WebSocket peer.
    if(!window.TrackpadNative&&window.setInterval)heartbeatTimer=setInterval(function(){
      if(socket!==ws||socket.readyState!==1||document.hidden)return;
      if(inputTimestamp()-lastReply>12000){socket.close();resetInputSession();return;}
      socket.send(JSON.stringify({heartbeat:true,sentAt:inputTimestamp()}));
    },4000);
    if(!window.TrackpadNative&&window.trackpadConnectionStatus)trackpadConnectionStatus('已连接，正在检查Mac控制权限…');
  };
  socket.onmessage = function(event){if(socket!==ws)return;lastReply=inputTimestamp();try{var value=JSON.parse(event.data);if(value.inputReset)handleInputReset(value.inputReset);if(value.status&&window.trackpadHandleServerStatus)trackpadHandleServerStatus(value.status);if(value.volume&&window.trackpadVolumeStatus)trackpadVolumeStatus(value.volume);}catch(e){}};
  socket.onclose = function () {
    if(socket!==ws||closedOnce)return;closedOnce=true;
    stopConnectionTimers();resetInputSession();
    hud.style.color = '#a33';hud.textContent = '×';
    if(window.trackpadConnectionStatus)trackpadConnectionStatus(connectionFailure||'连接已断开，正在检查设备权限…');
    if(!on||document.hidden)return;
    var delay=reconnectDelay;reconnectDelay=Math.min(15000,reconnectDelay*1.8);
    var retry=function(){if(!on||document.hidden||socket!==ws)return;ws=null;connect();};
    // A hung session request must not block reconnection indefinitely.
    reconnectTimer=setTimeout(retry,delay);
    if(window.fetch && !window.TrackpadNative){fetch('/api/session',{credentials:'same-origin'}).then(function(r){
      if(socket!==ws||!on||document.hidden)return;
      if(r.status===401){on=false;clearTimeout(reconnectTimer);if(window.trackpadConnectionStatus)trackpadConnectionStatus('设备尚未配对或权限已撤销，请在Mac重新扫码');}
      else return r.json().then(function(s){if(socket!==ws||!on||document.hidden)return;if(s.busy&&!s.ownsControl){clearTimeout(reconnectTimer);reconnectTimer=setTimeout(retry,15000);if(window.trackpadConnectionStatus)trackpadConnectionStatus('另一台设备正在控制，请先断开或在Mac撤销');}});
    }).catch(function(){if(socket===ws&&on&&window.trackpadConnectionStatus)trackpadConnectionStatus('Mac暂不可达，正在重试；若网络地址变化，请重新扫码');});}
  };
  socket.onerror = function () {
    if(socket!==ws)return;hud.style.color='#a33';hud.textContent='!';
    connectionFailure='控制通道未建立，正在重试；若页面可打开但一直失败，请确认Mac接收端和Wi-Fi正常';
    if(window.trackpadConnectionStatus)trackpadConnectionStatus(connectionFailure);
  };
}
document.addEventListener('visibilitychange',function(){
  if(window.TrackpadNative)return;
  if(document.hidden){
    stopConnectionTimers();var old=ws;ws=null;
    if(old){if(old.readyState===1)try{old.send('{"cancel":true,"p":[]}');}catch(e){}if(old.readyState===0||old.readyState===1)try{old.close();}catch(e){}}
    resetInputSession();
  } else if(on)connect();
});

/* ---------- 发送：坐标归一化到触摸板矩形 ---------- */
function flush() {
  raf = 0;
  if(ws&&typeof ws.bufferedAmount==='number'&&ws.bufferedAmount>32768){
    clearAll();ws.close();return;  // Closing releases controls; never replay stale motion.
  }
  if (!ws || ws.readyState !== 1 || window.trackpadInputAllowed===false) return;
  if (!rect) measure();
  var bounds = contactRect || rect;
  var arr = [];
  touches.forEach(function (t, id) {
    var nx = (t.x - bounds.left) / bounds.width;
    var ny = (t.y - bounds.top) / bounds.height;
    nx = nx < 0 ? 0 : (nx > 1 ? 1 : nx);
    ny = ny < 0 ? 0 : (ny > 1 ? 1 : ny);
    arr.push([id, Math.round(nx * 10000) / 10000,
                  Math.round(ny * 10000) / 10000,
                  Math.round(t.w), Math.round(t.h)]);
  });
  ws.send(JSON.stringify({ sentAt:inputTimestamp(), p: arr, directDrag:!!window.trackpadDirectDrag, surface:[Math.round(bounds.width),Math.round(bounds.height)], settings: window.trackpadFeel || {pointerGain: window.trackpadPointerGain || 720} }));
  if (!arr.length) contactRect = null;
  if(!arr.length&&window.trackpadDirectDrag&&window.trackpadEndDirectDrag)trackpadEndDirectDrag();
}

function schedule() { if (!raf) raf = requestAnimationFrame(flush); }

function refresh() {
  if (touches.size > maxSeen) maxSeen = touches.size;
  hud.textContent = maxSeen > 0 ? (touches.size + '/' + maxSeen) : '0';
  if (touches.size) padEl.classList.add('touching');
  else padEl.classList.remove('touching');
  schedule();
}

/* ---------- 手指指示点 ---------- */
function moveDot(dot, x, y) {
  if (!rect) measure();
  dot.style.transform = 'translate(' + (x - rect.left) + 'px,' + (y - rect.top) + 'px)';
}
function makeDot(x, y) {
  var d = document.createElement('div');
  d.className = 'dot';
  d.innerHTML = '<i></i>';
  moveDot(d, x, y);
  dotsEl.appendChild(d);
  // 下一帧再加 on，才能看到从小到大的弹出动画
  requestAnimationFrame(function () { d.classList.add('on'); });
  return d;
}

/* ---------- 触摸点集合 ---------- */
function add(id, x, y, w, h) {
  if (!ws || ws.readyState!==1 || window.trackpadInputAllowed===false) return;
  if (!inside(x, y)) return;          // 只接受从触摸板内部开始的接触
  if (!touches.size) contactRect = {left:rect.left,top:rect.top,width:rect.width,height:rect.height};
  var dot = makeDot(x, y);
  touches.set(id, { x: x, y: y, w: w || 0, h: h || 0, dot: dot });
  refresh();
}
function upd(id, x, y, w, h) {
  var t = touches.get(id);
  if (!t) return;
  t.x = x; t.y = y;
  if (w) t.w = w;
  if (h) t.h = h;
  moveDot(t.dot, x, y);
  refresh();
}
function del(id) {
  var t = touches.get(id);
  if (!t) return;
  touches.delete(id);
  var d = t.dot;
  d.classList.remove('on');
  d.classList.add('out');
  setTimeout(function () { if (d.parentNode) d.parentNode.removeChild(d); }, 260);
  refresh();
}
function clearAll() {
  touches.forEach(function (t) {
    if (t.dot.parentNode) t.dot.parentNode.removeChild(t.dot);
  });
  touches.clear();
  maxSeen = 0;
  refresh();
}

/* ---------- 事件绑定 ---------- */
if (window.PointerEvent) {
  padEl.addEventListener('pointerdown', function (e) {
    e.preventDefault();
    if (e.pointerType === 'mouse') return;
    if (e.isPrimary) { clearAll(); }
    add(e.pointerId, e.clientX, e.clientY, e.width, e.height);
    if(touches.has(e.pointerId)&&padEl.setPointerCapture)padEl.setPointerCapture(e.pointerId);
  }, { passive: false });
  padEl.addEventListener('pointermove', function (e) {
    e.preventDefault();
    if (e.pointerType === 'mouse') return;
    upd(e.pointerId, e.clientX, e.clientY, e.width, e.height);
  }, { passive: false });
  padEl.addEventListener('pointerup', function (e) {
    e.preventDefault(); del(e.pointerId);
  }, { passive: false });
  padEl.addEventListener('pointercancel', function (e) {
    e.preventDefault(); del(e.pointerId);
  }, { passive: false });
} else {
  padEl.addEventListener('touchstart', function (e) {
    e.preventDefault();
    for (var i = 0; i < e.changedTouches.length; i++) {
      var t = e.changedTouches[i];
      add(t.identifier, t.clientX, t.clientY);
    }
  }, { passive: false });
  padEl.addEventListener('touchmove', function (e) {
    e.preventDefault();
    for (var i = 0; i < e.changedTouches.length; i++) {
      var t = e.changedTouches[i];
      upd(t.identifier, t.clientX, t.clientY);
    }
  }, { passive: false });
  padEl.addEventListener('touchend', function (e) {
    e.preventDefault();
    for (var i = 0; i < e.changedTouches.length; i++) del(e.changedTouches[i].identifier);
  }, { passive: false });
  padEl.addEventListener('touchcancel', function (e) {
    e.preventDefault();
    for (var i = 0; i < e.changedTouches.length; i++) del(e.changedTouches[i].identifier);
  }, { passive: false });
}
['gesturestart','gesturechange','gestureend'].forEach(function(name){padEl.addEventListener(name,function(e){e.preventDefault();},{passive:false});});

window.addEventListener('blur', clearAll);
document.addEventListener('visibilitychange', function () {
  if (document.hidden) clearAll();
});

document.getElementById('go').addEventListener('click', function () {
  // Shared UI starts input independently of the optional browser fullscreen promise.
  if(window.trackpadStart)window.trackpadStart(true);
});

/* ============ 键盘抽屉 ============ */
var kbToggle = document.getElementById('kbToggle');
var kbInput = document.getElementById('kbInput');
var kbEl = document.getElementById('kb');

/* 修饰位，与 Mac 端常量一一对应 */
var MOD_FLAG = { shift: 0x20000, ctrl: 0x40000, opt: 0x80000, cmd: 0x100000 };
var mods = { cmd: 0, ctrl: 0, opt: 0, shift: 0 };

function wsSend(obj) {
  if(window.trackpadInputAllowed===false&&!obj.cancel&&!obj.heartbeat)return;
  if (ws && ws.readyState === 1) {obj.sentAt=inputTimestamp();ws.send(JSON.stringify(obj));}
}
function sendText(s) { if (s) wsSend({ t: s }); }
function sendKey(code, flags) { wsSend({ k: { c: code, f: flags || 0 } }); }
function curFlags() {
  var f = 0;
  for (var m in mods) if (mods[m]) f |= MOD_FLAG[m];
  return f;
}

/* 抽屉开合。开的时候等过渡走完再重新量触摸板矩形，
   否则 rect 还是旧尺寸，触摸范围会和看到的板子对不上。 */
function setKb(open) {
  document.body.classList.toggle('kb', !!open);
  if (open) {
    // focus 必须同步在 click 里调用，晚一拍就失去用户手势上下文，
    // 移动端浏览器不会弹系统键盘。measure 反而要等过渡走完。
    kbInput.focus();
    setTimeout(measure, 60);
    setTimeout(measure, 340);
  } else {
    kbInput.blur();
    setTimeout(measure, 340);
  }
}
kbToggle.addEventListener('click', function () {
  setKb(!document.body.classList.contains('kb'));
});

/* Native browser editing owns composition. Forward only actual full-buffer differences. */
var composing = false, remoteBuffer = '';
function resetRemoteEditor() { remoteBuffer='';kbInput.value=''; }
function syncRemoteEditor() {
  if(!ws||ws.readyState!==1){resetRemoteEditor();return;}
  var previous=Array.from(remoteBuffer),next=Array.from(kbInput.value),common=0;
  while(common<previous.length&&common<next.length&&previous[common]===next[common])common++;
  for(var i=common;i<previous.length;i++)sendKey(51,curFlags());
  if(common<next.length)sendText(next.slice(common).join(''));
  remoteBuffer=kbInput.value;
}
kbInput.addEventListener('compositionstart',function(){composing=true;});
kbInput.addEventListener('compositionend',function(){composing=false;syncRemoteEditor();});
kbInput.addEventListener('input',syncRemoteEditor);
kbInput.addEventListener('keydown',function(e){
  if(e.key==='Backspace')return;
  if(composing||e.isComposing)return;
  var map={Enter:36,Tab:48,Escape:53};var code=map[e.key];
  if(code!==undefined){e.preventDefault();sendKey(code,curFlags());resetRemoteEditor();}
});
function deleteRemoteEditor() {
  if(kbInput.value){var chars=Array.from(kbInput.value);chars.pop();kbInput.value=chars.join('');syncRemoteEditor();}
  else sendKey(51,curFlags());
}
window.trackpadDeleteRemote=deleteRemoteEditor;

/* 修饰键：点一下锁定，再点取消 */
Array.prototype.forEach.call(document.querySelectorAll('#kb [data-mod]'), function (b) {
  b.addEventListener('click', function () {
    var m = b.getAttribute('data-mod');
    mods[m] = mods[m] ? 0 : 1;
    b.classList.toggle('on', !!mods[m]);
  });
});

/* 功能键：带上当前锁定的修饰位 */
Array.prototype.forEach.call(document.querySelectorAll('#kb [data-key]'), function (b) {
  b.addEventListener('click', function () {
    sendKey(parseInt(b.getAttribute('data-key'), 10), curFlags());
  });
});

/* 组合键按钮：固定 Cmd + 某个字母键 */
Array.prototype.forEach.call(document.querySelectorAll('#kb [data-combo]'), function (b) {
  b.addEventListener('click', function () {
    sendKey(parseInt(b.getAttribute('data-combo'), 10), MOD_FLAG.cmd);
  });
});

/* 系统输入法弹出时 visualViewport 会变矮，抽屉跟着抬起来，别被键盘盖住 */
if (window.visualViewport) {
  var syncVv = function () {
    var gap = Math.max(0, innerHeight - visualViewport.height - visualViewport.offsetTop);
    document.documentElement.style.setProperty('--vvh', gap + 'px');
  };
  visualViewport.addEventListener('resize', syncVv);
  visualViewport.addEventListener('scroll', syncVv);
}
</script>
<script src="/app-ui.js"></script>
</body>
</html>
"""


def _serve_pad_image(conn):
    """把可选的 pad.png 发给平板；没有这个文件就返回 404，页面会自动退回内置面板。"""
    try:
        with open(PAD_IMAGE, "rb") as f:
            body = f.read()
    except OSError:
        conn.sendall(b"HTTP/1.1 404 Not Found\r\nContent-Length: 0\r\n"
                     b"Cache-Control: no-store\r\nConnection: close\r\n\r\n")
        return
    head = ("HTTP/1.1 200 OK\r\n"
            "Content-Type: image/png\r\n"
            "Content-Length: %d\r\n"
            "Cache-Control: no-store\r\n"
            "Connection: close\r\n\r\n" % len(body)).encode()
    conn.sendall(head + body)


class InputFrameClock:
    """Estimate only excess transit/processing delay; wall clocks need not match."""
    def __init__(self):
        self.offset=None;self.last=None

    def accept(self, stamp, now):
        if stamp is None:return True  # Older paired clients remain compatible.
        if isinstance(stamp,bool) or not isinstance(stamp,(int,float)) or not math.isfinite(stamp):return False
        sent=stamp/1000.0
        if self.last is not None and sent<self.last:return False
        self.last=sent
        observed=now-sent
        self.offset=observed if self.offset is None else min(self.offset,observed)
        return observed-self.offset<=.250


def reset_remote_input():
    with PAD.lock:
        if PAD.drag_down or PAD.dragging or PAD.drag_latched:mouse_up("left")
        PAD.drag_latched=False;PAD.last_tap_t=0
        PAD.reset();PAD.scroll_motion.stop()


def serve_client(conn, addr):
    ws_active = False
    try:
        conn.setsockopt(socket.IPPROTO_TCP,socket.TCP_NODELAY,1)
        conn.settimeout(10)
        raw = b""
        while b"\r\n\r\n" not in raw:
            chunk = conn.recv(4096)
            if not chunk:
                return
            raw += chunk
            if len(raw) > 16384:
                return

        head = raw.split(b"\r\n\r\n", 1)[0].decode("latin-1")
        lines = head.split("\r\n")
        request = lines[0].split(' ')
        if len(request) != 3:
            return
        method,path,version = request
        # Browser WebSocket cannot set custom headers; normalize only this exact
        # route/query and validate the marker in claim, never treat it as auth.
        from urllib.parse import urlsplit,parse_qs
        ws_client=None
        target=urlsplit(path)
        if target.path=='/ws' and target.query:
            query=parse_qs(target.query,keep_blank_values=True)
            if set(query)!={'client'} or len(query['client'])!=1:
                SECURITY.response(conn,400,'无效连接标记');return
            ws_client=query['client'][0];path='/ws'
        if version != 'HTTP/1.1':
            return
        headers = {}
        for line in lines[1:]:
            if ':' not in line:
                return
            name,value = line.split(':',1)
            name=name.strip().lower()
            if name in headers:
                return
            headers[name]=value.strip()
        if 'transfer-encoding' in headers:
            SECURITY.response(conn,400,'不支持分块请求');return
        try:
            length=int(headers.get('content-length','0'))
        except ValueError:
            SECURITY.response(conn,400,'无效请求长度');return
        if length < 0 or length > MAX_BODY:
            SECURITY.response(conn,413,'请求过大');return
        body=raw.split(b'\r\n\r\n',1)[1]
        if len(body)>length:
            SECURITY.response(conn,400,'请求长度不匹配');return
        if len(body)<length:
            more=recv_exact(conn,length-len(body))
            if more is None:return
            body+=more
        if SECURITY.route(conn,method,path,headers,body,addr[0]):
            return
        if path == '/ws':
            identity=SECURITY.authenticated(headers)
            if not SECURITY.claim(identity,conn,ws_client or headers.get('x-trackpad-client')):
                SECURITY.response(conn,409,'已有设备正在控制，请先在另一设备断开或在Mac撤销');return
            ws_active=True
            if not ws_handshake(conn, lines[1:]):
                return
            conn.settimeout(15)
            frame_clock=InputFrameClock();input_blocked=False
            with SECURITY.input_lock:
                if not SECURITY.is_current(conn):return
                reset_remote_input()
                ws_send_text(conn,json.dumps({"status":SECURITY.input_status()}))
            print('  [ws] 已配对设备建立局域网输入通道', flush=True)
            pointer_gain = 720
            scroll_speed,inertia,drag_lock=1.0,1.0,False
            while True:
                opcode, data = ws_recv(conn)
                if opcode is None or opcode == 8:
                    break
                with SECURITY.input_lock:
                    if not SECURITY.is_current(conn):break
                    if opcode == 9:
                        conn.sendall(bytes([0x8A, 0]))
                        continue
                    if opcode != 1:
                        continue
                    try:
                        msg = json.loads(data.decode())
                    except Exception:
                        continue
                    if not isinstance(msg, dict):
                        continue
                    # Liveness is independent of motion age/order; never replay input here.
                    # A delayed heartbeat must not silence replies and trigger a false timeout.
                    if msg.get('heartbeat'):
                        ws_send_text(conn,json.dumps({'alive':True,'status':SECURITY.input_status()}))
                        continue
                    if not frame_clock.accept(msg.get('sentAt'),time.monotonic()):
                        if not input_blocked:
                            reset_remote_input()
                            ws_send_text(conn,json.dumps({'inputReset':'输入延迟偏高，已清除旧触点；请抬手后继续'}))
                            print('  [ws] 已丢弃积压输入并释放按键',flush=True)
                        input_blocked=True
                        continue
                    if isinstance(msg.get('p'),list):
                        SECURITY.input_frames += 1
                    if not msg.get('cancel') and SECURITY.input_status()['inputReady'] is False:
                        ws_send_text(conn,json.dumps({'status':SECURITY.input_status()}))
                        continue
                    settings = msg.get("settings")
                    if isinstance(settings, dict):
                        gain = settings.get("pointerGain")
                        if isinstance(gain, (int, float)) and not isinstance(gain, bool) and math.isfinite(gain):
                            pointer_gain = max(250, min(1400, gain))
                        speed=settings.get("scrollSpeed")
                        strength=settings.get("inertia")
                        if isinstance(speed,(int,float)) and not isinstance(speed,bool) and math.isfinite(speed):scroll_speed=max(.5,min(2,speed))
                        if isinstance(strength,(int,float)) and not isinstance(strength,bool) and math.isfinite(strength):inertia=max(0,min(1.5,strength))
                        if isinstance(settings.get("dragLock"),bool):drag_lock=settings["dragLock"]
                    if msg.get("cancel"):
                        reset_remote_input();input_blocked=False
                    pts = msg.get("p")
                    if isinstance(pts, list) and len(pts) <= 5:
                        if input_blocked:
                            if pts:continue  # A held finger must not resume an interrupted stroke.
                            input_blocked=False
                        PAD.on_frame(pts, pointer_gain, scroll_speed, inertia, drag_lock, msg.get("surface"), msg.get("directDrag") is True)

                    # 平板键盘：文本走 Unicode 注入，功能键/组合键走键码
                    text = msg.get("t")
                    if isinstance(text, str) and 0 < len(text) <= 2048:
                        type_text(text)

                    key = msg.get("k")
                    if isinstance(key, dict):
                        code = key.get("c")
                        if isinstance(code, int) and not isinstance(code, bool) and 0 <= code <= 127:
                            flags = key.get("f") or 0
                            if not isinstance(flags,int):continue
                            flags &= MOD_MASK
                            if code in (72, 73, 74):
                                result=media_volume(code)
                                if result:ws_send_text(conn,json.dumps({"volume":result}))
                            else:
                                key_combo(code, int(flags))

            print("  [ws] 断开 %s" % (addr[0],))
        elif path == "/app-ui.js":
            with open(os.path.join(os.path.dirname(SELF_PATH), "android-apk", "app", "src", "main", "assets", "app-ui.js"), "rb") as asset:
                body = asset.read()
            SECURITY.response(conn,200,body,'application/javascript; charset=utf-8')
        else:
            SECURITY.response(conn,200,PAGE,extra=SECURITY.page_headers(headers))
    except socket.timeout:
        if ws_active:
            print("  [ws] 控制通道读取超时（15秒未收到下一段数据）；释放按键并等待客户端重连",flush=True)
        else:
            print("  [conn] HTTP请求等待超时（尚未建立控制通道）",flush=True)
    except Exception as e:
        print("  [conn] 通道关闭: %s" % type(e).__name__, flush=True)
    finally:
        if ws_active:
            with SECURITY.input_lock:
                if SECURITY.is_current(conn):
                    reset_remote_input()
                    SECURITY.release(conn)
        try:
            conn.close()
        except Exception:
            pass


def local_ips():
    """列出可用的局域网 IPv4，过滤回环、链路本地和代理 TUN 网段。"""
    import subprocess

    ips = []
    try:
        out = subprocess.check_output(["ifconfig"], text=True, timeout=3)
    except Exception:
        out = ""
    for line in out.splitlines():
        line = line.strip()
        if not line.startswith("inet "):
            continue
        ip = line.split()[1]
        if ip.startswith(("127.", "169.254.", "198.18.", "198.19.")):
            continue
        if ip not in ips:
            ips.append(ip)

    def rank(x):
        if x.startswith("192.168."):
            return 0
        if x.startswith("10."):
            return 1
        if x.startswith("172."):
            return 2
        return 3

    ips.sort(key=rank)
    return ips


PAD = Trackpad()


def _scroll_clock():
    while True:
        time.sleep(.016)
        PAD.tick_scroll(time.monotonic())


def main():
    global SECURITY
    SECURITY = SecureReceiver(port=PORT)
    SECURITY.power = IdleSleepGuard()
    SECURITY.input_check = lambda: bool(cg.CGPreflightPostEventAccess()) if HAS_ACCESS_API else None
    SECURITY.bootstrap()
    threading.Thread(target=_scroll_clock, daemon=True, name="trackpad-scroll").start()
    # stdout 接到 tee 时是管道、默认块缓冲，启动信息会卡在缓冲区里不显示。
    # 改成行缓冲，重载后横幅和自检结果立刻可见。
    try:
        sys.stdout.reconfigure(line_buffering=True)
    except Exception:
        pass

    print("")
    print("  Trackpad Server  —  路线 C")
    print("  " + "-" * 46)
    print("  屏幕: %d x %d" % (PAD.sw, PAD.sh))

    if HAS_ACCESS_API:
        ok = cg.CGPreflightPostEventAccess()
        if not ok:
            print("")
            print("  [!] 辅助功能权限未开启，注入不会生效。")
            print("      正在请求授权…… 若弹窗未出现，请手动到：")
            print("      系统设置 → 隐私与安全性 → 辅助功能")
            print("      勾选运行本脚本的终端 App，然后重启终端。")
            cg.CGRequestPostEventAccess()
        else:
            print("  权限: 辅助功能 已授权（未执行真实鼠标注入测试）")
            # Keep startup passive; runtime input only follows authenticated device frames.
    print('  已启用IP局域网 HTTP / WS（明文）；未配对设备无法控制。')
    print('  双击“触摸板.app”打开配对页，用手机或平板相机扫码。')
    print('  已配对设备地址: '+SECURITY.origin)
    print('  IP局域网直连（明文），设备权限保存在非同步的应用支持目录。')
    print('')
    print("  Ctrl+C 停止")
    print("  改完代码会自动重载，不用关终端")
    print("")

    srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    srv.bind((HOST, PORT))
    srv.listen(8)
    srv.settimeout(1.0)   # 每秒醒一次，用来检查代码是否变了
    mtime = _self_mtime()
    try:
        while True:
            try:
                conn, addr = srv.accept()
            except socket.timeout:
                conn = None
            except OSError:
                conn = None

            if conn is None:
                if AUTO_RELOAD and _should_reload(mtime):
                    if not _reload_now(srv):
                        # 新代码有问题，继续用旧版本跑，并把时间戳跟上，避免每秒重试
                        mtime = _self_mtime()
                continue

            t = threading.Thread(target=serve_client, args=(conn, addr))
            t.daemon = True
            t.start()
    except KeyboardInterrupt:
        print("\n  已停止")
    finally:
        srv.close()


def _self_mtime():
    try:
        return os.path.getmtime(SELF_PATH)
    except OSError:
        return 0.0


def _should_reload(mtime):
    """代码文件被改过，或者存在 .reload 标记，就重载。"""
    if os.path.exists(RELOAD_FLAG):
        try:
            os.remove(RELOAD_FLAG)
        except OSError:
            pass
        return True
    return _self_mtime() != mtime


def _reload_now(srv):
    """原地 exec 重载：进程号不变、父终端不变，辅助功能授权不会丢。

    返回 False 表示新代码有问题、没有重载；成功时 execv 直接替换进程，不会返回。
    """
    try:
        with open(SELF_PATH, "rb") as f:
            compile(f.read(), SELF_PATH, "exec")
    except Exception as e:
        print("")
        print("  [!] 新代码有错误，继续运行当前版本：")
        print("      %s" % e)
        print("")
        return False

    print("")
    print("  " + "=" * 46)
    print("  检测到代码更新，正在重载……")
    print("  " + "=" * 46)
    sys.stdout.flush()
    sys.stderr.flush()
    try:
        srv.close()
    except Exception:
        pass
    time.sleep(0.05)
    os.execv(sys.executable, [sys.executable, SELF_PATH])
    return False   # 理论上到不了


if __name__ == "__main__":
    main()
