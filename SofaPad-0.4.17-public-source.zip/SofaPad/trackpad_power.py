"""A scoped macOS idle-sleep assertion; no settings change or background helper."""
import ctypes

class IdleSleepGuard:
    def __init__(self):
        self.active=False
        self._assertion=0
        self._iokit=None

    def acquire(self):
        if self.active:return True
        try:
            cf=ctypes.CDLL('/System/Library/Frameworks/CoreFoundation.framework/CoreFoundation')
            io=ctypes.CDLL('/System/Library/Frameworks/IOKit.framework/IOKit')
            cf.CFStringCreateWithCString.argtypes=[ctypes.c_void_p,ctypes.c_char_p,ctypes.c_uint32]
            cf.CFStringCreateWithCString.restype=ctypes.c_void_p
            cf.CFRelease.argtypes=[ctypes.c_void_p];cf.CFRelease.restype=None
            io.IOPMAssertionCreateWithName.argtypes=[ctypes.c_void_p,ctypes.c_uint32,ctypes.c_void_p,ctypes.POINTER(ctypes.c_uint32)]
            io.IOPMAssertionCreateWithName.restype=ctypes.c_int
            io.IOPMAssertionRelease.argtypes=[ctypes.c_uint32];io.IOPMAssertionRelease.restype=ctypes.c_int
            kind=cf.CFStringCreateWithCString(None,b'PreventUserIdleSystemSleep',0x08000100)
            name=cf.CFStringCreateWithCString(None,b'TabletTrackpad active LAN controller',0x08000100)
            if not kind or not name:
                if kind:cf.CFRelease(kind)
                if name:cf.CFRelease(name)
                return False
            try:
                value=ctypes.c_uint32()
                result=io.IOPMAssertionCreateWithName(kind,255,name,ctypes.byref(value))
            finally:cf.CFRelease(kind);cf.CFRelease(name)
            if result!=0:return False
            self._iokit=io;self._assertion=value.value;self.active=True
            return True
        except (OSError,AttributeError):return False

    def release(self):
        if self.active and self._iokit:
            self._iokit.IOPMAssertionRelease(self._assertion)
        self.active=False;self._assertion=0
